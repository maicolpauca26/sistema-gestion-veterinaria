-- Ejecutar UNA sola vez (Laragon -> MySQL -> HeidiSQL / phpMyAdmin, o consola: mysql -u root < vetmvc.sql)
SET NAMES utf8mb4;
CREATE DATABASE IF NOT EXISTS vetmvc CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vetmvc;

CREATE TABLE IF NOT EXISTS mascotas (
    id          INT AUTO_INCREMENT PRIMARY KEY,
    nombre      VARCHAR(60)  NOT NULL,
    especie     VARCHAR(30)  NOT NULL,
    raza        VARCHAR(50),
    edad        INT          NOT NULL,
    peso        DECIMAL(6,2) NOT NULL,
    propietario VARCHAR(80)  NOT NULL,
    telefono    VARCHAR(20)
);

-- Datos de ejemplo (opcional, borra estas líneas si no los quieres)
INSERT INTO mascotas (nombre, especie, raza, edad, peso, propietario, telefono) VALUES
('Firulais', 'Perro', 'Mestizo',  4, 12.50, 'Carlos Ramos',  '987654321'),
('Michi',    'Gato',  'Siamés',   2,  4.20, 'Lucía Quispe',  '912345678'),
('Rocky',    'Perro', 'Labrador', 6, 28.00, 'Pedro Huamán',  '956781234');
