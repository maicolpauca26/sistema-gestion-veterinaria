package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * MODELO - Acceso a datos de Mascota (CRUD sobre MySQL).
 * Hereda de Conexion. No sabe nada de ventanas: solo habla con la base de datos.
 */
public class ConsultasMascota extends Conexion {

    private String ultimoError;

    /** Mensaje del último error de BD (null si la última operación salió bien). */
    public String getUltimoError() {
        return ultimoError;
    }

    public boolean insertar(Mascota m) {
        String sql = "INSERT INTO mascotas (nombre, especie, raza, edad, peso, propietario, telefono) "
                + "VALUES (?, ?, ?, ?, ?, ?, ?)";
        ultimoError = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getNombre());
            ps.setString(2, m.getEspecie());
            ps.setString(3, m.getRaza());
            ps.setInt(4, m.getEdad());
            ps.setDouble(5, m.getPeso());
            ps.setString(6, m.getPropietario());
            ps.setString(7, m.getTelefono());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    public boolean modificar(Mascota m) {
        String sql = "UPDATE mascotas SET nombre=?, especie=?, raza=?, edad=?, peso=?, "
                + "propietario=?, telefono=? WHERE id=?";
        ultimoError = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, m.getNombre());
            ps.setString(2, m.getEspecie());
            ps.setString(3, m.getRaza());
            ps.setInt(4, m.getEdad());
            ps.setDouble(5, m.getPeso());
            ps.setString(6, m.getPropietario());
            ps.setString(7, m.getTelefono());
            ps.setInt(8, m.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    public boolean eliminar(int id) {
        String sql = "DELETE FROM mascotas WHERE id=?";
        ultimoError = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    public List<Mascota> listar() {
        String sql = "SELECT id, nombre, especie, raza, edad, peso, propietario, telefono "
                + "FROM mascotas ORDER BY id";
        ultimoError = null;
        List<Mascota> lista = new ArrayList<>();
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(armarMascota(rs));
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
        }
        return lista;
    }

    /** Busca por nombre, especie o propietario (coincidencia parcial). */
    public List<Mascota> buscar(String texto) {
        String sql = "SELECT id, nombre, especie, raza, edad, peso, propietario, telefono "
                + "FROM mascotas WHERE nombre LIKE ? OR especie LIKE ? OR propietario LIKE ? ORDER BY id";
        ultimoError = null;
        List<Mascota> lista = new ArrayList<>();
        String patron = "%" + texto + "%";
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, patron);
            ps.setString(2, patron);
            ps.setString(3, patron);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(armarMascota(rs));
                }
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
        }
        return lista;
    }

    private Mascota armarMascota(ResultSet rs) throws SQLException {
        return new Mascota(
                rs.getInt("id"),
                rs.getString("nombre"),
                rs.getString("especie"),
                rs.getString("raza"),
                rs.getInt("edad"),
                rs.getDouble("peso"),
                rs.getString("propietario"),
                rs.getString("telefono"));
    }
}
