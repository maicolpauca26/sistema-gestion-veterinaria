package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * MODELO - Conexión a MySQL.
 * Si tu MySQL (Laragon) tiene otra contraseña o puerto, cámbialo aquí.
 */
public class Conexion {

    private static final String URL =
            "jdbc:mysql://localhost:3306/vetmvc?useSSL=false&serverTimezone=UTC&allowPublicKeyRetrieval=true"
            + "&useUnicode=true&characterEncoding=UTF-8";
    private static final String USUARIO = "root";
    private static final String PASSWORD = "";   // Laragon trae root sin contraseña

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }
}
