package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.List;
import javax.swing.JOptionPane;
import modelo.ConsultasMascota;
import modelo.Mascota;
import vista.FrmMascota;

/**
 * CONTROLADOR - Escucha los botones de la Vista, valida los datos,
 * le pide al Modelo que guarde/consulte y actualiza la Vista con el resultado.
 */
public class CtrlMascota implements ActionListener {

    private final ConsultasMascota consultas;   // Modelo
    private final FrmMascota frm;               // Vista

    public CtrlMascota(ConsultasMascota consultas, FrmMascota frm) {
        this.consultas = consultas;
        this.frm = frm;

        frm.btnGuardar.addActionListener(this);
        frm.btnModificar.addActionListener(this);
        frm.btnEliminar.addActionListener(this);
        frm.btnLimpiar.addActionListener(this);
        frm.btnBuscar.addActionListener(this);
        frm.btnTodos.addActionListener(this);

        // Al elegir una fila de la tabla, sus datos pasan al formulario
        frm.tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                seleccionarFila();
            }
        });
    }

    /** Arranque: centra la ventana y carga la tabla desde la base de datos. */
    public void iniciar() {
        frm.setLocationRelativeTo(null);
        cargarTabla(consultas.listar());
        if (consultas.getUltimoError() != null) {
            JOptionPane.showMessageDialog(frm,
                    "No se pudo conectar a la base de datos.\n"
                    + "• Verifica que MySQL (Laragon) esté iniciado.\n"
                    + "• Verifica que ejecutaste sql/vetmvc.sql.\n"
                    + "• Revisa usuario y contraseña en modelo/Conexion.java.\n\n"
                    + "Detalle: " + consultas.getUltimoError(),
                    "Sin conexión", JOptionPane.ERROR_MESSAGE);
            estado("Sin conexión a la base de datos.");
        } else {
            estado("Listo. " + frm.modeloTabla.getRowCount() + " mascota(s) registrada(s).");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object origen = e.getSource();
        if (origen == frm.btnGuardar) {
            guardar();
        } else if (origen == frm.btnModificar) {
            modificar();
        } else if (origen == frm.btnEliminar) {
            eliminar();
        } else if (origen == frm.btnLimpiar) {
            limpiar();
        } else if (origen == frm.btnBuscar) {
            buscar();
        } else if (origen == frm.btnTodos) {
            frm.txtBuscar.setText("");
            cargarTabla(consultas.listar());
            estado("Mostrando todas las mascotas.");
        }
    }

    // ---------------- Operaciones ----------------

    private void guardar() {
        Mascota m = leerFormulario();
        if (m == null) {
            return;
        }
        if (consultas.insertar(m)) {
            limpiar();
            cargarTabla(consultas.listar());
            estado("Mascota registrada correctamente.");
        } else {
            error("No se pudo guardar:\n" + consultas.getUltimoError());
        }
    }

    private void modificar() {
        if (frm.txtId.getText().trim().isEmpty()) {
            aviso("Primero selecciona una mascota de la tabla.");
            return;
        }
        Mascota m = leerFormulario();
        if (m == null) {
            return;
        }
        m.setId(Integer.parseInt(frm.txtId.getText().trim()));
        if (consultas.modificar(m)) {
            limpiar();
            cargarTabla(consultas.listar());
            estado("Mascota modificada correctamente.");
        } else {
            error("No se pudo modificar:\n" + consultas.getUltimoError());
        }
    }

    private void eliminar() {
        if (frm.txtId.getText().trim().isEmpty()) {
            aviso("Primero selecciona una mascota de la tabla.");
            return;
        }
        int opcion = JOptionPane.showConfirmDialog(frm,
                "¿Eliminar a \"" + frm.txtNombre.getText().trim() + "\"?",
                "Confirmar eliminación", JOptionPane.YES_NO_OPTION);
        if (opcion != JOptionPane.YES_OPTION) {
            return;
        }
        if (consultas.eliminar(Integer.parseInt(frm.txtId.getText().trim()))) {
            limpiar();
            cargarTabla(consultas.listar());
            estado("Mascota eliminada.");
        } else {
            error("No se pudo eliminar:\n" + consultas.getUltimoError());
        }
    }

    private void buscar() {
        String texto = frm.txtBuscar.getText().trim();
        if (texto.isEmpty()) {
            cargarTabla(consultas.listar());
            estado("Mostrando todas las mascotas.");
            return;
        }
        List<Mascota> resultado = consultas.buscar(texto);
        cargarTabla(resultado);
        estado(resultado.size() + " resultado(s) para \"" + texto + "\".");
    }

    // ---------------- Apoyo ----------------

    /** Lee y valida el formulario. Devuelve null (y avisa) si hay datos inválidos. */
    private Mascota leerFormulario() {
        String nombre = frm.txtNombre.getText().trim();
        String especie = frm.txtEspecie.getText().trim();
        String propietario = frm.txtPropietario.getText().trim();

        if (nombre.isEmpty() || especie.isEmpty() || propietario.isEmpty()) {
            aviso("Nombre, especie y propietario son obligatorios.");
            return null;
        }

        int edad;
        double peso;
        try {
            edad = Integer.parseInt(frm.txtEdad.getText().trim());
        } catch (NumberFormatException ex) {
            aviso("La edad debe ser un número entero (años).");
            return null;
        }
        try {
            peso = Double.parseDouble(frm.txtPeso.getText().trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            aviso("El peso debe ser un número (ej. 12.5).");
            return null;
        }
        if (edad < 0 || edad > 40) {
            aviso("La edad debe estar entre 0 y 40 años.");
            return null;
        }
        if (peso <= 0 || peso > 200) {
            aviso("El peso debe ser mayor que 0 y no más de 200 kg.");
            return null;
        }

        Mascota m = new Mascota();
        m.setNombre(nombre);
        m.setEspecie(especie);
        m.setRaza(frm.txtRaza.getText().trim());
        m.setEdad(edad);
        m.setPeso(peso);
        m.setPropietario(propietario);
        m.setTelefono(frm.txtTelefono.getText().trim());
        return m;
    }

    private void cargarTabla(List<Mascota> lista) {
        frm.modeloTabla.setRowCount(0);
        for (Mascota m : lista) {
            frm.modeloTabla.addRow(new Object[]{
                m.getId(), m.getNombre(), m.getEspecie(), m.getRaza(),
                m.getEdad(), m.getPeso(), m.getPropietario(), m.getTelefono()
            });
        }
    }

    private void seleccionarFila() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0) {
            return;
        }
        frm.txtId.setText(String.valueOf(frm.modeloTabla.getValueAt(fila, 0)));
        frm.txtNombre.setText(valor(fila, 1));
        frm.txtEspecie.setText(valor(fila, 2));
        frm.txtRaza.setText(valor(fila, 3));
        frm.txtEdad.setText(valor(fila, 4));
        frm.txtPeso.setText(valor(fila, 5));
        frm.txtPropietario.setText(valor(fila, 6));
        frm.txtTelefono.setText(valor(fila, 7));
    }

    private String valor(int fila, int columna) {
        Object v = frm.modeloTabla.getValueAt(fila, columna);
        return v == null ? "" : v.toString();
    }

    private void limpiar() {
        frm.txtId.setText("");
        frm.txtNombre.setText("");
        frm.txtEspecie.setText("");
        frm.txtRaza.setText("");
        frm.txtEdad.setText("");
        frm.txtPeso.setText("");
        frm.txtPropietario.setText("");
        frm.txtTelefono.setText("");
        frm.tabla.clearSelection();
        frm.txtNombre.requestFocus();
    }

    private void estado(String mensaje) {
        frm.lblEstado.setText("  " + mensaje);
    }

    private void aviso(String mensaje) {
        JOptionPane.showMessageDialog(frm, mensaje, "Datos incompletos", JOptionPane.WARNING_MESSAGE);
    }

    private void error(String mensaje) {
        JOptionPane.showMessageDialog(frm, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }
}
