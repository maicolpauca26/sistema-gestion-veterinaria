package vetmvc;

import controlador.CtrlMascota;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import modelo.ConsultasMascota;
import vista.FrmMascota;

/**
 * Punto de entrada: crea el Modelo, la Vista y el Controlador, y los conecta.
 */
public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignorada) {
            // si falla, Swing usa su aspecto por defecto
        }

        SwingUtilities.invokeLater(() -> {
            ConsultasMascota modelo = new ConsultasMascota();
            FrmMascota vista = new FrmMascota();
            CtrlMascota controlador = new CtrlMascota(modelo, vista);
            controlador.iniciar();
            vista.setVisible(true);
        });
    }
}
