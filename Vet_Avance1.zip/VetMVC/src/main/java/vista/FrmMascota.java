package vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 * VISTA - Ventana de gestión de mascotas (solo interfaz, sin lógica ni consultas).
 * Los componentes son públicos para que el Controlador pueda escucharlos.
 */
public class FrmMascota extends JFrame {

    public JTextField txtId = new JTextField();
    public JTextField txtNombre = new JTextField();
    public JTextField txtEspecie = new JTextField();
    public JTextField txtRaza = new JTextField();
    public JTextField txtEdad = new JTextField();
    public JTextField txtPeso = new JTextField();
    public JTextField txtPropietario = new JTextField();
    public JTextField txtTelefono = new JTextField();
    public JTextField txtBuscar = new JTextField(22);

    public JButton btnGuardar = new JButton("Guardar");
    public JButton btnModificar = new JButton("Modificar");
    public JButton btnEliminar = new JButton("Eliminar");
    public JButton btnLimpiar = new JButton("Limpiar");
    public JButton btnBuscar = new JButton("Buscar");
    public JButton btnTodos = new JButton("Mostrar todos");

    public JLabel lblEstado = new JLabel(" ");

    public DefaultTableModel modeloTabla;
    public JTable tabla;

    public FrmMascota() {
        super("VetSystem MVC - Gestión de mascotas");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(920, 580);
        setLayout(new BorderLayout(8, 8));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtId.setEditable(false);

        // --- Búsqueda ---
        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        panelBusqueda.add(new JLabel("Buscar (nombre, especie o propietario):"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnTodos);

        // --- Formulario ---
        JPanel panelForm = new JPanel(new GridLayout(4, 4, 8, 8));
        panelForm.setBorder(BorderFactory.createTitledBorder("Datos de la mascota"));
        panelForm.add(new JLabel("ID:"));
        panelForm.add(txtId);
        panelForm.add(new JLabel("Nombre:"));
        panelForm.add(txtNombre);
        panelForm.add(new JLabel("Especie:"));
        panelForm.add(txtEspecie);
        panelForm.add(new JLabel("Raza:"));
        panelForm.add(txtRaza);
        panelForm.add(new JLabel("Edad (años):"));
        panelForm.add(txtEdad);
        panelForm.add(new JLabel("Peso (kg):"));
        panelForm.add(txtPeso);
        panelForm.add(new JLabel("Propietario:"));
        panelForm.add(txtPropietario);
        panelForm.add(new JLabel("Teléfono:"));
        panelForm.add(txtTelefono);

        JPanel norte = new JPanel(new BorderLayout(0, 8));
        norte.add(panelBusqueda, BorderLayout.NORTH);
        norte.add(panelForm, BorderLayout.CENTER);
        add(norte, BorderLayout.NORTH);

        // --- Tabla ---
        String[] columnas = {"ID", "Nombre", "Especie", "Raza", "Edad", "Peso (kg)", "Propietario", "Teléfono"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(24);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        // --- Botones y estado ---
        JPanel panelBotones = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 4));
        panelBotones.add(btnGuardar);
        panelBotones.add(btnModificar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnLimpiar);

        JPanel sur = new JPanel(new BorderLayout());
        sur.add(panelBotones, BorderLayout.CENTER);
        sur.add(lblEstado, BorderLayout.SOUTH);
        add(sur, BorderLayout.SOUTH);
    }
}
