# VetMVC — Gestión de mascotas (patrón MVC en Java)

CRUD de **mascotas** de la veterinaria con **Java Swing + MySQL**, organizado en
**Modelo – Vista – Controlador**. Es el mismo molde que luego se repite para citas,
inventario y facturación.

![Ventana](docs/ventana.png)

## 1. Requisitos
- JDK 11 o superior (probado con 21) y NetBeans (proyecto Maven).
- MySQL de Laragon iniciado (usuario `root`, sin contraseña).

## 2. Cómo ponerlo a funcionar
1. **Crear la base de datos:** ejecuta `sql/vetmvc.sql` una sola vez
   (HeidiSQL / phpMyAdmin de Laragon, o en consola: `mysql -u root < sql/vetmvc.sql`).
2. **Abrir en NetBeans:** *File → Open Project* → elige la carpeta `VetMVC` (la del `pom.xml`).
3. **Dependencias:** Maven descarga solo el conector de MySQL. Si aparece
   *"No suitable driver"* o la dependencia sale en rojo:
   clic derecho al proyecto → **Reload POM**, luego en *Dependencies* →
   **Download Declared Dependencies**, y después **Clean and Build**.
4. **Ejecutar:** clic derecho → *Run* (clase principal `vetmvc.Main`).
5. Si tu MySQL tiene otra contraseña o puerto, cámbialo en `modelo/Conexion.java`.

## 3. Estructura

```
src/main/java/
├── modelo/
│   ├── Conexion.java          → conexión a MySQL (JDBC)
│   ├── Mascota.java           → entidad: atributos + getters/setters
│   └── ConsultasMascota.java  → CRUD en SQL (extiende Conexion)
├── vista/
│   └── FrmMascota.java        → ventana Swing (solo interfaz)
├── controlador/
│   └── CtrlMascota.java       → escucha los botones y coordina todo
└── vetmvc/Main.java           → crea Modelo, Vista y Controlador y los conecta
sql/vetmvc.sql                 → crea la BD `vetmvc` y la tabla `mascotas`
```

## 4. Qué hace cada capa

| Capa | Responsabilidad | Lo que NO hace |
|---|---|---|
| **Modelo** | Guarda y consulta los datos en MySQL | No sabe nada de ventanas |
| **Vista** | Muestra formulario, tabla y botones | No valida ni hace consultas |
| **Controlador** | Recibe el clic, valida, le pide al Modelo la operación y actualiza la Vista | No dibuja la interfaz ni escribe SQL |

**Flujo de "Guardar":**
`clic en Guardar (Vista)` → `CtrlMascota.actionPerformed()` → `leerFormulario()` valida
→ `ConsultasMascota.insertar()` ejecuta el INSERT → el controlador limpia el formulario y
recarga la tabla (Vista).

## 5. Funciones
Guardar · Modificar (selecciona una fila de la tabla) · Eliminar (con confirmación) ·
Buscar por nombre, especie o propietario · Mostrar todos · Limpiar.
Validaciones: nombre/especie/propietario obligatorios, edad entera 0–40, peso 0–200 kg.

## 6. Cómo ampliarlo a los otros módulos
Copia el molde cambiando el nombre de la entidad:

| Módulo | Modelo | Vista | Controlador | Tabla |
|---|---|---|---|---|
| Citas | `Cita`, `ConsultasCita` | `FrmCita` | `CtrlCita` | `citas` |
| Inventario | `Producto`, `ConsultasProducto` | `FrmProducto` | `CtrlProducto` | `productos` |
| Facturación | `Comprobante`, `ConsultasComprobante` | `FrmComprobante` | `CtrlComprobante` | `comprobantes` |

La conexión (`Conexion.java`) se reutiliza tal cual.

## 7. Nota sobre NetBeans
La ventana está escrita a mano (no con el diseñador), por eso en `FrmMascota.java`
no aparece la pestaña *Design*: se edita como código. Funciona igual.
