-- =====================================================================
--  DR.SHEEP - Sistema Integral de Gestión Veterinaria
--  Base de datos: dr_sheep_vet  (MySQL 8 / MariaDB 10.5+, InnoDB, utf8mb4)
--  Ejecutar UNA sola vez (HeidiSQL: abrir el archivo y pulsar F9;
--  o en consola: mysql -u root < sql/dr_sheep_vet.sql)
-- =====================================================================
SET NAMES utf8mb4;
DROP DATABASE IF EXISTS dr_sheep_vet;
CREATE DATABASE dr_sheep_vet CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE dr_sheep_vet;

-- ---------------- Seguridad ----------------
CREATE TABLE rol (
    id_rol  INT AUTO_INCREMENT PRIMARY KEY,
    nombre  VARCHAR(30) NOT NULL UNIQUE
) ENGINE=InnoDB;

CREATE TABLE usuario (
    id_usuario         INT AUTO_INCREMENT PRIMARY KEY,
    id_rol             INT          NOT NULL,
    username           VARCHAR(30)  NOT NULL UNIQUE,
    password_hash      VARCHAR(200) NOT NULL,          -- PBKDF2 (nunca texto plano)
    nombre_completo    VARCHAR(80)  NOT NULL,
    activo             TINYINT(1)   NOT NULL DEFAULT 1,
    intentos_fallidos  INT          NOT NULL DEFAULT 0,
    FOREIGN KEY (id_rol) REFERENCES rol(id_rol)
) ENGINE=InnoDB;

CREATE TABLE log_auditoria (
    id_log      INT AUTO_INCREMENT PRIMARY KEY,
    id_usuario  INT NULL,
    accion      VARCHAR(120) NOT NULL,
    fecha       DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_log_fecha (fecha),
    FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

-- ---------------- Clientes y mascotas ----------------
CREATE TABLE cliente (
    id_cliente  INT AUTO_INCREMENT PRIMARY KEY,
    dni         CHAR(8)      NOT NULL UNIQUE,
    nombres     VARCHAR(80)  NOT NULL,
    telefono    VARCHAR(20),
    direccion   VARCHAR(120),
    activo      TINYINT(1)   NOT NULL DEFAULT 1,
    CONSTRAINT ck_cliente_dni CHECK (dni REGEXP '^[0-9]{8}$')
) ENGINE=InnoDB;

CREATE TABLE mascota (
    id_mascota        INT AUTO_INCREMENT PRIMARY KEY,
    id_cliente        INT          NOT NULL,
    nombre            VARCHAR(60)  NOT NULL,
    especie           VARCHAR(30)  NOT NULL,
    raza              VARCHAR(50),
    sexo              CHAR(1)      NOT NULL,
    fecha_nacimiento  DATE,
    peso              DECIMAL(6,2) NOT NULL,
    activo            TINYINT(1)   NOT NULL DEFAULT 1,
    CONSTRAINT ck_mascota_peso CHECK (peso > 0),
    CONSTRAINT ck_mascota_sexo CHECK (sexo IN ('M','H')),
    FOREIGN KEY (id_cliente) REFERENCES cliente(id_cliente)
) ENGINE=InnoDB;

-- ---------------- Citas y atenciones ----------------
CREATE TABLE cita (
    id_cita         INT AUTO_INCREMENT PRIMARY KEY,
    id_mascota      INT         NOT NULL,
    id_veterinario  INT         NOT NULL,
    id_registrador  INT         NOT NULL,
    fecha_hora      DATETIME    NOT NULL,
    motivo          VARCHAR(150) NOT NULL,
    estado          VARCHAR(15) NOT NULL DEFAULT 'PROGRAMADA',
    CONSTRAINT ck_cita_estado CHECK (estado IN ('PROGRAMADA','CONFIRMADA','CANCELADA','ATENDIDA')),
    INDEX idx_cita_fecha (fecha_hora),
    FOREIGN KEY (id_mascota)     REFERENCES mascota(id_mascota),
    FOREIGN KEY (id_veterinario) REFERENCES usuario(id_usuario),
    FOREIGN KEY (id_registrador) REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

CREATE TABLE atencion (
    id_atencion  INT AUTO_INCREMENT PRIMARY KEY,
    id_cita      INT          NOT NULL UNIQUE,         -- 1 atención por cita
    fecha        DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    diagnostico  VARCHAR(300) NOT NULL,
    tratamiento  VARCHAR(300),
    FOREIGN KEY (id_cita) REFERENCES cita(id_cita)
) ENGINE=InnoDB;

-- ---------------- Inventario ----------------
CREATE TABLE producto (
    id_producto   INT AUTO_INCREMENT PRIMARY KEY,
    codigo        VARCHAR(20)  NOT NULL UNIQUE,
    nombre        VARCHAR(80)  NOT NULL,
    precio        DECIMAL(8,2) NOT NULL,
    stock         INT          NOT NULL DEFAULT 0,
    stock_minimo  INT          NOT NULL DEFAULT 5,
    activo        TINYINT(1)   NOT NULL DEFAULT 1,
    CONSTRAINT ck_producto_precio CHECK (precio >= 0),
    CONSTRAINT ck_producto_stock  CHECK (stock >= 0 AND stock_minimo >= 0)
) ENGINE=InnoDB;

CREATE TABLE movimiento_inventario (
    id_movimiento  INT AUTO_INCREMENT PRIMARY KEY,
    id_producto    INT         NOT NULL,
    id_atencion    INT         NULL,
    id_usuario     INT         NOT NULL,
    tipo           VARCHAR(7)  NOT NULL,
    cantidad       INT         NOT NULL,
    fecha          DATETIME    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT ck_mov_tipo CHECK (tipo IN ('ENTRADA','SALIDA')),
    CONSTRAINT ck_mov_cant CHECK (cantidad > 0),
    FOREIGN KEY (id_producto) REFERENCES producto(id_producto),
    FOREIGN KEY (id_atencion) REFERENCES atencion(id_atencion),
    FOREIGN KEY (id_usuario)  REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

-- ---------------- Facturación ----------------
CREATE TABLE servicio (
    id_servicio  INT AUTO_INCREMENT PRIMARY KEY,
    nombre       VARCHAR(60)  NOT NULL UNIQUE,
    precio       DECIMAL(8,2) NOT NULL,
    CONSTRAINT ck_servicio_precio CHECK (precio >= 0)
) ENGINE=InnoDB;

CREATE TABLE comprobante (
    id_comprobante  INT AUTO_INCREMENT PRIMARY KEY,
    id_atencion     INT          NOT NULL UNIQUE,      -- 1 comprobante por atención
    id_usuario      INT          NOT NULL,
    serie           CHAR(4)      NOT NULL,
    numero          INT          NOT NULL,
    fecha           DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    metodo_pago     VARCHAR(10)  NOT NULL,
    subtotal        DECIMAL(10,2) NOT NULL,
    igv             DECIMAL(10,2) NOT NULL,
    total           DECIMAL(10,2) NOT NULL,
    UNIQUE (serie, numero),
    CONSTRAINT ck_comp_total  CHECK (total = subtotal + igv),
    CONSTRAINT ck_comp_metodo CHECK (metodo_pago IN ('EFECTIVO','YAPE','PLIN','TARJETA')),
    FOREIGN KEY (id_atencion) REFERENCES atencion(id_atencion),
    FOREIGN KEY (id_usuario)  REFERENCES usuario(id_usuario)
) ENGINE=InnoDB;

CREATE TABLE detalle_comprobante (
    id_detalle       INT AUTO_INCREMENT PRIMARY KEY,
    id_comprobante   INT          NOT NULL,
    id_servicio      INT          NULL,
    id_producto      INT          NULL,
    descripcion      VARCHAR(100) NOT NULL,
    cantidad         INT          NOT NULL,
    precio_unitario  DECIMAL(8,2) NOT NULL,
    subtotal         DECIMAL(10,2) NOT NULL,
    CONSTRAINT ck_det_uno CHECK ((id_servicio IS NULL) <> (id_producto IS NULL)),  -- servicio O producto
    CONSTRAINT ck_det_cant CHECK (cantidad > 0),
    FOREIGN KEY (id_comprobante) REFERENCES comprobante(id_comprobante),
    FOREIGN KEY (id_servicio)    REFERENCES servicio(id_servicio),
    FOREIGN KEY (id_producto)    REFERENCES producto(id_producto)
) ENGINE=InnoDB;

-- ---------------- Trigger: actualiza el stock en cada movimiento ----------------
DELIMITER $$
CREATE TRIGGER trg_mov_aplicar_stock BEFORE INSERT ON movimiento_inventario
FOR EACH ROW
BEGIN
    IF NEW.tipo = 'SALIDA' THEN
        IF (SELECT stock FROM producto WHERE id_producto = NEW.id_producto) < NEW.cantidad THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Stock insuficiente para la salida';
        END IF;
        UPDATE producto SET stock = stock - NEW.cantidad WHERE id_producto = NEW.id_producto;
    ELSE
        UPDATE producto SET stock = stock + NEW.cantidad WHERE id_producto = NEW.id_producto;
    END IF;
END$$
DELIMITER ;

-- ---------------- Vistas para reportes ----------------
CREATE VIEW vw_stock_critico AS
    SELECT codigo, nombre, stock, stock_minimo FROM producto
    WHERE activo = 1 AND stock <= stock_minimo;

CREATE VIEW vw_citas_detalle AS
    SELECT c.id_cita, c.fecha_hora, m.nombre AS mascota, cl.nombres AS cliente,
           u.nombre_completo AS veterinario, c.estado
    FROM cita c
    JOIN mascota m  ON m.id_mascota = c.id_mascota
    JOIN cliente cl ON cl.id_cliente = m.id_cliente
    JOIN usuario u  ON u.id_usuario = c.id_veterinario;

CREATE VIEW vw_ingresos_diarios AS
    SELECT DATE(fecha) AS dia, COUNT(*) AS comprobantes, SUM(total) AS ingresos
    FROM comprobante GROUP BY DATE(fecha);

-- ---------------- Usuario de la aplicación (mínimo privilegio, NO root) ----------------
CREATE USER IF NOT EXISTS 'vet_app'@'localhost' IDENTIFIED BY 'VetApp2026!';
GRANT SELECT, INSERT, UPDATE ON dr_sheep_vet.* TO 'vet_app'@'localhost';
FLUSH PRIVILEGES;

-- ---------------- Datos iniciales ----------------
INSERT INTO rol (nombre) VALUES ('Administrador'), ('Veterinario'), ('Recepcionista');

-- Contraseñas: admin / admin123   vet / vet123   recepcion / recep123
INSERT INTO usuario (id_rol, username, password_hash, nombre_completo) VALUES
(1, 'admin',     '65536:CnxAKbwCWNIEqpa5+osqFQ==:0RzsRvq57XbOEaPtBFTcKOCKg6vZ7izLtYjd4ic0DWk=', 'Administrador DR.SHEEP'),
(2, 'vet',       '65536:6bn0saemnnU3DSHfoy/tXA==:3TUV3cB6EEbfSy0f2rTKoRtBgFtXkfQvEXjGMVjxhVk=', 'Dr. Luis Paredes'),
(3, 'recepcion', '65536:J8s0aByTYZQq7hAplYvnNQ==:PpYZ60t0E90Tzrtq115au7ZITtEhHphG/JiWncfU5Q8=', 'Ana Torres');

INSERT INTO servicio (nombre, precio) VALUES
('Consulta general', 40.00), ('Vacunación', 35.00), ('Desparasitación', 25.00),
('Baño y corte', 45.00), ('Cirugía menor', 150.00);

INSERT INTO producto (codigo, nombre, precio, stock, stock_minimo) VALUES
('MED-001', 'Antibiótico (tableta)', 3.50, 40, 10),
('MED-002', 'Antiparasitario (tableta)', 2.50, 8, 10),
('INS-001', 'Jeringa descartable', 1.00, 100, 20),
('VAC-001', 'Vacuna quíntuple', 28.00, 12, 5);

INSERT INTO cliente (dni, nombres, telefono, direccion) VALUES
('45678901', 'Carlos Ramos',  '987654321', 'Av. Leoncio Prado 120, San Agustín de Cajas'),
('41234567', 'Lucía Quispe',  '912345678', 'Jr. Los Pinos 45, San Agustín de Cajas'),
('47890123', 'Pedro Huamán',  '956781234', 'Psje. Las Flores 8, San Agustín de Cajas');

INSERT INTO mascota (id_cliente, nombre, especie, raza, sexo, fecha_nacimiento, peso) VALUES
(1, 'Firulais', 'Perro', 'Mestizo',  'M', '2022-03-10', 12.50),
(2, 'Michi',    'Gato',  'Siamés',   'H', '2024-06-21',  4.20),
(3, 'Rocky',    'Perro', 'Labrador', 'M', '2020-01-15', 28.00);
