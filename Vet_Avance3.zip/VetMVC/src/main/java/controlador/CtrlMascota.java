package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import modelo.Atencion;
import modelo.Cliente;
import modelo.ConsultasMascota;
import modelo.Mascota;
import modelo.Usuario;
import util.Mensajes;
import util.SesionUsuario;
import vista.FrmMascota;

/**
 * CONTROLADOR - Clientes y mascotas. Escucha los botones de la Vista, valida los datos,
 * le pide al Modelo que guarde/consulte y actualiza la Vista con el resultado.
 */
public class CtrlMascota implements ActionListener {

    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final DateTimeFormatter FECHA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final ConsultasMascota consultas;   // Modelo
    private final FrmMascota frm;               // Vista
    private List<Mascota> mostradas = new ArrayList<>();

    public CtrlMascota(ConsultasMascota consultas, FrmMascota frm) {
        this.consultas = consultas;
        this.frm = frm;

        frm.btnGuardar.addActionListener(this);
        frm.btnModificar.addActionListener(this);
        frm.btnEliminar.addActionListener(this);
        frm.btnLimpiar.addActionListener(this);
        frm.btnBuscar.addActionListener(this);
        frm.btnTodos.addActionListener(this);
        frm.btnBuscarDni.addActionListener(this);
        frm.btnHistorial.addActionListener(this);

        frm.tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                seleccionarFila();
            }
        });
    }

    public void iniciar() {
        frm.setLocationRelativeTo(null);
        // El veterinario solo consulta: no registra ni modifica clientes/mascotas.
        Usuario u = SesionUsuario.getActual();
        if (u != null && u.getRol().equals(Usuario.VETERINARIO)) {
            frm.btnGuardar.setEnabled(false);
            frm.btnModificar.setEnabled(false);
            frm.btnEliminar.setEnabled(false);
        }
        cargarTabla(consultas.listar());
        if (consultas.getUltimoError() != null) {
            Mensajes.sinConexion(frm, consultas.getUltimoError());
            estado("Sin conexión a la base de datos.");
        } else {
            estado("Listo. " + mostradas.size() + " mascota(s) registrada(s).");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        if (o == frm.btnGuardar) {
            guardar();
        } else if (o == frm.btnModificar) {
            modificar();
        } else if (o == frm.btnEliminar) {
            eliminar();
        } else if (o == frm.btnLimpiar) {
            limpiar();
        } else if (o == frm.btnBuscar) {
            buscar();
        } else if (o == frm.btnTodos) {
            frm.txtBuscar.setText("");
            cargarTabla(consultas.listar());
            estado("Mostrando todas las mascotas.");
        } else if (o == frm.btnBuscarDni) {
            buscarDueno();
        } else if (o == frm.btnHistorial) {
            verHistorial();
        }
    }

    // ---------------- Operaciones ----------------

    private void guardar() {
        Mascota m = leerFormulario();
        if (m == null) {
            return;
        }
        if (consultas.insertar(m)) {
            limpiar();
            cargarTabla(consultas.listar());
            estado("Mascota registrada correctamente.");
        } else {
            Mensajes.error(frm, "No se pudo guardar:\n" + consultas.getUltimoError());
        }
    }

    private void modificar() {
        if (frm.txtId.getText().trim().isEmpty()) {
            Mensajes.aviso(frm, "Primero selecciona una mascota de la tabla.");
            return;
        }
        Mascota m = leerFormulario();
        if (m == null) {
            return;
        }
        m.setId(Integer.parseInt(frm.txtId.getText().trim()));
        if (consultas.modificar(m)) {
            limpiar();
            cargarTabla(consultas.listar());
            estado("Mascota modificada correctamente.");
        } else {
            Mensajes.error(frm, "No se pudo modificar:\n" + consultas.getUltimoError());
        }
    }

    private void eliminar() {
        if (frm.txtId.getText().trim().isEmpty()) {
            Mensajes.aviso(frm, "Primero selecciona una mascota de la tabla.");
            return;
        }
        if (!Mensajes.confirmar(frm, "¿Eliminar a \"" + frm.txtNombre.getText().trim()
                + "\"? (se conserva su historial)")) {
            return;
        }
        if (consultas.eliminar(Integer.parseInt(frm.txtId.getText().trim()))) {
            limpiar();
            cargarTabla(consultas.listar());
            estado("Mascota eliminada.");
        } else {
            Mensajes.error(frm, "No se pudo eliminar:\n" + consultas.getUltimoError());
        }
    }

    private void buscar() {
        String texto = frm.txtBuscar.getText().trim();
        if (texto.isEmpty()) {
            cargarTabla(consultas.listar());
            estado("Mostrando todas las mascotas.");
            return;
        }
        cargarTabla(consultas.buscar(texto));
        estado(mostradas.size() + " resultado(s) para \"" + texto + "\".");
    }

    private void buscarDueno() {
        String dni = frm.txtDni.getText().trim();
        if (!dni.matches("\\d{8}")) {
            Mensajes.aviso(frm, "El DNI debe tener 8 dígitos.");
            return;
        }
        Cliente c = consultas.buscarClientePorDni(dni);
        if (c == null) {
            estado("DNI no registrado: completa los datos del dueño y se registrará al guardar.");
            return;
        }
        frm.txtDueno.setText(c.getNombres());
        frm.txtTelefono.setText(c.getTelefono() == null ? "" : c.getTelefono());
        frm.txtDireccion.setText(c.getDireccion() == null ? "" : c.getDireccion());
        estado("Dueño encontrado: " + c.getNombres());
    }

    /** RF04: muestra el historial médico de la mascota seleccionada. */
    private void verHistorial() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0) {
            Mensajes.aviso(frm, "Selecciona una mascota de la tabla.");
            return;
        }
        Mascota m = mostradas.get(fila);
        List<Atencion> atenciones = consultas.historial(m.getId());
        StringBuilder sb = new StringBuilder();
        if (atenciones.isEmpty()) {
            sb.append("Esta mascota aún no tiene atenciones registradas.");
        }
        for (Atencion a : atenciones) {
            sb.append(a.getFecha().format(FECHA_HORA)).append('\n')
              .append("  Diagnóstico: ").append(a.getDiagnostico()).append('\n')
              .append("  Tratamiento: ").append(a.getTratamiento() == null ? "-" : a.getTratamiento())
              .append("\n\n");
        }
        JTextArea area = new JTextArea(sb.toString(), 14, 48);
        area.setEditable(false);
        javax.swing.JOptionPane.showMessageDialog(frm, new JScrollPane(area),
                "Historial médico de " + m.getNombre(), javax.swing.JOptionPane.PLAIN_MESSAGE);
    }

    // ---------------- Apoyo ----------------

    /** Lee y valida el formulario. Devuelve null (y avisa) si hay datos inválidos. */
    private Mascota leerFormulario() {
        String dni = frm.txtDni.getText().trim();
        String dueno = frm.txtDueno.getText().trim();
        String telefono = frm.txtTelefono.getText().trim();
        String nombre = frm.txtNombre.getText().trim();
        String especie = frm.txtEspecie.getText().trim();

        if (!dni.matches("\\d{8}")) {
            Mensajes.aviso(frm, "El DNI del dueño debe tener 8 dígitos.");
            return null;
        }
        if (dueno.isEmpty() || nombre.isEmpty() || especie.isEmpty()) {
            Mensajes.aviso(frm, "Nombre del dueño, nombre de la mascota y especie son obligatorios.");
            return null;
        }
        if (!telefono.isEmpty() && !telefono.matches("\\d{6,12}")) {
            Mensajes.aviso(frm, "El teléfono debe tener solo números (6 a 12 dígitos).");
            return null;
        }
        double peso;
        try {
            peso = Double.parseDouble(frm.txtPeso.getText().trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            Mensajes.aviso(frm, "El peso debe ser un número (ej. 12.5).");
            return null;
        }
        if (peso <= 0 || peso > 200) {
            Mensajes.aviso(frm, "El peso debe ser mayor que 0 y no más de 200 kg.");
            return null;
        }
        LocalDate nacimiento = null;
        String textoFecha = frm.txtNacimiento.getText().trim();
        if (!textoFecha.isEmpty()) {
            try {
                nacimiento = LocalDate.parse(textoFecha, FECHA);
            } catch (DateTimeParseException ex) {
                Mensajes.aviso(frm, "La fecha de nacimiento debe tener el formato aaaa-mm-dd (ej. 2022-03-10).");
                return null;
            }
            if (nacimiento.isAfter(LocalDate.now())) {
                Mensajes.aviso(frm, "La fecha de nacimiento no puede ser futura.");
                return null;
            }
        }

        Cliente c = new Cliente();
        c.setDni(dni);
        c.setNombres(dueno);
        c.setTelefono(telefono);
        c.setDireccion(frm.txtDireccion.getText().trim());

        Mascota m = new Mascota();
        m.setCliente(c);
        m.setNombre(nombre);
        m.setEspecie(especie);
        m.setRaza(frm.txtRaza.getText().trim());
        m.setSexo(frm.cmbSexo.getSelectedIndex() == 0 ? "M" : "H");
        m.setFechaNacimiento(nacimiento);
        m.setPeso(peso);
        return m;
    }

    private void cargarTabla(List<Mascota> lista) {
        mostradas = lista;
        frm.modeloTabla.setRowCount(0);
        for (Mascota m : lista) {
            Cliente c = m.getCliente();
            frm.modeloTabla.addRow(new Object[]{
                m.getId(), m.getNombre(), m.getEspecie(), m.getRaza(),
                m.getSexo().equals("M") ? "Macho" : "Hembra",
                m.getFechaNacimiento() == null ? "" : m.getFechaNacimiento().toString(),
                m.getPeso(), c.getDni(), c.getNombres(), c.getTelefono(), c.getDireccion()
            });
        }
    }

    private void seleccionarFila() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0 || fila >= mostradas.size()) {
            return;
        }
        Mascota m = mostradas.get(fila);
        Cliente c = m.getCliente();
        frm.txtId.setText(String.valueOf(m.getId()));
        frm.txtNombre.setText(m.getNombre());
        frm.txtEspecie.setText(m.getEspecie());
        frm.txtRaza.setText(m.getRaza() == null ? "" : m.getRaza());
        frm.cmbSexo.setSelectedIndex(m.getSexo().equals("M") ? 0 : 1);
        frm.txtNacimiento.setText(m.getFechaNacimiento() == null ? "" : m.getFechaNacimiento().toString());
        frm.txtPeso.setText(String.valueOf(m.getPeso()));
        frm.txtDni.setText(c.getDni());
        frm.txtDueno.setText(c.getNombres());
        frm.txtTelefono.setText(c.getTelefono() == null ? "" : c.getTelefono());
        frm.txtDireccion.setText(c.getDireccion() == null ? "" : c.getDireccion());
    }

    private void limpiar() {
        for (javax.swing.JTextField t : new javax.swing.JTextField[]{frm.txtId, frm.txtDni, frm.txtDueno,
            frm.txtTelefono, frm.txtDireccion, frm.txtNombre, frm.txtEspecie, frm.txtRaza,
            frm.txtNacimiento, frm.txtPeso}) {
            t.setText("");
        }
        frm.cmbSexo.setSelectedIndex(0);
        frm.tabla.clearSelection();
        frm.txtDni.requestFocus();
    }

    private void estado(String mensaje) {
        frm.lblEstado.setText("  " + mensaje);
    }
}
