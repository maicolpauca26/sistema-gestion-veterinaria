package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.ArrayList;
import java.util.List;
import modelo.Cita;
import modelo.ConsultasCita;
import modelo.ConsultasUsuario;
import modelo.Mascota;
import modelo.Usuario;
import util.Mensajes;
import util.SesionUsuario;
import vista.FrmCita;

/** CONTROLADOR - Agenda de citas: programar, confirmar, cancelar y registrar la atención (RF06 a RF08). */
public class CtrlCita implements ActionListener {

    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final ConsultasCita consultas;        // Modelo
    private final ConsultasUsuario usuarios;      // Modelo (lista de veterinarios)
    private final FrmCita frm;                    // Vista
    private List<Cita> mostradas = new ArrayList<>();

    public CtrlCita(ConsultasCita consultas, ConsultasUsuario usuarios, FrmCita frm) {
        this.consultas = consultas;
        this.usuarios = usuarios;
        this.frm = frm;

        frm.btnProgramar.addActionListener(this);
        frm.btnModificar.addActionListener(this);
        frm.btnConfirmar.addActionListener(this);
        frm.btnCancelar.addActionListener(this);
        frm.btnAtender.addActionListener(this);
        frm.btnLimpiar.addActionListener(this);
        frm.btnVerDia.addActionListener(this);
        frm.btnTodas.addActionListener(this);

        frm.tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                seleccionarFila();
            }
        });
    }

    public void iniciar() {
        frm.setLocationRelativeTo(null);

        // Permisos por rol: el veterinario atiende; recepción programa, confirma y cancela.
        String rol = SesionUsuario.getActual().getRol();
        boolean puedeAgendar = rol.equals(Usuario.ADMIN) || rol.equals(Usuario.RECEPCIONISTA);
        boolean puedeAtender = rol.equals(Usuario.ADMIN) || rol.equals(Usuario.VETERINARIO);
        frm.btnProgramar.setEnabled(puedeAgendar);
        frm.btnModificar.setEnabled(puedeAgendar);
        frm.btnConfirmar.setEnabled(puedeAgendar);
        frm.btnCancelar.setEnabled(puedeAgendar);
        frm.btnAtender.setEnabled(puedeAtender);

        frm.txtFiltroFecha.setText(LocalDate.now().format(FECHA));
        frm.txtFecha.setText(LocalDate.now().format(FECHA));
        for (Mascota m : consultas.listarMascotas()) {
            frm.cmbMascota.addItem(m);
        }
        for (Usuario v : usuarios.listarVeterinarios()) {
            frm.cmbVeterinario.addItem(v);
        }
        cargarTabla(consultas.listarTodas());
        if (consultas.getUltimoError() != null) {
            Mensajes.sinConexion(frm, consultas.getUltimoError());
            estado("Sin conexión a la base de datos.");
        } else {
            estado("Listo. " + mostradas.size() + " cita(s) registrada(s).");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        if (o == frm.btnProgramar) {
            programar();
        } else if (o == frm.btnModificar) {
            reprogramar();
        } else if (o == frm.btnConfirmar) {
            cambiarEstado(Cita.CONFIRMADA, "confirmada");
        } else if (o == frm.btnCancelar) {
            cambiarEstado(Cita.CANCELADA, "cancelada");
        } else if (o == frm.btnAtender) {
            atender();
        } else if (o == frm.btnLimpiar) {
            limpiar();
        } else if (o == frm.btnVerDia) {
            verDia();
        } else if (o == frm.btnTodas) {
            cargarTabla(consultas.listarTodas());
            estado("Mostrando todas las citas.");
        }
    }

    // ---------------- Operaciones ----------------

    private void programar() {
        Cita c = leerFormulario(0);
        if (c == null) {
            return;
        }
        if (consultas.insertar(c, SesionUsuario.getActual().getId())) {
            limpiar();
            cargarTabla(consultas.listarTodas());
            estado("Cita programada correctamente (estado PROGRAMADA).");
        } else {
            Mensajes.error(frm, "No se pudo programar:\n" + consultas.getUltimoError());
        }
    }

    private void reprogramar() {
        Cita actual = citaSeleccionada();
        if (actual == null) {
            return;
        }
        Cita c = leerFormulario(actual.getId());
        if (c == null) {
            return;
        }
        c.setId(actual.getId());
        if (consultas.modificar(c)) {
            limpiar();
            cargarTabla(consultas.listarTodas());
            estado("Cita reprogramada.");
        } else if (consultas.getUltimoError() != null) {
            Mensajes.error(frm, "No se pudo modificar:\n" + consultas.getUltimoError());
        } else {
            Mensajes.aviso(frm, "Solo se pueden modificar citas PROGRAMADAS o CONFIRMADAS.");
        }
    }

    private void cambiarEstado(String nuevoEstado, String texto) {
        Cita c = citaSeleccionada();
        if (c == null) {
            return;
        }
        if (consultas.cambiarEstado(c.getId(), nuevoEstado)) {
            limpiar();
            cargarTabla(consultas.listarTodas());
            estado("Cita " + texto + ".");
        } else if (consultas.getUltimoError() != null) {
            Mensajes.error(frm, "No se pudo actualizar:\n" + consultas.getUltimoError());
        } else {
            Mensajes.aviso(frm, "La cita está " + c.getEstado() + ": no se puede dejar como " + nuevoEstado + ".");
        }
    }

    private void atender() {
        Cita c = citaSeleccionada();
        if (c == null) {
            return;
        }
        String diagnostico = frm.txtDiagnostico.getText().trim();
        if (diagnostico.isEmpty()) {
            Mensajes.aviso(frm, "Escribe el diagnóstico para registrar la atención.");
            return;
        }
        if (consultas.atender(c.getId(), diagnostico, frm.txtTratamiento.getText().trim())) {
            limpiar();
            cargarTabla(consultas.listarTodas());
            estado("Atención registrada. La cita quedó ATENDIDA y ya se puede facturar.");
        } else {
            Mensajes.aviso(frm, "No se pudo registrar la atención:\n" + consultas.getUltimoError());
        }
    }

    private void verDia() {
        LocalDate dia;
        try {
            dia = LocalDate.parse(frm.txtFiltroFecha.getText().trim(), FECHA);
        } catch (DateTimeParseException ex) {
            Mensajes.aviso(frm, "La fecha debe tener el formato aaaa-mm-dd (ej. 2026-10-15).");
            return;
        }
        cargarTabla(consultas.listarPorFecha(dia));
        estado(mostradas.size() + " cita(s) el " + dia + ".");
    }

    // ---------------- Apoyo ----------------

    /** Lee y valida el formulario (mascota, veterinario, fecha, hora, motivo y cruce de horario). */
    private Cita leerFormulario(int idCitaExcluida) {
        Mascota mascota = (Mascota) frm.cmbMascota.getSelectedItem();
        Usuario vet = (Usuario) frm.cmbVeterinario.getSelectedItem();
        String motivo = frm.txtMotivo.getText().trim();
        if (mascota == null || vet == null) {
            Mensajes.aviso(frm, "Elige la mascota y el veterinario.");
            return null;
        }
        if (motivo.isEmpty()) {
            Mensajes.aviso(frm, "El motivo de la consulta es obligatorio.");
            return null;
        }
        LocalDateTime fechaHora;
        try {
            LocalDate fecha = LocalDate.parse(frm.txtFecha.getText().trim(), FECHA);
            fechaHora = LocalDateTime.of(fecha, LocalTime.parse((String) frm.cmbHora.getSelectedItem()));
        } catch (DateTimeParseException ex) {
            Mensajes.aviso(frm, "La fecha debe tener el formato aaaa-mm-dd (ej. 2026-10-15).");
            return null;
        }
        if (fechaHora.isBefore(LocalDateTime.now())) {
            Mensajes.aviso(frm, "No se puede programar una cita en el pasado.");
            return null;
        }
        if (consultas.horarioOcupado(vet.getId(), fechaHora, idCitaExcluida)) {
            if (consultas.getUltimoError() != null) {
                Mensajes.error(frm, "No se pudo verificar la disponibilidad:\n" + consultas.getUltimoError());
            } else {
                Mensajes.aviso(frm, vet.getNombreCompleto() + " ya tiene una cita a esa hora. Elige otro horario.");
            }
            return null;
        }
        Cita c = new Cita();
        c.setMascota(mascota);
        c.setVeterinario(vet);
        c.setFechaHora(fechaHora);
        c.setMotivo(motivo);
        return c;
    }

    private Cita citaSeleccionada() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0 || fila >= mostradas.size()) {
            Mensajes.aviso(frm, "Primero selecciona una cita de la tabla.");
            return null;
        }
        return mostradas.get(fila);
    }

    private void cargarTabla(List<Cita> lista) {
        mostradas = lista;
        frm.modeloTabla.setRowCount(0);
        for (Cita c : lista) {
            frm.modeloTabla.addRow(new Object[]{
                c.getId(), c.getFechaHora().toLocalDate(), c.getFechaHora().toLocalTime(),
                c.getMascota().getNombre(), c.getMascota().getCliente().getNombres(),
                c.getVeterinario().getNombreCompleto(), c.getMotivo(), c.getEstado()
            });
        }
    }

    private void seleccionarFila() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0 || fila >= mostradas.size()) {
            return;
        }
        Cita c = mostradas.get(fila);
        frm.txtId.setText(String.valueOf(c.getId()));
        frm.txtFecha.setText(c.getFechaHora().toLocalDate().toString());
        frm.cmbHora.setSelectedItem(c.getFechaHora().toLocalTime().toString());
        frm.txtMotivo.setText(c.getMotivo());
        for (int i = 0; i < frm.cmbMascota.getItemCount(); i++) {
            if (frm.cmbMascota.getItemAt(i).getId() == c.getMascota().getId()) {
                frm.cmbMascota.setSelectedIndex(i);
            }
        }
        for (int i = 0; i < frm.cmbVeterinario.getItemCount(); i++) {
            if (frm.cmbVeterinario.getItemAt(i).getId() == c.getVeterinario().getId()) {
                frm.cmbVeterinario.setSelectedIndex(i);
            }
        }
    }

    private void limpiar() {
        frm.txtId.setText("");
        frm.txtMotivo.setText("");
        frm.txtDiagnostico.setText("");
        frm.txtTratamiento.setText("");
        frm.txtFecha.setText(LocalDate.now().format(FECHA));
        frm.tabla.clearSelection();
    }

    private void estado(String mensaje) {
        frm.lblEstado.setText("  " + mensaje);
    }
}
