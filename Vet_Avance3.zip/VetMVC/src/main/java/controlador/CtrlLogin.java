package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import modelo.ConsultasUsuario;
import modelo.ConsultasUsuario.Resultado;
import util.Mensajes;
import util.SesionUsuario;
import vista.FrmLogin;
import vista.FrmPrincipal;

/** CONTROLADOR - Valida el inicio de sesión (RF01) y abre el menú principal. */
public class CtrlLogin implements ActionListener {

    private final ConsultasUsuario consultas;   // Modelo
    private final FrmLogin frm;                 // Vista

    public CtrlLogin(ConsultasUsuario consultas, FrmLogin frm) {
        this.consultas = consultas;
        this.frm = frm;
        frm.btnIngresar.addActionListener(this);
    }

    public void iniciar() {
        frm.setLocationRelativeTo(null);
        frm.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String usuario = frm.txtUsuario.getText().trim();
        String clave = new String(frm.txtClave.getPassword());
        if (usuario.isEmpty() || clave.isEmpty()) {
            frm.lblMensaje.setText("Ingresa tu usuario y contraseña.");
            return;
        }
        Resultado r = consultas.autenticar(usuario, clave);
        switch (r) {
            case OK:
                SesionUsuario.iniciar(consultas.getUsuarioAutenticado());
                FrmPrincipal principal = new FrmPrincipal();
                new CtrlPrincipal(principal).iniciar();
                frm.dispose();
                break;
            case BLOQUEADO:
                frm.lblMensaje.setText("Cuenta bloqueada (3 intentos fallidos). Habla con el administrador.");
                break;
            case ERROR_BD:
                Mensajes.sinConexion(frm, consultas.getUltimoError());
                frm.lblMensaje.setText("Sin conexión a la base de datos.");
                break;
            default:
                frm.lblMensaje.setText("Usuario o contraseña incorrectos.");
                break;
        }
        frm.txtClave.setText("");
    }
}
