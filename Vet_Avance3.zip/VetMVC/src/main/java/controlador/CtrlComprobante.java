package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.time.format.DateTimeFormatter;
import java.util.List;
import modelo.Atencion;
import modelo.Comprobante;
import modelo.ConsultasComprobante;
import modelo.ConsultasProducto;
import modelo.DetalleComprobante;
import modelo.Producto;
import modelo.Servicio;
import util.Mensajes;
import util.SesionUsuario;
import vista.FrmComprobante;

/** CONTROLADOR - Facturación: arma la boleta, calcula subtotal, IGV y total, y la emite (RF12 y RF13). */
public class CtrlComprobante implements ActionListener {

    private final ConsultasComprobante consultas;    // Modelo
    private final ConsultasProducto productos;       // Modelo (para los productos usados)
    private final FrmComprobante frm;                // Vista
    private Comprobante actual = new Comprobante();  // boleta en construcción

    public CtrlComprobante(ConsultasComprobante consultas, ConsultasProducto productos, FrmComprobante frm) {
        this.consultas = consultas;
        this.productos = productos;
        this.frm = frm;
        frm.btnAgregarServicio.addActionListener(this);
        frm.btnAgregarProducto.addActionListener(this);
        frm.btnQuitar.addActionListener(this);
        frm.btnEmitir.addActionListener(this);
        frm.btnLimpiar.addActionListener(this);
    }

    public void iniciar() {
        frm.setLocationRelativeTo(null);
        for (Servicio s : consultas.listarServicios()) {
            frm.cmbServicio.addItem(s);
        }
        if (consultas.getUltimoError() != null) {
            Mensajes.sinConexion(frm, consultas.getUltimoError());
            estado("Sin conexión a la base de datos.");
            return;
        }
        recargarListas();
        estado("Listo. Elige una atención y agrega servicios y productos.");
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        if (o == frm.btnAgregarServicio) {
            agregarServicio();
        } else if (o == frm.btnAgregarProducto) {
            agregarProducto();
        } else if (o == frm.btnQuitar) {
            quitarLinea();
        } else if (o == frm.btnEmitir) {
            emitir();
        } else if (o == frm.btnLimpiar) {
            limpiar();
        }
    }

    // ---------------- Operaciones ----------------

    private void agregarServicio() {
        Servicio s = (Servicio) frm.cmbServicio.getSelectedItem();
        if (s == null) {
            return;
        }
        int cantidad = (Integer) frm.spnServicio.getValue();
        actual.getDetalles().add(new DetalleComprobante(s.getId(), null, s.getNombre(), cantidad, s.getPrecio()));
        refrescarDetalle();
    }

    private void agregarProducto() {
        Producto p = (Producto) frm.cmbProducto.getSelectedItem();
        if (p == null) {
            return;
        }
        int cantidad = (Integer) frm.spnProducto.getValue();
        int yaAgregado = 0;
        for (DetalleComprobante d : actual.getDetalles()) {
            if (d.getIdProducto() != null && d.getIdProducto() == p.getId()) {
                yaAgregado += d.getCantidad();
            }
        }
        if (yaAgregado + cantidad > p.getStock()) {
            Mensajes.aviso(frm, "Stock insuficiente de " + p.getNombre() + ": hay " + p.getStock()
                    + " y ya agregaste " + yaAgregado + ".");
            return;
        }
        actual.getDetalles().add(new DetalleComprobante(null, p.getId(), p.getNombre(), cantidad, p.getPrecio()));
        refrescarDetalle();
    }

    private void quitarLinea() {
        int fila = frm.tablaDetalle.getSelectedRow();
        if (fila < 0) {
            Mensajes.aviso(frm, "Selecciona una línea del detalle para quitarla.");
            return;
        }
        actual.getDetalles().remove(fila);
        refrescarDetalle();
    }

    private void emitir() {
        Atencion a = (Atencion) frm.cmbAtencion.getSelectedItem();
        if (a == null) {
            Mensajes.aviso(frm, "No hay una atención seleccionada. Registra primero la atención en la agenda de citas.");
            return;
        }
        if (actual.getDetalles().isEmpty()) {
            Mensajes.aviso(frm, "Agrega al menos un servicio o producto.");
            return;
        }
        actual.setIdAtencion(a.getId());
        actual.setMetodoPago((String) frm.cmbPago.getSelectedItem());
        actual.calcularTotales();
        if (consultas.emitir(actual, SesionUsuario.getActual().getId())) {
            Mensajes.info(frm, "Boleta " + actual.getNumeroCompleto() + " emitida.\n"
                    + "Cliente: " + a.getCliente() + "\nTotal: S/ " + actual.getTotal()
                    + "  (" + actual.getMetodoPago() + ")");
            estado("Boleta " + actual.getNumeroCompleto() + " emitida correctamente.");
            limpiar();
            recargarListas();
        } else {
            Mensajes.error(frm, "No se pudo emitir el comprobante (no se guardó nada):\n" + consultas.getUltimoError());
        }
    }

    // ---------------- Apoyo ----------------

    private void refrescarDetalle() {
        frm.modeloDetalle.setRowCount(0);
        for (DetalleComprobante d : actual.getDetalles()) {
            frm.modeloDetalle.addRow(new Object[]{
                d.getDescripcion(), d.getCantidad(), d.getPrecioUnitario(), d.getSubtotal()
            });
        }
        actual.calcularTotales();
        frm.lblSubtotal.setText("S/ " + actual.getSubtotal());
        frm.lblIgv.setText("S/ " + actual.getIgv());
        frm.lblTotal.setText("S/ " + actual.getTotal());
    }

    /** Recarga las atenciones pendientes, los productos con su stock actual y los comprobantes emitidos. */
    private void recargarListas() {
        frm.cmbAtencion.removeAllItems();
        for (Atencion a : consultas.listarAtencionesPendientes()) {
            frm.cmbAtencion.addItem(a);
        }
        frm.cmbProducto.removeAllItems();
        for (Producto p : productos.listar()) {
            if (p.getStock() > 0) {
                frm.cmbProducto.addItem(p);
            }
        }
        DateTimeFormatter f = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");
        frm.modeloEmitidos.setRowCount(0);
        List<Comprobante> emitidos = consultas.listar();
        for (Comprobante c : emitidos) {
            frm.modeloEmitidos.addRow(new Object[]{
                c.getNumeroCompleto(), c.getFecha().format(f), c.getCliente(), c.getMetodoPago(),
                c.getSubtotal(), c.getIgv(), c.getTotal()
            });
        }
    }

    private void limpiar() {
        actual = new Comprobante();
        refrescarDetalle();
    }

    private void estado(String mensaje) {
        frm.lblEstado.setText("  " + mensaje);
    }
}
