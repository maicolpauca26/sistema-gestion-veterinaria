package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import modelo.ConsultasProducto;
import modelo.Producto;
import util.Mensajes;
import util.SesionUsuario;
import vista.FrmProducto;

/** CONTROLADOR - Inventario: productos, entradas, salidas y alerta de stock mínimo (RF09 a RF11). */
public class CtrlProducto implements ActionListener {

    private final ConsultasProducto consultas;   // Modelo
    private final FrmProducto frm;               // Vista
    private List<Producto> mostrados = new ArrayList<>();

    public CtrlProducto(ConsultasProducto consultas, FrmProducto frm) {
        this.consultas = consultas;
        this.frm = frm;

        frm.btnGuardar.addActionListener(this);
        frm.btnModificar.addActionListener(this);
        frm.btnEliminar.addActionListener(this);
        frm.btnLimpiar.addActionListener(this);
        frm.btnBuscar.addActionListener(this);
        frm.btnTodos.addActionListener(this);
        frm.btnCriticos.addActionListener(this);
        frm.btnEntrada.addActionListener(this);
        frm.btnSalida.addActionListener(this);

        frm.tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                seleccionarFila();
            }
        });
    }

    public void iniciar() {
        frm.setLocationRelativeTo(null);
        cargarTabla(consultas.listar());
        actualizarAlerta();
        if (consultas.getUltimoError() != null) {
            Mensajes.sinConexion(frm, consultas.getUltimoError());
            estado("Sin conexión a la base de datos.");
        } else {
            estado("Listo. " + mostrados.size() + " producto(s).");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        if (o == frm.btnGuardar) {
            guardar();
        } else if (o == frm.btnModificar) {
            modificar();
        } else if (o == frm.btnEliminar) {
            eliminar();
        } else if (o == frm.btnLimpiar) {
            limpiar();
        } else if (o == frm.btnBuscar) {
            buscar();
        } else if (o == frm.btnTodos) {
            frm.txtBuscar.setText("");
            cargarTabla(consultas.listar());
            estado("Mostrando todos los productos.");
        } else if (o == frm.btnCriticos) {
            cargarTabla(consultas.listarCriticos());
            estado(mostrados.size() + " producto(s) con stock crítico.");
        } else if (o == frm.btnEntrada) {
            movimiento("ENTRADA");
        } else if (o == frm.btnSalida) {
            movimiento("SALIDA");
        }
    }

    // ---------------- Operaciones ----------------

    private void guardar() {
        Producto p = leerFormulario();
        if (p == null) {
            return;
        }
        if (consultas.insertar(p)) {
            limpiar();
            recargar();
            estado("Producto registrado. Usa \"Registrar ENTRADA\" para darle stock.");
        } else {
            Mensajes.error(frm, "No se pudo guardar:\n" + consultas.getUltimoError());
        }
    }

    private void modificar() {
        Producto p = leerFormulario();
        if (p == null || !haySeleccion()) {
            return;
        }
        p.setId(Integer.parseInt(frm.txtId.getText().trim()));
        if (consultas.modificar(p)) {
            limpiar();
            recargar();
            estado("Producto modificado.");
        } else {
            Mensajes.error(frm, "No se pudo modificar:\n" + consultas.getUltimoError());
        }
    }

    private void eliminar() {
        if (!haySeleccion()) {
            return;
        }
        if (!Mensajes.confirmar(frm, "¿Eliminar \"" + frm.txtNombre.getText().trim() + "\"?")) {
            return;
        }
        if (consultas.eliminar(Integer.parseInt(frm.txtId.getText().trim()))) {
            limpiar();
            recargar();
            estado("Producto eliminado.");
        } else {
            Mensajes.error(frm, "No se pudo eliminar:\n" + consultas.getUltimoError());
        }
    }

    private void buscar() {
        String texto = frm.txtBuscar.getText().trim();
        cargarTabla(texto.isEmpty() ? consultas.listar() : consultas.buscar(texto));
        estado(mostrados.size() + " resultado(s).");
    }

    /** Entrada (compra) o salida (consumo) de stock. */
    private void movimiento(String tipo) {
        if (!haySeleccion()) {
            return;
        }
        int cantidad;
        try {
            cantidad = Integer.parseInt(frm.txtCantidad.getText().trim());
        } catch (NumberFormatException ex) {
            Mensajes.aviso(frm, "La cantidad debe ser un número entero.");
            return;
        }
        if (cantidad <= 0) {
            Mensajes.aviso(frm, "La cantidad debe ser mayor que 0.");
            return;
        }
        Producto elegido = mostrados.get(frm.tabla.getSelectedRow());
        if (tipo.equals("SALIDA") && cantidad > elegido.getStock()) {
            Mensajes.aviso(frm, "Stock insuficiente: solo hay " + elegido.getStock() + " unidad(es) de "
                    + elegido.getNombre() + ".");
            return;
        }
        if (consultas.registrarMovimiento(elegido.getId(), tipo, cantidad, SesionUsuario.getActual().getId())) {
            limpiar();
            recargar();
            estado(tipo + " de " + cantidad + " unidad(es) de " + elegido.getNombre() + " registrada.");
        } else {
            Mensajes.error(frm, "No se pudo registrar el movimiento:\n" + consultas.getUltimoError());
        }
    }

    // ---------------- Apoyo ----------------

    private Producto leerFormulario() {
        String codigo = frm.txtCodigo.getText().trim();
        String nombre = frm.txtNombre.getText().trim();
        if (codigo.isEmpty() || nombre.isEmpty()) {
            Mensajes.aviso(frm, "Código y nombre son obligatorios.");
            return null;
        }
        BigDecimal precio;
        int minimo;
        try {
            precio = new BigDecimal(frm.txtPrecio.getText().trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            Mensajes.aviso(frm, "El precio debe ser un número (ej. 3.50).");
            return null;
        }
        try {
            minimo = Integer.parseInt(frm.txtStockMinimo.getText().trim());
        } catch (NumberFormatException ex) {
            Mensajes.aviso(frm, "El stock mínimo debe ser un número entero.");
            return null;
        }
        if (precio.signum() < 0 || minimo < 0) {
            Mensajes.aviso(frm, "El precio y el stock mínimo no pueden ser negativos.");
            return null;
        }
        Producto p = new Producto();
        p.setCodigo(codigo);
        p.setNombre(nombre);
        p.setPrecio(precio);
        p.setStockMinimo(minimo);
        return p;
    }

    private boolean haySeleccion() {
        if (frm.txtId.getText().trim().isEmpty()) {
            Mensajes.aviso(frm, "Primero selecciona un producto de la tabla.");
            return false;
        }
        return true;
    }

    private void recargar() {
        cargarTabla(consultas.listar());
        actualizarAlerta();
    }

    /** RF11: muestra una alerta visible si hay productos en o por debajo del stock mínimo. */
    private void actualizarAlerta() {
        List<Producto> criticos = consultas.listarCriticos();
        if (criticos.isEmpty()) {
            frm.lblAlerta.setText(" ");
            return;
        }
        StringBuilder sb = new StringBuilder("  ⚠ ALERTA de stock mínimo: ");
        for (int i = 0; i < criticos.size(); i++) {
            sb.append(i > 0 ? ", " : "").append(criticos.get(i).getNombre())
              .append(" (").append(criticos.get(i).getStock()).append(')');
        }
        frm.lblAlerta.setText(sb.toString());
    }

    private void cargarTabla(List<Producto> lista) {
        mostrados = lista;
        frm.modeloTabla.setRowCount(0);
        for (Producto p : lista) {
            frm.modeloTabla.addRow(new Object[]{
                p.getId(), p.getCodigo(), p.getNombre(), p.getPrecio(), p.getStock(), p.getStockMinimo()
            });
        }
    }

    private void seleccionarFila() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0 || fila >= mostrados.size()) {
            return;
        }
        Producto p = mostrados.get(fila);
        frm.txtId.setText(String.valueOf(p.getId()));
        frm.txtCodigo.setText(p.getCodigo());
        frm.txtNombre.setText(p.getNombre());
        frm.txtPrecio.setText(p.getPrecio().toPlainString());
        frm.txtStockMinimo.setText(String.valueOf(p.getStockMinimo()));
        frm.txtStock.setText(String.valueOf(p.getStock()));
    }

    private void limpiar() {
        frm.txtId.setText("");
        frm.txtCodigo.setText("");
        frm.txtNombre.setText("");
        frm.txtPrecio.setText("");
        frm.txtStockMinimo.setText("");
        frm.txtStock.setText("");
        frm.txtCantidad.setText("");
        frm.tabla.clearSelection();
        frm.txtCodigo.requestFocus();
    }

    private void estado(String mensaje) {
        frm.lblEstado.setText("  " + mensaje);
    }
}
