package controlador;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import modelo.ConsultasCita;
import modelo.ConsultasComprobante;
import modelo.ConsultasMascota;
import modelo.ConsultasProducto;
import modelo.ConsultasUsuario;
import modelo.Usuario;
import util.SesionUsuario;
import vista.FrmCita;
import vista.FrmComprobante;
import vista.FrmLogin;
import vista.FrmMascota;
import vista.FrmPrincipal;
import vista.FrmProducto;

/**
 * CONTROLADOR - Menú principal. Habilita los módulos según el rol del usuario
 * y abre cada pantalla creando su trío Modelo - Vista - Controlador.
 */
public class CtrlPrincipal implements ActionListener {

    private final FrmPrincipal frm;
    private JFrame abierta;   // evita abrir dos veces la misma ventana

    public CtrlPrincipal(FrmPrincipal frm) {
        this.frm = frm;
        frm.btnMascotas.addActionListener(this);
        frm.btnCitas.addActionListener(this);
        frm.btnInventario.addActionListener(this);
        frm.btnFacturacion.addActionListener(this);
        frm.btnCerrarSesion.addActionListener(this);
    }

    public void iniciar() {
        Usuario u = SesionUsuario.getActual();
        frm.lblUsuario.setText(u.getNombreCompleto() + "  |  " + u.getRol());

        String rol = u.getRol();
        boolean admin = rol.equals(Usuario.ADMIN);
        boolean vet = rol.equals(Usuario.VETERINARIO);
        boolean recep = rol.equals(Usuario.RECEPCIONISTA);
        frm.btnMascotas.setEnabled(admin || vet || recep);
        frm.btnCitas.setEnabled(admin || vet || recep);
        frm.btnInventario.setEnabled(admin || vet);
        frm.btnFacturacion.setEnabled(admin || recep);

        frm.setLocationRelativeTo(null);
        frm.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object origen = e.getSource();
        if (origen == frm.btnMascotas) {
            FrmMascota v = new FrmMascota();
            abrir(v, () -> new CtrlMascota(new ConsultasMascota(), v).iniciar());
        } else if (origen == frm.btnCitas) {
            FrmCita v = new FrmCita();
            abrir(v, () -> new CtrlCita(new ConsultasCita(), new ConsultasUsuario(), v).iniciar());
        } else if (origen == frm.btnInventario) {
            FrmProducto v = new FrmProducto();
            abrir(v, () -> new CtrlProducto(new ConsultasProducto(), v).iniciar());
        } else if (origen == frm.btnFacturacion) {
            FrmComprobante v = new FrmComprobante();
            abrir(v, () -> new CtrlComprobante(new ConsultasComprobante(), new ConsultasProducto(), v).iniciar());
        } else if (origen == frm.btnCerrarSesion) {
            if (abierta != null) {
                abierta.dispose();
            }
            SesionUsuario.cerrar();
            frm.dispose();
            new CtrlLogin(new ConsultasUsuario(), new FrmLogin()).iniciar();
        }
    }

    /** Cierra la ventana de módulo anterior (si la hay) y muestra la nueva. */
    private void abrir(JFrame ventana, Runnable configurar) {
        if (abierta != null) {
            abierta.dispose();
        }
        abierta = ventana;
        configurar.run();
        ventana.setVisible(true);
    }
}
