package util;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;
import java.security.SecureRandom;
import java.util.Base64;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

/**
 * UTILITARIO - Cifrado de contraseñas (nunca se guarda texto plano).
 * Usa PBKDF2-HmacSHA256 incluido en el JDK (no necesita librerías externas).
 * Formato guardado en la BD:  iteraciones:sal(Base64):hash(Base64)
 */
public final class PasswordUtil {

    private static final int ITERACIONES = 65536;

    private PasswordUtil() {
    }

    public static String hash(String password) {
        byte[] sal = new byte[16];
        new SecureRandom().nextBytes(sal);
        byte[] h = derivar(password, sal, ITERACIONES);
        return ITERACIONES + ":" + Base64.getEncoder().encodeToString(sal)
                + ":" + Base64.getEncoder().encodeToString(h);
    }

    public static boolean verificar(String password, String guardado) {
        try {
            String[] p = guardado.split(":");
            int it = Integer.parseInt(p[0]);
            byte[] sal = Base64.getDecoder().decode(p[1]);
            byte[] esperado = Base64.getDecoder().decode(p[2]);
            return MessageDigest.isEqual(esperado, derivar(password, sal, it));
        } catch (RuntimeException e) {
            return false;
        }
    }

    private static byte[] derivar(String password, byte[] sal, int iteraciones) {
        try {
            PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), sal, iteraciones, 256);
            return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).getEncoded();
        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Utilidad para generar el hash de una contraseña: java -cp target/classes util.PasswordUtil clave */
    public static void main(String[] args) {
        System.out.println(hash(args.length > 0 ? args[0] : "admin123"));
    }
}
