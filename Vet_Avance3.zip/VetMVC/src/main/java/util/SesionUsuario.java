package util;

import modelo.Usuario;

/** UTILITARIO - Guarda el usuario que inició sesión (para saber su rol y su id). */
public final class SesionUsuario {

    private static Usuario actual;

    private SesionUsuario() {
    }

    public static void iniciar(Usuario u) { actual = u; }
    public static Usuario getActual() { return actual; }
    public static void cerrar() { actual = null; }
}
