package vetmvc;

import controlador.CtrlLogin;
import javax.swing.SwingUtilities;
import modelo.ConsultasUsuario;
import vista.FrmLogin;
import vista.Tema;

/**
 * Punto de entrada: abre el login. Después de iniciar sesión, el menú principal
 * crea el Modelo, la Vista y el Controlador de cada módulo y los conecta.
 */
public class Main {

    public static void main(String[] args) {
        Tema.instalar();   // colores y aspecto visual de DR.SHEEP (clase vista.Tema)

        SwingUtilities.invokeLater(() -> {
            ConsultasUsuario modelo = new ConsultasUsuario();
            FrmLogin vista = new FrmLogin();
            CtrlLogin controlador = new CtrlLogin(modelo, vista);
            controlador.iniciar();
        });
    }
}
