package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/** VISTA - Pantalla de inicio de sesión (P01). Solo interfaz, sin lógica. */
public class FrmLogin extends JFrame {

    private static final long serialVersionUID = 1L;

    public JTextField txtUsuario = new JTextField(16);
    public JPasswordField txtClave = new JPasswordField(16);
    public JButton btnIngresar = new JButton("Ingresar");
    public JLabel lblMensaje = new JLabel(" ");

    public FrmLogin() {
        super("DR.SHEEP - Iniciar sesión");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setIconImage(Tema.iconoVentana());
        setSize(800, 480);
        setResizable(false);

        JPanel raiz = new JPanel(new BorderLayout());

        // ---- Panel de marca (izquierda) ----
        JPanel marca = new JPanel(new BorderLayout()) {
            private static final long serialVersionUID = 1L;

            @Override
            protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                g.setPaint(new GradientPaint(0, 0, Tema.PRIMARIO_OSC, 0, getHeight(), Tema.PRIMARIO));
                g.fillRect(0, 0, getWidth(), getHeight());
                Tema.dibujarLogo(g, (getWidth() - 120) / 2, 90, 120);
                g.dispose();
            }
        };
        marca.setPreferredSize(new Dimension(330, 480));
        marca.setBorder(BorderFactory.createEmptyBorder(230, 24, 28, 24));
        JPanel textos = new JPanel();
        textos.setOpaque(false);
        textos.setLayout(new BoxLayout(textos, BoxLayout.Y_AXIS));
        JLabel nombre = new JLabel("DR.SHEEP");
        nombre.setFont(Tema.FUENTE_NEGRITA.deriveFont(Font.BOLD, 32f));
        nombre.setForeground(Color.WHITE);
        nombre.setAlignmentX(CENTER_ALIGNMENT);
        JLabel lema = new JLabel("Veterinaria · San Agustín de Cajas");
        lema.setFont(Tema.FUENTE.deriveFont(13f));
        lema.setForeground(new Color(204, 240, 235));
        lema.setAlignmentX(CENTER_ALIGNMENT);
        JLabel sistema = new JLabel("Sistema Integral de Gestión Veterinaria");
        sistema.setFont(Tema.FUENTE.deriveFont(11.5f));
        sistema.setForeground(new Color(170, 220, 214));
        sistema.setAlignmentX(CENTER_ALIGNMENT);
        textos.add(nombre);
        textos.add(Box.createVerticalStrut(4));
        textos.add(lema);
        textos.add(Box.createVerticalGlue());
        textos.add(sistema);
        marca.add(textos, BorderLayout.CENTER);
        raiz.add(marca, BorderLayout.WEST);

        // ---- Formulario (derecha) ----
        JPanel derecha = new JPanel();
        derecha.setBackground(Color.WHITE);
        derecha.setLayout(new BoxLayout(derecha, BoxLayout.Y_AXIS));
        derecha.setBorder(BorderFactory.createEmptyBorder(80, 56, 40, 56));

        JLabel titulo = new JLabel("Bienvenido");
        titulo.setFont(Tema.FUENTE_NEGRITA.deriveFont(Font.BOLD, 28f));
        titulo.setForeground(Tema.TEXTO);
        JLabel sub = new JLabel("Ingresa con tu usuario para continuar");
        sub.setFont(Tema.FUENTE.deriveFont(13f));
        sub.setForeground(Tema.SUAVE);

        JLabel etUsuario = Tema.et("USUARIO");
        JLabel etClave = Tema.et("CONTRASEÑA");
        for (JTextField t : new JTextField[]{txtUsuario, txtClave}) {
            t.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
            t.setPreferredSize(new Dimension(300, 40));
        }
        btnIngresar.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        btnIngresar.setPreferredSize(new Dimension(300, 42));
        Tema.primario(btnIngresar);
        lblMensaje.setForeground(Tema.PELIGRO);
        lblMensaje.setFont(Tema.FUENTE.deriveFont(12.5f));

        for (JLabel l : new JLabel[]{titulo, sub, etUsuario, etClave, lblMensaje}) {
            l.setAlignmentX(LEFT_ALIGNMENT);
        }
        for (JTextField t : new JTextField[]{txtUsuario, txtClave}) {
            t.setAlignmentX(LEFT_ALIGNMENT);
        }
        btnIngresar.setAlignmentX(LEFT_ALIGNMENT);

        derecha.add(titulo);
        derecha.add(Box.createVerticalStrut(4));
        derecha.add(sub);
        derecha.add(Box.createVerticalStrut(28));
        derecha.add(etUsuario);
        derecha.add(Box.createVerticalStrut(6));
        derecha.add(txtUsuario);
        derecha.add(Box.createVerticalStrut(16));
        derecha.add(etClave);
        derecha.add(Box.createVerticalStrut(6));
        derecha.add(txtClave);
        derecha.add(Box.createVerticalStrut(24));
        derecha.add(btnIngresar);
        derecha.add(Box.createVerticalStrut(12));
        derecha.add(lblMensaje);
        derecha.add(Box.createVerticalGlue());
        Tema.decorar(derecha);
        raiz.add(derecha, BorderLayout.CENTER);

        setContentPane(raiz);
        getRootPane().setDefaultButton(btnIngresar);   // Enter = Ingresar
    }
}
