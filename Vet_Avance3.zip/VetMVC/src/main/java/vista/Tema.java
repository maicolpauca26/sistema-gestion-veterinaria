package vista;

import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Cursor;
import java.awt.Dimension;
import java.awt.FontMetrics;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.Insets;
import java.awt.RenderingHints;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Path2D;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import javax.swing.AbstractButton;
import javax.swing.BorderFactory;
import javax.swing.ButtonModel;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.SwingConstants;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.border.LineBorder;
import javax.swing.plaf.FontUIResource;
import javax.swing.plaf.basic.BasicButtonUI;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.JTableHeader;

/**
 * VISTA - Tema visual de DR.SHEEP (colores, tipografía, botones, tarjetas, tablas e íconos).
 * Todo lo "bonito" vive aquí, en la capa Vista: los controladores y el modelo no lo conocen.
 * No usa librerías externas: solo Java Swing (Nimbus + dibujo propio).
 */
public final class Tema {

    // ---------- Paleta ----------
    public static final Color PRIMARIO = new Color(0x0F766E);
    public static final Color PRIMARIO_OSC = new Color(0x134E4A);
    public static final Color PRIMARIO_HOVER = new Color(0x14918A);
    public static final Color PRIMARIO_PRES = new Color(0x0B5F59);
    public static final Color FONDO = new Color(0xF1F5F4);
    public static final Color BORDE = new Color(0xD5DEDC);
    public static final Color TEXTO = new Color(0x1F2937);
    public static final Color SUAVE = new Color(0x6B7280);
    public static final Color PELIGRO = new Color(0xDC2626);
    public static final Color SELECCION = new Color(0xD5F2EE);
    public static final Color ZEBRA = new Color(0xF7FAF9);
    public static final Color DESHABILITADO = new Color(0xC5CFCD);

    public static final Font FUENTE = new Font("Segoe UI", Font.PLAIN, 13);
    public static final Font FUENTE_NEGRITA = FUENTE.deriveFont(Font.BOLD);

    /** Íconos dibujados con Java2D (no hacen falta imágenes). */
    public enum Icono { PATA, CALENDARIO, CAJA, BOLETA }

    private enum Variante { PRIMARIO, SECUNDARIO, PELIGRO }

    private Tema() {
    }

    /** Se llama una vez al arrancar (Main): instala Nimbus y los colores base. */
    public static void instalar() {
        UIManager.put("control", FONDO);
        UIManager.put("nimbusBase", new Color(0xAEBBB9));   // gris neutro: combos, spinners y barras de scroll
        UIManager.put("nimbusFocus", PRIMARIO_HOVER);
        UIManager.put("nimbusSelectionBackground", PRIMARIO);
        UIManager.put("nimbusLightBackground", Color.WHITE);
        UIManager.put("text", TEXTO);
        UIManager.put("defaultFont", new FontUIResource(FUENTE));
        try {
            for (UIManager.LookAndFeelInfo i : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(i.getName())) {
                    UIManager.setLookAndFeel(i.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException | InstantiationException | IllegalAccessException
                 | UnsupportedLookAndFeelException ignorada) {
            // si falla, Swing usa su aspecto por defecto
        }
    }

    // ---------- Piezas de pantalla ----------

    /** Etiqueta de formulario. */
    public static JLabel et(String texto) {
        JLabel l = new JLabel(texto);
        l.setFont(FUENTE_NEGRITA.deriveFont(12f));
        l.setForeground(SUAVE);
        return l;
    }

    /** Panel blanco con borde redondeado y un título pequeño arriba. */
    public static JPanel tarjeta(String titulo, JComponent contenido) {
        JPanel p = new JPanel(new java.awt.BorderLayout(0, 8));
        p.setBackground(Color.WHITE);
        p.putClientProperty("tarjeta", Boolean.TRUE);
        p.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDE, 1, true),
                BorderFactory.createEmptyBorder(10, 14, 12, 14)));
        if (titulo != null) {
            JLabel t = new JLabel(titulo.toUpperCase());
            t.setFont(FUENTE_NEGRITA.deriveFont(11f));
            t.setForeground(PRIMARIO);
            p.add(t, java.awt.BorderLayout.NORTH);
        }
        contenido.setOpaque(false);
        p.add(contenido, java.awt.BorderLayout.CENTER);
        return p;
    }

    /** Formulario de pares etiqueta/campo: la etiqueta ocupa poco y el campo el resto. */
    public static JPanel formulario(int pares, JComponent... componentes) {
        JPanel p = new JPanel(new java.awt.GridBagLayout());
        java.awt.GridBagConstraints gc = new java.awt.GridBagConstraints();
        gc.fill = java.awt.GridBagConstraints.HORIZONTAL;
        for (int i = 0; i < componentes.length; i++) {
            int celda = i / 2;
            boolean esCampo = i % 2 == 1;
            gc.gridx = (celda % pares) * 2 + (esCampo ? 1 : 0);
            gc.gridy = celda / pares;
            gc.weightx = esCampo ? 0.8 / pares : 0.2 / pares;
            gc.insets = new Insets(5, esCampo ? 0 : 0, 5, esCampo ? 14 : 10);
            p.add(componentes[i], gc);
        }
        return p;
    }

    /** Campo y botón en la misma fila (ej. DNI + Buscar). */
    public static JPanel fila(JComponent campo, JComponent boton) {
        JPanel p = new JPanel(new java.awt.BorderLayout(6, 0));
        p.setOpaque(false);
        p.add(campo, java.awt.BorderLayout.CENTER);
        p.add(boton, java.awt.BorderLayout.EAST);
        return p;
    }

    /** Tabla con borde, dentro de un scroll. */
    public static JScrollPane scroll(JTable t) {
        estilizarTabla(t);
        JScrollPane sp = new JScrollPane(t);
        sp.setBorder(new LineBorder(BORDE, 1, true));
        sp.getViewport().setBackground(Color.WHITE);
        return sp;
    }

    /** Arma la ventana: cabecera de color arriba y el cuerpo con márgenes. */
    public static void marco(JFrame f, String titulo, String subtitulo, Icono icono,
                             JComponent derecha, JComponent cuerpo) {
        f.setIconImage(iconoVentana());
        JPanel raiz = new JPanel(new java.awt.BorderLayout());
        raiz.setBackground(FONDO);
        raiz.add(cabecera(titulo, subtitulo, icono, derecha), java.awt.BorderLayout.NORTH);
        cuerpo.setBorder(BorderFactory.createEmptyBorder(14, 18, 14, 18));
        cuerpo.setOpaque(false);
        raiz.add(cuerpo, java.awt.BorderLayout.CENTER);
        decorar(raiz);
        f.setContentPane(raiz);
    }

    private static JPanel cabecera(String titulo, String subtitulo, Icono icono, JComponent derecha) {
        JPanel p = new JPanel(new java.awt.BorderLayout(14, 0)) {
            @Override
            protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                g.setPaint(new GradientPaint(0, 0, PRIMARIO_OSC, getWidth(), 0, PRIMARIO));
                g.fillRect(0, 0, getWidth(), getHeight());
                g.dispose();
            }
        };
        p.setOpaque(false);
        p.setBorder(BorderFactory.createEmptyBorder(12, 20, 12, 20));

        JComponent logo = new JComponent() {
            @Override
            protected void paintComponent(Graphics g0) {
                Graphics2D g = (Graphics2D) g0.create();
                suavizar(g);
                g.setColor(new Color(255, 255, 255, 40));
                g.fill(new Ellipse2D.Double(0, 0, 48, 48));
                dibujarIcono(g, icono, 10, 10, 28, Color.WHITE);
                g.dispose();
            }
        };
        logo.setPreferredSize(new Dimension(48, 48));
        p.add(logo, java.awt.BorderLayout.WEST);

        JPanel textos = new JPanel(new java.awt.GridLayout(2, 1));
        textos.setOpaque(false);
        JLabel t = new JLabel(titulo);
        t.setFont(FUENTE_NEGRITA.deriveFont(22f));
        t.setForeground(Color.WHITE);
        JLabel s = new JLabel(subtitulo == null ? " " : subtitulo);
        s.setFont(FUENTE.deriveFont(12.5f));
        s.setForeground(new Color(220, 245, 241));
        textos.add(t);
        textos.add(s);
        p.add(textos, java.awt.BorderLayout.CENTER);

        if (derecha != null) {
            p.add(derecha, java.awt.BorderLayout.EAST);
        }
        return p;
    }

    // ---------- Estilo de componentes ----------

    /** Recorre la ventana y da estilo a campos de texto, combos y spinners. */
    public static void decorar(Container c) {
        for (Component k : c.getComponents()) {
            if (k instanceof JTextField && !(k.getParent() instanceof JSpinner.DefaultEditor)) {
                JTextField t = (JTextField) k;
                t.setFont(FUENTE);
                t.setForeground(TEXTO);
                t.setBackground(t.isEditable() ? Color.WHITE : new Color(0xEEF2F1));
                t.setBorder(BorderFactory.createCompoundBorder(new LineBorder(BORDE, 1, true),
                        BorderFactory.createEmptyBorder(6, 9, 6, 9)));
            } else if (k instanceof JComboBox) {
                k.setFont(FUENTE);
            } else if (k instanceof JSpinner) {
                k.setFont(FUENTE);
            }
            if (k instanceof JPanel && ((JPanel) k).getClientProperty("tarjeta") == null) {
                ((JPanel) k).setOpaque(false);   // los paneles interiores dejan ver el blanco de la tarjeta
            }
            if (k instanceof Container) {
                decorar((Container) k);
            }
        }
    }

    public static void primario(JButton b) { b.setUI(new BotonUI(Variante.PRIMARIO)); }
    public static void secundario(JButton b) { b.setUI(new BotonUI(Variante.SECUNDARIO)); }
    public static void peligro(JButton b) { b.setUI(new BotonUI(Variante.PELIGRO)); }

    /** Convierte un botón en una tarjeta grande de menú con ícono y descripción. */
    public static void tarjetaMenu(JButton b, String descripcion, Icono icono) {
        b.putClientProperty("desc", descripcion);
        b.putClientProperty("icono", icono);
        b.setUI(new TarjetaUI());
    }

    public static void estilizarTabla(JTable t) {
        t.setRowHeight(30);
        t.setShowGrid(false);
        t.setIntercellSpacing(new Dimension(0, 0));
        t.setFont(FUENTE);
        t.setForeground(TEXTO);
        t.setFillsViewportHeight(true);
        t.setSelectionBackground(SELECCION);
        t.setSelectionForeground(TEXTO);
        t.setDefaultRenderer(Object.class, new CeldaRenderer());
        JTableHeader h = t.getTableHeader();
        h.setReorderingAllowed(false);
        h.setPreferredSize(new Dimension(100, 34));
        h.setDefaultRenderer((tabla, valor, sel, foco, fila, col) -> {
            JLabel l = new JLabel(String.valueOf(valor));
            l.setOpaque(true);
            l.setBackground(PRIMARIO_OSC);
            l.setForeground(Color.WHITE);
            l.setFont(FUENTE_NEGRITA.deriveFont(12f));
            l.setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
            return l;
        });
    }

    /** Celdas con filas alternadas y selección suave. Se puede heredar para colorear una columna. */
    public static class CeldaRenderer extends DefaultTableCellRenderer {
        private static final long serialVersionUID = 1L;

        @Override
        public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foco,
                                                       int fila, int col) {
            super.getTableCellRendererComponent(t, v, sel, false, fila, col);
            setBorder(BorderFactory.createEmptyBorder(0, 10, 0, 10));
            setForeground(TEXTO);
            setBackground(sel ? SELECCION : (fila % 2 == 0 ? Color.WHITE : ZEBRA));
            return this;
        }
    }

    // ---------- Dibujo ----------

    static void suavizar(Graphics2D g) {
        g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
        g.setRenderingHint(RenderingHints.KEY_TEXT_ANTIALIASING, RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
    }

    /** Dibuja un ícono sencillo dentro de un cuadrado de lado s. */
    public static void dibujarIcono(Graphics2D g, Icono icono, double x, double y, double s, Color c) {
        g.setColor(c);
        g.setStroke(new BasicStroke((float) (s * 0.08), BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
        switch (icono) {
            case PATA:
                g.fill(new Ellipse2D.Double(x + s * 0.27, y + s * 0.50, s * 0.46, s * 0.38));
                g.fill(new Ellipse2D.Double(x + s * 0.06, y + s * 0.38, s * 0.20, s * 0.26));
                g.fill(new Ellipse2D.Double(x + s * 0.27, y + s * 0.10, s * 0.20, s * 0.28));
                g.fill(new Ellipse2D.Double(x + s * 0.53, y + s * 0.10, s * 0.20, s * 0.28));
                g.fill(new Ellipse2D.Double(x + s * 0.74, y + s * 0.38, s * 0.20, s * 0.26));
                break;
            case CALENDARIO:
                g.draw(new RoundRectangle2D.Double(x + s * 0.12, y + s * 0.20, s * 0.76, s * 0.68, s * 0.14, s * 0.14));
                g.fill(new RoundRectangle2D.Double(x + s * 0.12, y + s * 0.20, s * 0.76, s * 0.20, s * 0.14, s * 0.14));
                g.fill(new RoundRectangle2D.Double(x + s * 0.28, y + s * 0.07, s * 0.08, s * 0.22, 3, 3));
                g.fill(new RoundRectangle2D.Double(x + s * 0.64, y + s * 0.07, s * 0.08, s * 0.22, 3, 3));
                for (int i = 0; i < 3; i++) {
                    for (int j = 0; j < 2; j++) {
                        g.fill(new RoundRectangle2D.Double(x + s * (0.24 + 0.20 * i), y + s * (0.52 + 0.18 * j),
                                s * 0.12, s * 0.10, 2, 2));
                    }
                }
                break;
            case CAJA:
                g.fill(new RoundRectangle2D.Double(x + s * 0.06, y + s * 0.16, s * 0.88, s * 0.22, s * 0.08, s * 0.08));
                g.draw(new RoundRectangle2D.Double(x + s * 0.12, y + s * 0.38, s * 0.76, s * 0.50, s * 0.08, s * 0.08));
                g.draw(new java.awt.geom.Line2D.Double(x + s * 0.38, y + s * 0.52, x + s * 0.62, y + s * 0.52));
                break;
            case BOLETA:
            default:
                Path2D.Double p = new Path2D.Double();
                p.moveTo(x + s * 0.20, y + s * 0.08);
                p.lineTo(x + s * 0.80, y + s * 0.08);
                p.lineTo(x + s * 0.80, y + s * 0.92);
                for (int i = 0; i < 3; i++) {
                    p.lineTo(x + s * (0.80 - 0.20 * (i + 0.5)), y + s * 0.84);
                    p.lineTo(x + s * (0.80 - 0.20 * (i + 1)), y + s * 0.92);
                }
                p.closePath();
                g.draw(p);
                for (int i = 0; i < 3; i++) {
                    g.draw(new java.awt.geom.Line2D.Double(x + s * 0.32, y + s * (0.28 + 0.16 * i),
                            x + s * (i == 2 ? 0.52 : 0.68), y + s * (0.28 + 0.16 * i)));
                }
                break;
        }
    }

    /** Ícono de la ventana (patita blanca sobre círculo verde). */
    public static Image iconoVentana() {
        BufferedImage img = new BufferedImage(64, 64, BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = img.createGraphics();
        suavizar(g);
        g.setColor(PRIMARIO);
        g.fillOval(0, 0, 64, 64);
        dibujarIcono(g, Icono.PATA, 12, 12, 40, Color.WHITE);
        g.dispose();
        return img;
    }

    /** Logo grande del login: círculo con la patita. */
    public static void dibujarLogo(Graphics2D g, int x, int y, int d) {
        suavizar(g);
        g.setColor(new Color(255, 255, 255, 45));
        g.fill(new Ellipse2D.Double(x, y, d, d));
        dibujarIcono(g, Icono.PATA, x + d * 0.22, y + d * 0.22, d * 0.56, Color.WHITE);
    }

    // ---------- Botones ----------

    private static final class BotonUI extends BasicButtonUI {
        private final Variante variante;

        BotonUI(Variante v) {
            this.variante = v;
        }

        @Override
        public void installUI(JComponent c) {
            super.installUI(c);
            AbstractButton b = (AbstractButton) c;
            b.setOpaque(false);
            b.setBorder(BorderFactory.createEmptyBorder(9, 18, 9, 18));
            b.setFocusPainted(false);
            b.setRolloverEnabled(true);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            b.setFont(FUENTE_NEGRITA);
        }

        @Override
        public void paint(Graphics g0, JComponent c) {
            Graphics2D g = (Graphics2D) g0.create();
            suavizar(g);
            AbstractButton b = (AbstractButton) c;
            ButtonModel m = b.getModel();
            boolean on = b.isEnabled();
            Color fondo;
            Color borde;
            Color texto;
            switch (variante) {
                case PRIMARIO:
                    fondo = !on ? DESHABILITADO : m.isPressed() ? PRIMARIO_PRES : m.isRollover() ? PRIMARIO_HOVER : PRIMARIO;
                    borde = fondo;
                    texto = Color.WHITE;
                    break;
                case PELIGRO:
                    fondo = m.isPressed() ? new Color(0xFECACA) : m.isRollover() ? new Color(0xFEE2E2) : Color.WHITE;
                    borde = on ? PELIGRO : DESHABILITADO;
                    texto = on ? PELIGRO : new Color(0x9AA7A5);
                    break;
                default:
                    fondo = m.isPressed() ? SELECCION : m.isRollover() ? new Color(0xEAF6F4) : Color.WHITE;
                    borde = on ? PRIMARIO : DESHABILITADO;
                    texto = on ? PRIMARIO : new Color(0x9AA7A5);
                    break;
            }
            int w = c.getWidth();
            int h = c.getHeight();
            g.setColor(fondo);
            g.fillRoundRect(0, 0, w - 1, h - 1, 12, 12);
            g.setColor(borde);
            g.drawRoundRect(0, 0, w - 1, h - 1, 12, 12);
            g.setFont(b.getFont());
            FontMetrics fm = g.getFontMetrics();
            String t = b.getText();
            g.setColor(texto);
            g.drawString(t, (w - fm.stringWidth(t)) / 2, (h - fm.getHeight()) / 2 + fm.getAscent());
            g.dispose();
        }

        @Override
        public Dimension getPreferredSize(JComponent c) {
            AbstractButton b = (AbstractButton) c;
            FontMetrics fm = b.getFontMetrics(b.getFont());
            Insets i = b.getInsets();
            return new Dimension(fm.stringWidth(b.getText()) + i.left + i.right, fm.getHeight() + i.top + i.bottom);
        }
    }

    // ---------- Tarjetas del menú ----------

    private static final class TarjetaUI extends BasicButtonUI {

        @Override
        public void installUI(JComponent c) {
            super.installUI(c);
            AbstractButton b = (AbstractButton) c;
            b.setOpaque(false);
            b.setBorder(BorderFactory.createEmptyBorder(16, 18, 16, 18));
            b.setFocusPainted(false);
            b.setRolloverEnabled(true);
            b.setHorizontalAlignment(SwingConstants.LEFT);
            b.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        }

        @Override
        public void paint(Graphics g0, JComponent c) {
            Graphics2D g = (Graphics2D) g0.create();
            suavizar(g);
            AbstractButton b = (AbstractButton) c;
            boolean on = b.isEnabled();
            boolean hover = on && b.getModel().isRollover();
            int w = c.getWidth();
            int h = c.getHeight();

            g.setColor(on ? Color.WHITE : new Color(0xE9EEED));
            g.fillRoundRect(0, 0, w - 1, h - 1, 18, 18);
            g.setColor(hover ? PRIMARIO : BORDE);
            g.setStroke(new BasicStroke(hover ? 2f : 1f));
            g.drawRoundRect(0, 0, w - 1, h - 1, 18, 18);

            int d = 60;
            int cy = (h - d) / 2;
            g.setColor(on ? SELECCION : new Color(0xDDE4E3));
            g.fill(new Ellipse2D.Double(20, cy, d, d));
            dibujarIcono(g, (Icono) b.getClientProperty("icono"), 20 + d * 0.22, cy + d * 0.22, d * 0.56,
                    on ? PRIMARIO : new Color(0x9AA7A5));

            int tx = 20 + d + 18;
            g.setFont(FUENTE_NEGRITA.deriveFont(17f));
            FontMetrics fm = g.getFontMetrics();
            int y = cy + fm.getAscent() - 2;
            g.setColor(on ? TEXTO : new Color(0x8A9795));
            g.drawString(b.getText(), tx, y);

            String desc = on ? String.valueOf(b.getClientProperty("desc")) : "Sin acceso para tu rol";
            g.setFont(FUENTE.deriveFont(12.5f));
            fm = g.getFontMetrics();
            g.setColor(SUAVE);
            y += 22;
            for (String linea : partir(desc, fm, w - tx - 16)) {
                g.drawString(linea, tx, y);
                y += fm.getHeight();
            }
            g.dispose();
        }

        private List<String> partir(String texto, FontMetrics fm, int ancho) {
            List<String> lineas = new ArrayList<>();
            StringBuilder actual = new StringBuilder();
            for (String palabra : texto.split(" ")) {
                String prueba = actual.length() == 0 ? palabra : actual + " " + palabra;
                if (fm.stringWidth(prueba) > ancho && actual.length() > 0) {
                    lineas.add(actual.toString());
                    actual = new StringBuilder(palabra);
                } else {
                    actual = new StringBuilder(prueba);
                }
            }
            lineas.add(actual.toString());
            return lineas;
        }

        @Override
        public Dimension getPreferredSize(JComponent c) {
            return new Dimension(300, 128);
        }
    }
}
