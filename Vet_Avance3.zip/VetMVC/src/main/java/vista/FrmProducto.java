package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableCellRenderer;

/** VISTA - Inventario (P06). Solo interfaz, sin lógica ni consultas. */
public class FrmProducto extends JFrame {

    private static final long serialVersionUID = 1L;

    public JTextField txtId = new JTextField();
    public JTextField txtCodigo = new JTextField();
    public JTextField txtNombre = new JTextField();
    public JTextField txtPrecio = new JTextField();
    public JTextField txtStockMinimo = new JTextField();
    public JTextField txtStock = new JTextField();
    public JTextField txtCantidad = new JTextField();

    public JTextField txtBuscar = new JTextField(20);
    public JButton btnBuscar = new JButton("Buscar");
    public JButton btnTodos = new JButton("Mostrar todos");
    public JButton btnCriticos = new JButton("Ver stock crítico");

    public JButton btnGuardar = new JButton("Guardar");
    public JButton btnModificar = new JButton("Modificar");
    public JButton btnEliminar = new JButton("Eliminar");
    public JButton btnLimpiar = new JButton("Limpiar");
    public JButton btnEntrada = new JButton("Registrar ENTRADA");
    public JButton btnSalida = new JButton("Registrar SALIDA");

    public JLabel lblAlerta = new JLabel(" ");
    public JLabel lblEstado = new JLabel(" ");
    public DefaultTableModel modeloTabla;
    public JTable tabla;

    public FrmProducto() {
        super("DR.SHEEP - Inventario");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1120, 740);

        txtId.setEditable(false);
        txtStock.setEditable(false);
        lblAlerta.setForeground(Tema.PELIGRO);
        lblAlerta.setFont(Tema.FUENTE_NEGRITA);
        Tema.primario(btnBuscar);
        Tema.secundario(btnTodos);
        Tema.peligro(btnCriticos);
        Tema.primario(btnGuardar);
        Tema.secundario(btnModificar);
        Tema.peligro(btnEliminar);
        Tema.secundario(btnLimpiar);
        Tema.secundario(btnEntrada);
        Tema.secundario(btnSalida);

        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        busqueda.add(Tema.et("CÓDIGO O NOMBRE"));
        busqueda.add(txtBuscar);
        busqueda.add(btnBuscar);
        busqueda.add(btnTodos);
        busqueda.add(btnCriticos);
        JPanel bloqueBusqueda = new JPanel(new BorderLayout(0, 6));
        bloqueBusqueda.add(busqueda, BorderLayout.CENTER);
        bloqueBusqueda.add(lblAlerta, BorderLayout.SOUTH);

        JPanel form = new JPanel(new GridLayout(4, 4, 10, 10));
        form.add(Tema.et("ID"));
        form.add(txtId);
        form.add(Tema.et("Código"));
        form.add(txtCodigo);
        form.add(Tema.et("Nombre"));
        form.add(txtNombre);
        form.add(Tema.et("Precio (S/)"));
        form.add(txtPrecio);
        form.add(Tema.et("Stock mínimo"));
        form.add(txtStockMinimo);
        form.add(Tema.et("Stock actual"));
        form.add(txtStock);
        form.add(Tema.et("Cantidad del movimiento"));
        form.add(txtCantidad);
        form.add(new JLabel());
        form.add(new JLabel());

        JPanel norte = new JPanel(new BorderLayout(0, 12));
        norte.setOpaque(false);
        norte.add(Tema.tarjeta("Búsqueda y alertas", bloqueBusqueda), BorderLayout.NORTH);
        norte.add(Tema.tarjeta("Datos del producto", form), BorderLayout.CENTER);

        String[] columnas = {"ID", "Código", "Producto", "Precio (S/)", "Stock", "Mínimo"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new JTable(modeloTabla) {
            private static final long serialVersionUID = 1L;

            // Fila en rojo cuando stock <= mínimo (alerta visible)
            @Override
            public Component prepareRenderer(TableCellRenderer r, int fila, int col) {
                Component c = super.prepareRenderer(r, fila, col);
                if (!isRowSelected(fila)) {
                    int stock = Integer.parseInt(getValueAt(fila, 4).toString());
                    int min = Integer.parseInt(getValueAt(fila, 5).toString());
                    boolean critico = stock <= min;
                    c.setForeground(critico ? Tema.PELIGRO : Tema.TEXTO);
                    c.setFont(critico ? Tema.FUENTE_NEGRITA : Tema.FUENTE);
                    if (critico) {
                        c.setBackground(new Color(0xFEF2F2));
                    }
                }
                return c;
            }
        };
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botones.setOpaque(false);
        botones.add(btnGuardar);
        botones.add(btnModificar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);
        botones.add(btnEntrada);
        botones.add(btnSalida);
        lblEstado.setForeground(Tema.SUAVE);
        JPanel sur = new JPanel(new BorderLayout());
        sur.setOpaque(false);
        sur.add(lblEstado, BorderLayout.WEST);
        sur.add(botones, BorderLayout.EAST);

        JPanel cuerpo = new JPanel(new BorderLayout(0, 12));
        cuerpo.add(norte, BorderLayout.NORTH);
        cuerpo.add(Tema.scroll(tabla), BorderLayout.CENTER);
        cuerpo.add(sur, BorderLayout.SOUTH);

        Tema.marco(this, "Inventario", "Productos, entradas, salidas y alertas de stock mínimo",
                Tema.Icono.CAJA, null, cuerpo);
    }
}
