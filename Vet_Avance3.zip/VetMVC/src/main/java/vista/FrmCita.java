package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;
import modelo.Cita;
import modelo.Mascota;
import modelo.Usuario;

/** VISTA - Agenda de citas (P05). Solo interfaz, sin lógica ni consultas. */
public class FrmCita extends JFrame {

    private static final long serialVersionUID = 1L;

    public JTextField txtId = new JTextField();
    public JComboBox<Mascota> cmbMascota = new JComboBox<>();
    public JComboBox<Usuario> cmbVeterinario = new JComboBox<>();
    public JTextField txtFecha = new JTextField();
    public JComboBox<String> cmbHora = new JComboBox<>();
    public JTextField txtMotivo = new JTextField();
    public JTextField txtDiagnostico = new JTextField();
    public JTextField txtTratamiento = new JTextField();

    public JTextField txtFiltroFecha = new JTextField(10);
    public JButton btnVerDia = new JButton("Ver día");
    public JButton btnTodas = new JButton("Ver todas");

    public JButton btnProgramar = new JButton("Programar");
    public JButton btnModificar = new JButton("Reprogramar");
    public JButton btnConfirmar = new JButton("Confirmar");
    public JButton btnCancelar = new JButton("Cancelar cita");
    public JButton btnAtender = new JButton("Registrar atención");
    public JButton btnLimpiar = new JButton("Limpiar");

    public JLabel lblEstado = new JLabel(" ");
    public DefaultTableModel modeloTabla;
    public JTable tabla;

    public FrmCita() {
        super("DR.SHEEP - Agenda de citas");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1120, 740);

        txtId.setEditable(false);
        for (int h = 8; h <= 19; h++) {
            cmbHora.addItem(String.format("%02d:00", h));
            cmbHora.addItem(String.format("%02d:30", h));
        }
        Tema.secundario(btnVerDia);
        Tema.secundario(btnTodas);
        Tema.primario(btnProgramar);
        Tema.secundario(btnModificar);
        Tema.secundario(btnConfirmar);
        Tema.peligro(btnCancelar);
        Tema.primario(btnAtender);
        Tema.secundario(btnLimpiar);

        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
        filtro.add(Tema.et("FECHA (aaaa-mm-dd)"));
        filtro.add(txtFiltroFecha);
        filtro.add(btnVerDia);
        filtro.add(btnTodas);

        JPanel form = new JPanel(new GridLayout(4, 4, 10, 10));
        form.add(Tema.et("ID"));
        form.add(txtId);
        form.add(Tema.et("Mascota"));
        form.add(cmbMascota);
        form.add(Tema.et("Veterinario"));
        form.add(cmbVeterinario);
        form.add(Tema.et("Motivo"));
        form.add(txtMotivo);
        form.add(Tema.et("Fecha (aaaa-mm-dd)"));
        form.add(txtFecha);
        form.add(Tema.et("Hora"));
        form.add(cmbHora);
        form.add(Tema.et("Diagnóstico (atención)"));
        form.add(txtDiagnostico);
        form.add(Tema.et("Tratamiento (atención)"));
        form.add(txtTratamiento);

        JPanel norte = new JPanel(new BorderLayout(0, 12));
        norte.setOpaque(false);
        norte.add(Tema.tarjeta("Ver agenda", filtro), BorderLayout.NORTH);
        norte.add(Tema.tarjeta("Datos de la cita", form), BorderLayout.CENTER);

        String[] columnas = {"ID", "Fecha", "Hora", "Mascota", "Dueño", "Veterinario", "Motivo", "Estado"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        Tema.estilizarTabla(tabla);
        // Color de la columna Estado
        tabla.getColumnModel().getColumn(7).setCellRenderer(new Tema.CeldaRenderer() {
            private static final long serialVersionUID = 1L;

            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foco,
                                                           int fila, int col) {
                Component c = super.getTableCellRendererComponent(t, v, sel, foco, fila, col);
                String e = String.valueOf(v);
                c.setFont(Tema.FUENTE_NEGRITA);
                c.setForeground(e.equals(Cita.CANCELADA) ? Tema.PELIGRO
                        : e.equals(Cita.ATENDIDA) ? new Color(0x15803D)
                        : e.equals(Cita.CONFIRMADA) ? new Color(0x1D4ED8) : new Color(0xB45309));
                return c;
            }
        });

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botones.setOpaque(false);
        botones.add(btnProgramar);
        botones.add(btnModificar);
        botones.add(btnConfirmar);
        botones.add(btnCancelar);
        botones.add(btnAtender);
        botones.add(btnLimpiar);
        lblEstado.setForeground(Tema.SUAVE);
        JPanel sur = new JPanel(new BorderLayout());
        sur.setOpaque(false);
        sur.add(lblEstado, BorderLayout.WEST);
        sur.add(botones, BorderLayout.EAST);

        JPanel cuerpo = new JPanel(new BorderLayout(0, 12));
        cuerpo.add(norte, BorderLayout.NORTH);
        cuerpo.add(Tema.scroll(tabla), BorderLayout.CENTER);
        cuerpo.add(sur, BorderLayout.SOUTH);

        Tema.marco(this, "Agenda de citas", "Programa, confirma, cancela y atiende las citas",
                Tema.Icono.CALENDARIO, null, cuerpo);
    }
}
