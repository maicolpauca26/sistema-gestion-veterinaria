package vista;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import modelo.Atencion;
import modelo.Producto;
import modelo.Servicio;

/** VISTA - Facturación (P07). Solo interfaz, sin lógica ni consultas. */
public class FrmComprobante extends JFrame {

    private static final long serialVersionUID = 1L;

    public JComboBox<Atencion> cmbAtencion = new JComboBox<>();
    public JComboBox<Servicio> cmbServicio = new JComboBox<>();
    public JSpinner spnServicio = new JSpinner(new SpinnerNumberModel(1, 1, 99, 1));
    public JButton btnAgregarServicio = new JButton("Agregar servicio");
    public JComboBox<Producto> cmbProducto = new JComboBox<>();
    public JSpinner spnProducto = new JSpinner(new SpinnerNumberModel(1, 1, 999, 1));
    public JButton btnAgregarProducto = new JButton("Agregar producto");

    public JComboBox<String> cmbPago = new JComboBox<>(new String[]{"EFECTIVO", "YAPE", "PLIN", "TARJETA"});
    public JLabel lblSubtotal = new JLabel("S/ 0.00");
    public JLabel lblIgv = new JLabel("S/ 0.00");
    public JLabel lblTotal = new JLabel("S/ 0.00");

    public JButton btnQuitar = new JButton("Quitar línea");
    public JButton btnEmitir = new JButton("Emitir comprobante");
    public JButton btnLimpiar = new JButton("Limpiar");

    public JLabel lblEstado = new JLabel(" ");
    public DefaultTableModel modeloDetalle;
    public JTable tablaDetalle;
    public DefaultTableModel modeloEmitidos;
    public JTable tablaEmitidos;

    public FrmComprobante() {
        super("DR.SHEEP - Facturación");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1120, 780);

        Tema.secundario(btnAgregarServicio);
        Tema.secundario(btnAgregarProducto);
        Tema.secundario(btnQuitar);
        Tema.primario(btnEmitir);
        Tema.secundario(btnLimpiar);

        // Selección
        JPanel selector = new JPanel(new GridLayout(3, 4, 10, 10));
        selector.add(Tema.et("Atención a cobrar"));
        selector.add(cmbAtencion);
        selector.add(new JLabel());
        selector.add(new JLabel());
        selector.add(Tema.et("Servicio"));
        selector.add(cmbServicio);
        selector.add(spnServicio);
        selector.add(btnAgregarServicio);
        selector.add(Tema.et("Producto usado"));
        selector.add(cmbProducto);
        selector.add(spnProducto);
        selector.add(btnAgregarProducto);

        // Detalle
        modeloDetalle = new DefaultTableModel(
                new String[]{"Descripción", "Cant.", "P. unitario (S/)", "Subtotal (S/)"}, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tablaDetalle = new JTable(modeloDetalle);
        tablaDetalle.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        lblTotal.setFont(Tema.FUENTE_NEGRITA.deriveFont(22f));
        lblTotal.setForeground(Tema.PRIMARIO);
        JPanel totales = new JPanel(new GridLayout(4, 2, 8, 10));
        totales.add(Tema.et("Subtotal"));
        totales.add(lblSubtotal);
        totales.add(Tema.et("IGV (18 %)"));
        totales.add(lblIgv);
        totales.add(Tema.et("TOTAL"));
        totales.add(lblTotal);
        totales.add(Tema.et("Método de pago"));
        totales.add(cmbPago);

        JPanel botones = new JPanel(new BorderLayout());
        botones.setOpaque(false);
        JPanel izq = new JPanel(new java.awt.FlowLayout(java.awt.FlowLayout.LEFT, 8, 0));
        izq.setOpaque(false);
        izq.add(btnQuitar);
        izq.add(btnLimpiar);
        botones.add(izq, BorderLayout.WEST);
        botones.add(btnEmitir, BorderLayout.EAST);

        JPanel lateral = new JPanel(new BorderLayout());
        lateral.setOpaque(false);
        lateral.setPreferredSize(new Dimension(270, 100));
        lateral.add(totales, BorderLayout.NORTH);

        JPanel izquierda = new JPanel(new BorderLayout(0, 10));
        izquierda.setOpaque(false);
        izquierda.add(Tema.scroll(tablaDetalle), BorderLayout.CENTER);
        izquierda.add(botones, BorderLayout.SOUTH);

        JPanel detalle = new JPanel(new BorderLayout(16, 0));
        detalle.add(izquierda, BorderLayout.CENTER);
        detalle.add(lateral, BorderLayout.EAST);

        // Emitidos
        modeloEmitidos = new DefaultTableModel(
                new String[]{"N.º", "Fecha", "Cliente", "Pago", "Subtotal", "IGV", "Total"}, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tablaEmitidos = new JTable(modeloEmitidos);

        JPanel centro = new JPanel(new GridLayout(2, 1, 0, 12));
        centro.setOpaque(false);
        centro.add(Tema.tarjeta("Detalle de la boleta", detalle));
        centro.add(Tema.tarjeta("Comprobantes emitidos", Tema.scroll(tablaEmitidos)));

        lblEstado.setForeground(Tema.SUAVE);
        lblEstado.setBorder(BorderFactory.createEmptyBorder(0, 0, 0, 0));

        JPanel cuerpo = new JPanel(new BorderLayout(0, 12));
        cuerpo.add(Tema.tarjeta("Nueva boleta", selector), BorderLayout.NORTH);
        cuerpo.add(centro, BorderLayout.CENTER);
        cuerpo.add(lblEstado, BorderLayout.SOUTH);

        Tema.marco(this, "Facturación", "Boletas con IGV 18 % y control de pagos",
                Tema.Icono.BOLETA, null, cuerpo);
    }
}
