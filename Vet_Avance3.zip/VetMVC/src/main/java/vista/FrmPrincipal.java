package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** VISTA - Menú principal (P02): muestra el usuario con su rol y los módulos como tarjetas. */
public class FrmPrincipal extends JFrame {

    private static final long serialVersionUID = 1L;

    public JLabel lblUsuario = new JLabel(" ");
    public JButton btnMascotas = new JButton("Clientes y mascotas");
    public JButton btnCitas = new JButton("Agenda de citas");
    public JButton btnInventario = new JButton("Inventario");
    public JButton btnFacturacion = new JButton("Facturación");
    public JButton btnCerrarSesion = new JButton("Cerrar sesión");

    public FrmPrincipal() {
        super("DR.SHEEP - Sistema Integral de Gestión Veterinaria");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(760, 560);

        Tema.tarjetaMenu(btnMascotas, "Registra dueños y mascotas y consulta su historial médico.", Tema.Icono.PATA);
        Tema.tarjetaMenu(btnCitas, "Programa, confirma y cancela citas; registra la atención.", Tema.Icono.CALENDARIO);
        Tema.tarjetaMenu(btnInventario, "Controla productos, entradas, salidas y alertas de stock.", Tema.Icono.CAJA);
        Tema.tarjetaMenu(btnFacturacion, "Emite boletas con IGV y registra el método de pago.", Tema.Icono.BOLETA);
        Tema.secundario(btnCerrarSesion);

        lblUsuario.setForeground(Color.WHITE);
        lblUsuario.setFont(Tema.FUENTE_NEGRITA.deriveFont(13f));

        JPanel menu = new JPanel(new GridLayout(2, 2, 18, 18));
        menu.add(btnMascotas);
        menu.add(btnCitas);
        menu.add(btnInventario);
        menu.add(btnFacturacion);

        JPanel pie = new JPanel(new FlowLayout(FlowLayout.RIGHT, 0, 0));
        pie.setOpaque(false);
        pie.setBorder(BorderFactory.createEmptyBorder(14, 0, 0, 0));
        pie.add(btnCerrarSesion);

        JPanel cuerpo = new JPanel(new BorderLayout());
        cuerpo.add(menu, BorderLayout.CENTER);
        cuerpo.add(pie, BorderLayout.SOUTH);

        Tema.marco(this, "Menú principal", "Elige un módulo para comenzar", Tema.Icono.PATA, lblUsuario, cuerpo);
    }
}
