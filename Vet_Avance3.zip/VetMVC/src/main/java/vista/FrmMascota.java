package vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.Insets;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 * VISTA - Clientes y mascotas (P03/P04). Solo interfaz, sin lógica ni consultas.
 * Los componentes son públicos para que el Controlador pueda escucharlos.
 */
public class FrmMascota extends JFrame {

    private static final long serialVersionUID = 1L;

    // Dueño (cliente)
    public JTextField txtDni = new JTextField();
    public JTextField txtDueno = new JTextField();
    public JTextField txtTelefono = new JTextField();
    public JTextField txtDireccion = new JTextField();
    public JButton btnBuscarDni = new JButton("Buscar");

    // Mascota
    public JTextField txtId = new JTextField();
    public JTextField txtNombre = new JTextField();
    public JTextField txtEspecie = new JTextField();
    public JTextField txtRaza = new JTextField();
    public JComboBox<String> cmbSexo = new JComboBox<>(new String[]{"Macho", "Hembra"});
    public JTextField txtNacimiento = new JTextField();
    public JTextField txtPeso = new JTextField();

    public JTextField txtBuscar = new JTextField(22);
    public JButton btnBuscar = new JButton("Buscar");
    public JButton btnTodos = new JButton("Mostrar todos");

    public JButton btnGuardar = new JButton("Guardar");
    public JButton btnModificar = new JButton("Modificar");
    public JButton btnEliminar = new JButton("Eliminar");
    public JButton btnLimpiar = new JButton("Limpiar");
    public JButton btnHistorial = new JButton("Ver historial médico");

    public JLabel lblEstado = new JLabel(" ");
    public DefaultTableModel modeloTabla;
    public JTable tabla;

    public FrmMascota() {
        super("DR.SHEEP - Clientes y mascotas");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1120, 760);

        txtId.setEditable(false);
        btnBuscarDni.setToolTipText("Buscar dueño por DNI");
        Tema.primario(btnBuscar);
        Tema.secundario(btnTodos);
        Tema.secundario(btnBuscarDni);
        Tema.primario(btnGuardar);
        Tema.secundario(btnModificar);
        Tema.peligro(btnEliminar);
        Tema.secundario(btnLimpiar);
        Tema.secundario(btnHistorial);

        // Búsqueda
        JPanel busqueda = new JPanel(new BorderLayout(10, 0));
        busqueda.add(Tema.et("MASCOTA, ESPECIE, DUEÑO O DNI"), BorderLayout.WEST);
        busqueda.add(txtBuscar, BorderLayout.CENTER);
        JPanel bBusq = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        bBusq.setOpaque(false);
        bBusq.add(btnBuscar);
        bBusq.add(btnTodos);
        busqueda.add(bBusq, BorderLayout.EAST);

        // Dueño
        JPanel dueno = Tema.formulario(1,
                Tema.et("DNI"), Tema.fila(txtDni, btnBuscarDni),
                Tema.et("Nombres"), txtDueno,
                Tema.et("Teléfono"), txtTelefono,
                Tema.et("Dirección"), txtDireccion);

        // Mascota
        JPanel mascota = new JPanel(new GridLayout(4, 4, 10, 10));
        mascota.add(Tema.et("ID"));
        mascota.add(txtId);
        mascota.add(Tema.et("Nombre"));
        mascota.add(txtNombre);
        mascota.add(Tema.et("Especie"));
        mascota.add(txtEspecie);
        mascota.add(Tema.et("Raza"));
        mascota.add(txtRaza);
        mascota.add(Tema.et("Sexo"));
        mascota.add(cmbSexo);
        mascota.add(Tema.et("Nacimiento (aaaa-mm-dd)"));
        mascota.add(txtNacimiento);
        mascota.add(Tema.et("Peso (kg)"));
        mascota.add(txtPeso);
        mascota.add(new JLabel());
        mascota.add(new JLabel());

        JPanel formularios = new JPanel(new GridBagLayout());
        formularios.setOpaque(false);
        GridBagConstraints gc = new GridBagConstraints();
        gc.fill = GridBagConstraints.BOTH;
        gc.weighty = 1;
        gc.insets = new Insets(0, 0, 0, 6);
        gc.weightx = 0.50;
        formularios.add(Tema.tarjeta("Dueño · si el DNI no existe se registra al guardar", dueno), gc);
        gc.insets = new Insets(0, 6, 0, 0);
        gc.weightx = 0.50;
        formularios.add(Tema.tarjeta("Datos de la mascota", mascota), gc);

        JPanel norte = new JPanel(new BorderLayout(0, 12));
        norte.setOpaque(false);
        norte.add(Tema.tarjeta("Búsqueda", busqueda), BorderLayout.NORTH);
        norte.add(formularios, BorderLayout.CENTER);

        // Tabla
        String[] columnas = {"ID", "Mascota", "Especie", "Raza", "Sexo", "Nacimiento", "Peso (kg)",
            "DNI", "Dueño", "Teléfono", "Dirección"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            private static final long serialVersionUID = 1L;

            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);

        // Botones + estado
        JPanel botones = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        botones.setOpaque(false);
        botones.add(btnGuardar);
        botones.add(btnModificar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);
        botones.add(btnHistorial);
        lblEstado.setForeground(Tema.SUAVE);
        JPanel sur = new JPanel(new BorderLayout());
        sur.setOpaque(false);
        sur.add(lblEstado, BorderLayout.WEST);
        sur.add(botones, BorderLayout.EAST);

        JPanel cuerpo = new JPanel(new BorderLayout(0, 12));
        cuerpo.add(norte, BorderLayout.NORTH);
        cuerpo.add(Tema.scroll(tabla), BorderLayout.CENTER);
        cuerpo.add(sur, BorderLayout.SOUTH);
        cuerpo.setBorder(BorderFactory.createEmptyBorder());

        Tema.marco(this, "Clientes y mascotas", "Registro de dueños, mascotas e historial médico",
                Tema.Icono.PATA, null, cuerpo);
    }
}
