package modelo;

/** MODELO - Entidad Cliente (dueño de la mascota). */
public class Cliente {

    private int id;
    private String dni;
    private String nombres;
    private String telefono;
    private String direccion;

    public Cliente() { }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getDni() { return dni; }
    public void setDni(String dni) { this.dni = dni; }
    public String getNombres() { return nombres; }
    public void setNombres(String nombres) { this.nombres = nombres; }
    public String getTelefono() { return telefono; }
    public void setTelefono(String telefono) { this.telefono = telefono; }
    public String getDireccion() { return direccion; }
    public void setDireccion(String direccion) { this.direccion = direccion; }
}
