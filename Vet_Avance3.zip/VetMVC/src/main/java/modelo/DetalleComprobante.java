package modelo;

import java.math.BigDecimal;

/** MODELO - Línea de un comprobante: un servicio o un producto (nunca ambos). */
public class DetalleComprobante {

    private Integer idServicio;
    private Integer idProducto;
    private String descripcion;
    private int cantidad;
    private BigDecimal precioUnitario;

    public DetalleComprobante(Integer idServicio, Integer idProducto, String descripcion,
                              int cantidad, BigDecimal precioUnitario) {
        this.idServicio = idServicio;
        this.idProducto = idProducto;
        this.descripcion = descripcion;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }

    public Integer getIdServicio() { return idServicio; }
    public Integer getIdProducto() { return idProducto; }
    public String getDescripcion() { return descripcion; }
    public int getCantidad() { return cantidad; }
    public BigDecimal getPrecioUnitario() { return precioUnitario; }

    public BigDecimal getSubtotal() { return precioUnitario.multiply(BigDecimal.valueOf(cantidad)); }
}
