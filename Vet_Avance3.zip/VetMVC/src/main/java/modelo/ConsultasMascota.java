package modelo;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

/**
 * MODELO - Acceso a datos de Cliente y Mascota (RF02 a RF05).
 * "Eliminar" es una eliminación lógica: activo = 0, para conservar el historial.
 */
public class ConsultasMascota extends Conexion {

    private static final String SELECT_MASCOTA =
            "SELECT m.id_mascota, m.nombre, m.especie, m.raza, m.sexo, m.fecha_nacimiento, m.peso, "
            + "c.id_cliente, c.dni, c.nombres, c.telefono, c.direccion "
            + "FROM mascota m JOIN cliente c ON c.id_cliente = m.id_cliente WHERE m.activo = 1 ";

    /** Guarda la mascota. Si el DNI del dueño no existe, registra también al cliente. */
    public boolean insertar(Mascota m) {
        ultimoError = null;
        try (Connection con = getConnection()) {
            con.setAutoCommit(false);
            try {
                m.getCliente().setId(guardarCliente(con, m.getCliente()));
                String sql = "INSERT INTO mascota (id_cliente, nombre, especie, raza, sexo, "
                        + "fecha_nacimiento, peso) VALUES (?, ?, ?, ?, ?, ?, ?)";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    llenar(ps, m);
                    ps.executeUpdate();
                }
                con.commit();
                return true;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    public boolean modificar(Mascota m) {
        ultimoError = null;
        try (Connection con = getConnection()) {
            con.setAutoCommit(false);
            try {
                m.getCliente().setId(guardarCliente(con, m.getCliente()));
                String sql = "UPDATE mascota SET id_cliente=?, nombre=?, especie=?, raza=?, sexo=?, "
                        + "fecha_nacimiento=?, peso=? WHERE id_mascota=?";
                try (PreparedStatement ps = con.prepareStatement(sql)) {
                    llenar(ps, m);
                    ps.setInt(8, m.getId());
                    ps.executeUpdate();
                }
                con.commit();
                return true;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    /** Eliminación lógica (activo = 0). */
    public boolean eliminar(int idMascota) {
        ultimoError = null;
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("UPDATE mascota SET activo = 0 WHERE id_mascota = ?")) {
            ps.setInt(1, idMascota);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    public List<Mascota> listar() {
        return consultar(SELECT_MASCOTA + "ORDER BY m.id_mascota", null);
    }

    /** Busca por nombre de mascota, especie, nombre del dueño o DNI (coincidencia parcial). */
    public List<Mascota> buscar(String texto) {
        return consultar(SELECT_MASCOTA + "AND (m.nombre LIKE ? OR m.especie LIKE ? OR c.nombres LIKE ? "
                + "OR c.dni LIKE ?) ORDER BY m.id_mascota", "%" + texto + "%");
    }

    /** Busca un cliente por DNI; devuelve null si no existe. */
    public Cliente buscarClientePorDni(String dni) {
        ultimoError = null;
        try (Connection con = getConnection()) {
            return clientePorDni(con, dni);
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return null;
        }
    }

    /** Historial médico de una mascota (RF04): sus atenciones, de la más reciente a la más antigua. */
    public List<Atencion> historial(int idMascota) {
        String sql = "SELECT a.id_atencion, a.id_cita, a.fecha, a.diagnostico, a.tratamiento "
                + "FROM atencion a JOIN cita c ON c.id_cita = a.id_cita "
                + "WHERE c.id_mascota = ? ORDER BY a.fecha DESC";
        ultimoError = null;
        List<Atencion> lista = new ArrayList<>();
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idMascota);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Atencion a = new Atencion();
                    a.setId(rs.getInt("id_atencion"));
                    a.setIdCita(rs.getInt("id_cita"));
                    a.setFecha(rs.getTimestamp("fecha").toLocalDateTime());
                    a.setDiagnostico(rs.getString("diagnostico"));
                    a.setTratamiento(rs.getString("tratamiento"));
                    lista.add(a);
                }
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
        }
        return lista;
    }

    // ---------------- Apoyo ----------------

    private List<Mascota> consultar(String sql, String patron) {
        ultimoError = null;
        List<Mascota> lista = new ArrayList<>();
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            if (patron != null) {
                for (int i = 1; i <= 4; i++) {
                    ps.setString(i, patron);
                }
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(armarMascota(rs));
                }
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
        }
        return lista;
    }

    /** Si el DNI existe actualiza los datos del cliente; si no, lo inserta. Devuelve su id. */
    private int guardarCliente(Connection con, Cliente c) throws SQLException {
        Cliente existente = clientePorDni(con, c.getDni());
        if (existente != null) {
            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE cliente SET nombres=?, telefono=?, direccion=?, activo=1 WHERE id_cliente=?")) {
                ps.setString(1, c.getNombres());
                ps.setString(2, c.getTelefono());
                ps.setString(3, c.getDireccion());
                ps.setInt(4, existente.getId());
                ps.executeUpdate();
            }
            return existente.getId();
        }
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO cliente (dni, nombres, telefono, direccion) VALUES (?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, c.getDni());
            ps.setString(2, c.getNombres());
            ps.setString(3, c.getTelefono());
            ps.setString(4, c.getDireccion());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    private Cliente clientePorDni(Connection con, String dni) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id_cliente, dni, nombres, telefono, direccion FROM cliente WHERE dni = ?")) {
            ps.setString(1, dni);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? armarCliente(rs) : null;
            }
        }
    }

    private void llenar(PreparedStatement ps, Mascota m) throws SQLException {
        ps.setInt(1, m.getCliente().getId());
        ps.setString(2, m.getNombre());
        ps.setString(3, m.getEspecie());
        ps.setString(4, m.getRaza());
        ps.setString(5, m.getSexo());
        ps.setDate(6, m.getFechaNacimiento() == null ? null : Date.valueOf(m.getFechaNacimiento()));
        ps.setDouble(7, m.getPeso());
    }

    private Cliente armarCliente(ResultSet rs) throws SQLException {
        Cliente c = new Cliente();
        c.setId(rs.getInt("id_cliente"));
        c.setDni(rs.getString("dni"));
        c.setNombres(rs.getString("nombres"));
        c.setTelefono(rs.getString("telefono"));
        c.setDireccion(rs.getString("direccion"));
        return c;
    }

    private Mascota armarMascota(ResultSet rs) throws SQLException {
        Mascota m = new Mascota();
        m.setId(rs.getInt("id_mascota"));
        m.setNombre(rs.getString("nombre"));
        m.setEspecie(rs.getString("especie"));
        m.setRaza(rs.getString("raza"));
        m.setSexo(rs.getString("sexo"));
        Date nac = rs.getDate("fecha_nacimiento");
        m.setFechaNacimiento(nac == null ? null : nac.toLocalDate());
        m.setPeso(rs.getDouble("peso"));
        m.setCliente(armarCliente(rs));
        return m;
    }
}
