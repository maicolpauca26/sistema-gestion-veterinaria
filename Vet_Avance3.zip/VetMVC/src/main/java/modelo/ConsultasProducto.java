package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/** MODELO - Acceso a datos de Producto e inventario (RF09 a RF11). */
public class ConsultasProducto extends Conexion {

    private static final String SELECT_PRODUCTO =
            "SELECT id_producto, codigo, nombre, precio, stock, stock_minimo FROM producto WHERE activo = 1 ";

    public boolean insertar(Producto p) {
        String sql = "INSERT INTO producto (codigo, nombre, precio, stock, stock_minimo) VALUES (?, ?, ?, 0, ?)";
        ultimoError = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getCodigo());
            ps.setString(2, p.getNombre());
            ps.setBigDecimal(3, p.getPrecio());
            ps.setInt(4, p.getStockMinimo());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    /** El stock NO se edita aquí: solo cambia con movimientos de entrada y salida. */
    public boolean modificar(Producto p) {
        String sql = "UPDATE producto SET codigo=?, nombre=?, precio=?, stock_minimo=? WHERE id_producto=?";
        ultimoError = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, p.getCodigo());
            ps.setString(2, p.getNombre());
            ps.setBigDecimal(3, p.getPrecio());
            ps.setInt(4, p.getStockMinimo());
            ps.setInt(5, p.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    /** Eliminación lógica (activo = 0). */
    public boolean eliminar(int idProducto) {
        ultimoError = null;
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement("UPDATE producto SET activo = 0 WHERE id_producto = ?")) {
            ps.setInt(1, idProducto);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    /** Registra una ENTRADA o SALIDA. El trigger de la BD actualiza el stock y rechaza salidas de más. */
    public boolean registrarMovimiento(int idProducto, String tipo, int cantidad, int idUsuario) {
        String sql = "INSERT INTO movimiento_inventario (id_producto, id_usuario, tipo, cantidad) VALUES (?, ?, ?, ?)";
        ultimoError = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idProducto);
            ps.setInt(2, idUsuario);
            ps.setString(3, tipo);
            ps.setInt(4, cantidad);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    public List<Producto> listar() {
        return consultar(SELECT_PRODUCTO + "ORDER BY id_producto", null);
    }

    public List<Producto> buscar(String texto) {
        return consultar(SELECT_PRODUCTO + "AND (codigo LIKE ? OR nombre LIKE ?) ORDER BY id_producto",
                "%" + texto + "%");
    }

    /** Productos con stock igual o menor al mínimo (alerta RF11). */
    public List<Producto> listarCriticos() {
        return consultar(SELECT_PRODUCTO + "AND stock <= stock_minimo ORDER BY stock", null);
    }

    private List<Producto> consultar(String sql, String patron) {
        ultimoError = null;
        List<Producto> lista = new ArrayList<>();
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            if (patron != null) {
                ps.setString(1, patron);
                ps.setString(2, patron);
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Producto p = new Producto();
                    p.setId(rs.getInt("id_producto"));
                    p.setCodigo(rs.getString("codigo"));
                    p.setNombre(rs.getString("nombre"));
                    p.setPrecio(rs.getBigDecimal("precio"));
                    p.setStock(rs.getInt("stock"));
                    p.setStockMinimo(rs.getInt("stock_minimo"));
                    lista.add(p);
                }
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
        }
        return lista;
    }
}
