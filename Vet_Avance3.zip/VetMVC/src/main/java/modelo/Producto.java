package modelo;

import java.math.BigDecimal;

/** MODELO - Entidad Producto (medicamentos e insumos). */
public class Producto {

    private int id;
    private String codigo;
    private String nombre;
    private BigDecimal precio = BigDecimal.ZERO;
    private int stock;
    private int stockMinimo;

    public Producto() { }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getCodigo() { return codigo; }
    public void setCodigo(String codigo) { this.codigo = codigo; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public BigDecimal getPrecio() { return precio; }
    public void setPrecio(BigDecimal precio) { this.precio = precio; }
    public int getStock() { return stock; }
    public void setStock(int stock) { this.stock = stock; }
    public int getStockMinimo() { return stockMinimo; }
    public void setStockMinimo(int stockMinimo) { this.stockMinimo = stockMinimo; }

    /** Regla del negocio (RF11): hay alerta cuando el stock llega al mínimo o por debajo. */
    public boolean esCritico() { return stock <= stockMinimo; }

    @Override
    public String toString() { return codigo + " - " + nombre + " (stock " + stock + ")"; }
}
