package modelo;

import java.time.LocalDateTime;

/** MODELO - Entidad Cita (agenda). Estados: PROGRAMADA, CONFIRMADA, CANCELADA, ATENDIDA. */
public class Cita {

    public static final String PROGRAMADA = "PROGRAMADA";
    public static final String CONFIRMADA = "CONFIRMADA";
    public static final String CANCELADA = "CANCELADA";
    public static final String ATENDIDA = "ATENDIDA";

    private int id;
    private Mascota mascota;
    private Usuario veterinario;
    private LocalDateTime fechaHora;
    private String motivo;
    private String estado;

    public Cita() { }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public Mascota getMascota() { return mascota; }
    public void setMascota(Mascota mascota) { this.mascota = mascota; }
    public Usuario getVeterinario() { return veterinario; }
    public void setVeterinario(Usuario veterinario) { this.veterinario = veterinario; }
    public LocalDateTime getFechaHora() { return fechaHora; }
    public void setFechaHora(LocalDateTime fechaHora) { this.fechaHora = fechaHora; }
    public String getMotivo() { return motivo; }
    public void setMotivo(String motivo) { this.motivo = motivo; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
