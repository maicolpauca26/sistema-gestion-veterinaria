package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import util.PasswordUtil;

/** MODELO - Acceso a datos de Usuario: inicio de sesión (RF01) y lista de veterinarios. */
public class ConsultasUsuario extends Conexion {

    public static final int MAX_INTENTOS = 3;

    /** Resultado posible de un intento de login. */
    public enum Resultado { OK, CREDENCIALES_INVALIDAS, BLOQUEADO, ERROR_BD }

    private Usuario usuarioAutenticado;

    public Usuario getUsuarioAutenticado() {
        return usuarioAutenticado;
    }

    /** Valida usuario y contraseña. Tras 3 intentos fallidos la cuenta se bloquea. */
    public Resultado autenticar(String username, String password) {
        String sql = "SELECT u.id_usuario, u.password_hash, u.nombre_completo, u.activo, "
                + "u.intentos_fallidos, r.nombre AS rol FROM usuario u "
                + "JOIN rol r ON r.id_rol = u.id_rol WHERE u.username = ?";
        ultimoError = null;
        usuarioAutenticado = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            try (ResultSet rs = ps.executeQuery()) {
                if (!rs.next()) {
                    return Resultado.CREDENCIALES_INVALIDAS;
                }
                int id = rs.getInt("id_usuario");
                if (rs.getInt("activo") == 0 || rs.getInt("intentos_fallidos") >= MAX_INTENTOS) {
                    return Resultado.BLOQUEADO;
                }
                if (!PasswordUtil.verificar(password, rs.getString("password_hash"))) {
                    ejecutar(con, "UPDATE usuario SET intentos_fallidos = intentos_fallidos + 1 "
                            + "WHERE id_usuario = ?", id);
                    registrarLog(con, id, "Login fallido");
                    return Resultado.CREDENCIALES_INVALIDAS;
                }
                ejecutar(con, "UPDATE usuario SET intentos_fallidos = 0 WHERE id_usuario = ?", id);
                registrarLog(con, id, "Inicio de sesión");
                usuarioAutenticado = new Usuario(id, username, rs.getString("nombre_completo"),
                        rs.getString("rol"));
                return Resultado.OK;
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return Resultado.ERROR_BD;
        }
    }

    /** Veterinarios activos (para elegir quién atiende una cita). */
    public List<Usuario> listarVeterinarios() {
        String sql = "SELECT u.id_usuario, u.username, u.nombre_completo, r.nombre AS rol FROM usuario u "
                + "JOIN rol r ON r.id_rol = u.id_rol WHERE r.nombre = 'Veterinario' AND u.activo = 1 "
                + "ORDER BY u.nombre_completo";
        ultimoError = null;
        List<Usuario> lista = new ArrayList<>();
        try (Connection con = getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                lista.add(new Usuario(rs.getInt("id_usuario"), rs.getString("username"),
                        rs.getString("nombre_completo"), rs.getString("rol")));
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
        }
        return lista;
    }

    private void ejecutar(Connection con, String sql, int id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private void registrarLog(Connection con, int idUsuario, String accion) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO log_auditoria (id_usuario, accion) VALUES (?, ?)")) {
            ps.setInt(1, idUsuario);
            ps.setString(2, accion);
            ps.executeUpdate();
        }
    }
}
