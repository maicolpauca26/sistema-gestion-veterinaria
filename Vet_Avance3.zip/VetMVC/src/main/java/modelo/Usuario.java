package modelo;

/** MODELO - Entidad Usuario (personal que usa el sistema). */
public class Usuario {

    public static final String ADMIN = "Administrador";
    public static final String VETERINARIO = "Veterinario";
    public static final String RECEPCIONISTA = "Recepcionista";

    private int id;
    private String username;
    private String nombreCompleto;
    private String rol;

    public Usuario() { }

    public Usuario(int id, String username, String nombreCompleto, String rol) {
        this.id = id; this.username = username; this.nombreCompleto = nombreCompleto; this.rol = rol;
    }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getUsername() { return username; }
    public void setUsername(String username) { this.username = username; }
    public String getNombreCompleto() { return nombreCompleto; }
    public void setNombreCompleto(String nombreCompleto) { this.nombreCompleto = nombreCompleto; }
    public String getRol() { return rol; }
    public void setRol(String rol) { this.rol = rol; }

    /** Texto que se muestra en las listas desplegables. */
    @Override
    public String toString() { return nombreCompleto; }
}
