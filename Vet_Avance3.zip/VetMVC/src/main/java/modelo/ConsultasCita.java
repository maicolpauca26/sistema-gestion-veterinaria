package modelo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** MODELO - Acceso a datos de Cita y Atención (RF06 a RF08). */
public class ConsultasCita extends Conexion {

    private static final String SELECT_CITA =
            "SELECT c.id_cita, c.fecha_hora, c.motivo, c.estado, m.id_mascota, m.nombre AS mascota, "
            + "cl.nombres AS cliente, u.id_usuario, u.nombre_completo AS veterinario "
            + "FROM cita c JOIN mascota m ON m.id_mascota = c.id_mascota "
            + "JOIN cliente cl ON cl.id_cliente = m.id_cliente "
            + "JOIN usuario u ON u.id_usuario = c.id_veterinario ";

    /** ¿El veterinario ya tiene una cita activa en ese horario? (evita cruces de horario) */
    public boolean horarioOcupado(int idVeterinario, LocalDateTime fechaHora, int idCitaExcluida) {
        String sql = "SELECT COUNT(*) FROM cita WHERE id_veterinario = ? AND fecha_hora = ? "
                + "AND estado <> 'CANCELADA' AND id_cita <> ?";
        ultimoError = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, idVeterinario);
            ps.setTimestamp(2, Timestamp.valueOf(fechaHora));
            ps.setInt(3, idCitaExcluida);
            try (ResultSet rs = ps.executeQuery()) {
                rs.next();
                return rs.getInt(1) > 0;
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return true;   // ante un error no se permite programar
        }
    }

    public boolean insertar(Cita c, int idRegistrador) {
        String sql = "INSERT INTO cita (id_mascota, id_veterinario, id_registrador, fecha_hora, motivo, estado) "
                + "VALUES (?, ?, ?, ?, ?, 'PROGRAMADA')";
        ultimoError = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, c.getMascota().getId());
            ps.setInt(2, c.getVeterinario().getId());
            ps.setInt(3, idRegistrador);
            ps.setTimestamp(4, Timestamp.valueOf(c.getFechaHora()));
            ps.setString(5, c.getMotivo());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    /** Reprograma o corrige una cita que aún no fue atendida ni cancelada. */
    public boolean modificar(Cita c) {
        String sql = "UPDATE cita SET id_mascota=?, id_veterinario=?, fecha_hora=?, motivo=? "
                + "WHERE id_cita=? AND estado IN ('PROGRAMADA','CONFIRMADA')";
        ultimoError = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, c.getMascota().getId());
            ps.setInt(2, c.getVeterinario().getId());
            ps.setTimestamp(3, Timestamp.valueOf(c.getFechaHora()));
            ps.setString(4, c.getMotivo());
            ps.setInt(5, c.getId());
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    /** Cambia el estado (CONFIRMADA o CANCELADA) solo si la cita está en un estado válido de origen. */
    public boolean cambiarEstado(int idCita, String nuevoEstado) {
        String origen = nuevoEstado.equals(Cita.CONFIRMADA) ? "('PROGRAMADA')" : "('PROGRAMADA','CONFIRMADA')";
        String sql = "UPDATE cita SET estado = ? WHERE id_cita = ? AND estado IN " + origen;
        ultimoError = null;
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, nuevoEstado);
            ps.setInt(2, idCita);
            return ps.executeUpdate() > 0;
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    /** Registra el diagnóstico y marca la cita como ATENDIDA (todo o nada). */
    public boolean atender(int idCita, String diagnostico, String tratamiento) {
        ultimoError = null;
        try (Connection con = getConnection()) {
            con.setAutoCommit(false);
            try {
                try (PreparedStatement ps = con.prepareStatement(
                        "UPDATE cita SET estado = 'ATENDIDA' WHERE id_cita = ? AND estado = 'CONFIRMADA'")) {
                    ps.setInt(1, idCita);
                    if (ps.executeUpdate() == 0) {
                        throw new SQLException("Solo se puede atender una cita CONFIRMADA.");
                    }
                }
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO atencion (id_cita, diagnostico, tratamiento) VALUES (?, ?, ?)")) {
                    ps.setInt(1, idCita);
                    ps.setString(2, diagnostico);
                    ps.setString(3, tratamiento);
                    ps.executeUpdate();
                }
                con.commit();
                return true;
            } catch (SQLException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
            return false;
        }
    }

    /** Agenda de un día (RF08). */
    public List<Cita> listarPorFecha(LocalDate dia) {
        return consultar(SELECT_CITA + "WHERE DATE(c.fecha_hora) = ? ORDER BY c.fecha_hora", dia);
    }

    public List<Cita> listarTodas() {
        return consultar(SELECT_CITA + "ORDER BY c.fecha_hora DESC", null);
    }

    private List<Cita> consultar(String sql, LocalDate dia) {
        ultimoError = null;
        List<Cita> lista = new ArrayList<>();
        try (Connection con = getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            if (dia != null) {
                ps.setDate(1, java.sql.Date.valueOf(dia));
            }
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Cita c = new Cita();
                    c.setId(rs.getInt("id_cita"));
                    c.setFechaHora(rs.getTimestamp("fecha_hora").toLocalDateTime());
                    c.setMotivo(rs.getString("motivo"));
                    c.setEstado(rs.getString("estado"));
                    Mascota m = new Mascota();
                    m.setId(rs.getInt("id_mascota"));
                    m.setNombre(rs.getString("mascota"));
                    m.getCliente().setNombres(rs.getString("cliente"));
                    c.setMascota(m);
                    c.setVeterinario(new Usuario(rs.getInt("id_usuario"), null,
                            rs.getString("veterinario"), Usuario.VETERINARIO));
                    lista.add(c);
                }
            }
        } catch (SQLException e) {
            ultimoError = e.getMessage();
        }
        return lista;
    }

    /** Mascotas activas para el combo de la pantalla de citas. */
    public List<Mascota> listarMascotas() {
        return new ConsultasMascota().listar();
    }
}
