package modelo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * MODELO - Conexión a MySQL. Todas las clases Consultas* heredan de esta.
 * La aplicación se conecta con el usuario vet_app (mínimo privilegio), NO con root.
 * Si cambiaste la clave en sql/dr_sheep_vet.sql, cámbiala también aquí.
 */
public class Conexion {

    private static final String URL = System.getProperty("vet.url",
            "jdbc:mysql://localhost:3306/dr_sheep_vet?useSSL=false&serverTimezone=America/Lima"
            + "&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8");
    private static final String USUARIO = System.getProperty("vet.user", "vet_app");
    private static final String PASSWORD = System.getProperty("vet.pass", "VetApp2026!");

    /** Mensaje del último error de BD (null si la última operación salió bien). */
    protected String ultimoError;

    public Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }

    public String getUltimoError() {
        return ultimoError;
    }
}
