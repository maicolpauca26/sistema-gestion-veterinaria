package modelo;

import java.time.LocalDateTime;

/** MODELO - Entidad Atención (diagnóstico y tratamiento de una cita). */
public class Atencion {

    private int id;
    private int idCita;
    private LocalDateTime fecha;
    private String diagnostico;
    private String tratamiento;
    private String mascota;   // solo para mostrar en listas
    private String cliente;   // solo para mostrar en listas

    public Atencion() { }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getIdCita() { return idCita; }
    public void setIdCita(int idCita) { this.idCita = idCita; }
    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }
    public String getDiagnostico() { return diagnostico; }
    public void setDiagnostico(String diagnostico) { this.diagnostico = diagnostico; }
    public String getTratamiento() { return tratamiento; }
    public void setTratamiento(String tratamiento) { this.tratamiento = tratamiento; }
    public String getMascota() { return mascota; }
    public void setMascota(String mascota) { this.mascota = mascota; }
    public String getCliente() { return cliente; }
    public void setCliente(String cliente) { this.cliente = cliente; }

    @Override
    public String toString() { return "Atención " + id + " - " + mascota + " (" + cliente + ")"; }
}
