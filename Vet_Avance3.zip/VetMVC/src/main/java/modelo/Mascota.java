package modelo;

import java.time.LocalDate;

/** MODELO - Entidad Mascota. Cada mascota pertenece a un Cliente. */
public class Mascota {

    private int id;
    private String nombre;
    private String especie;
    private String raza;
    private String sexo;              // M = macho, H = hembra
    private LocalDate fechaNacimiento;
    private double peso;
    private Cliente cliente = new Cliente();

    public Mascota() { }

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getEspecie() { return especie; }
    public void setEspecie(String especie) { this.especie = especie; }
    public String getRaza() { return raza; }
    public void setRaza(String raza) { this.raza = raza; }
    public String getSexo() { return sexo; }
    public void setSexo(String sexo) { this.sexo = sexo; }
    public LocalDate getFechaNacimiento() { return fechaNacimiento; }
    public void setFechaNacimiento(LocalDate fechaNacimiento) { this.fechaNacimiento = fechaNacimiento; }
    public double getPeso() { return peso; }
    public void setPeso(double peso) { this.peso = peso; }
    public Cliente getCliente() { return cliente; }
    public void setCliente(Cliente cliente) { this.cliente = cliente; }

    /** Texto para las listas desplegables: "Firulais (Carlos Ramos)". */
    @Override
    public String toString() { return nombre + " (" + cliente.getNombres() + ")"; }
}
