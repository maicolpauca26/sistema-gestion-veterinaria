# VetMVC — DR.SHEEP · Sistema Integral de Gestión Veterinaria (patrón MVC en Java)

Aplicación de escritorio con **Java Swing + MySQL**, organizada en **Modelo – Vista – Controlador**.
Cubre los 4 procesos del alcance del proyecto (citas, mascotas, inventario y facturación) más el
inicio de sesión con roles. Es la **Alternativa 1** del documento *Avance de Proyecto Final 2*.

| Login | Menú principal |
|---|---|
| ![Login](docs/login.png) | ![Menú](docs/menu.png) |

![Clientes y mascotas](docs/mascotas.png)
![Agenda de citas](docs/citas.png)
![Inventario](docs/inventario.png)
![Facturación](docs/facturacion.png)

## 1. Requisitos
- JDK 11 o superior (probado con 21) y NetBeans (proyecto Maven).
- MySQL de Laragon iniciado (usuario `root`, sin contraseña, solo para crear la base).

## 2. Cómo ponerlo a funcionar
1. **Crear la base de datos:** ejecuta `sql/dr_sheep_vet.sql` **una sola vez** (HeidiSQL: abrir el
   archivo y pulsar F9; o en consola: `mysql -u root < sql/dr_sheep_vet.sql`).
   Crea la BD `dr_sheep_vet`, las tablas, el trigger de stock, las vistas, el usuario `vet_app`
   y los datos de ejemplo. *Si lo vuelves a ejecutar, la base se reinicia desde cero.*
2. **Abrir en NetBeans:** *File → Open Project* → carpeta `VetMVC` (la del `pom.xml`).
3. **Dependencias:** Maven descarga solo el conector de MySQL. Si sale en rojo:
   clic derecho al proyecto → **Reload POM** → *Dependencies* → **Download Declared Dependencies**
   → **Clean and Build**.
4. **Ejecutar:** clic derecho → *Run* (clase principal `vetmvc.Main`).

### Usuarios de prueba
| Usuario | Contraseña | Rol | Módulos que ve |
|---|---|---|---|
| `admin` | `admin123` | Administrador | Todos |
| `recepcion` | `recep123` | Recepcionista | Mascotas, Citas, Facturación |
| `vet` | `vet123` | Veterinario | Mascotas (solo consulta), Citas (registra atención), Inventario |

Tras **3 intentos fallidos** la cuenta se bloquea (para desbloquearla:
`UPDATE usuario SET intentos_fallidos = 0 WHERE username = 'vet';`).

## 3. Estructura

```
src/main/java/
├── modelo/                         ← MODELO (datos + SQL, nada de ventanas)
│   ├── Conexion.java               → conexión JDBC (usuario vet_app) y último error
│   ├── Usuario, Cliente, Mascota, Cita, Atencion,
│   │   Producto, Servicio, Comprobante, DetalleComprobante   → entidades (atributos, getters/setters, reglas simples)
│   └── ConsultasUsuario, ConsultasMascota, ConsultasCita,
│       ConsultasProducto, ConsultasComprobante               → CRUD en SQL (heredan de Conexion)
├── vista/                          ← VISTA (solo interfaz Swing)
│   ├── FrmLogin, FrmPrincipal, FrmMascota, FrmCita, FrmProducto, FrmComprobante
├── controlador/                    ← CONTROLADOR (escucha, valida, coordina)
│   ├── CtrlLogin, CtrlPrincipal, CtrlMascota, CtrlCita, CtrlProducto, CtrlComprobante
├── util/                           → PasswordUtil (cifrado), SesionUsuario (quién inició sesión), Mensajes (diálogos)
└── vetmvc/Main.java                → abre el login
sql/dr_sheep_vet.sql                → esquema completo + datos de ejemplo
```

## 4. Qué hace cada capa

| Capa | Responsabilidad | Lo que NO hace |
|---|---|---|
| **Modelo** | Guarda y consulta los datos en MySQL; contiene las reglas del dato (ej. IGV 18 %, stock crítico) | No sabe nada de ventanas |
| **Vista** | Muestra formularios, tablas y botones | No valida ni hace consultas |
| **Controlador** | Recibe el clic, valida lo que escribió el usuario, le pide al Modelo la operación y actualiza la Vista | No dibuja la interfaz ni escribe SQL |

**Flujo de "Guardar mascota":**
`clic en Guardar (Vista)` → `CtrlMascota.actionPerformed()` → `leerFormulario()` valida
→ `ConsultasMascota.insertar()` ejecuta el INSERT (y crea al cliente si el DNI no existe)
→ el controlador limpia el formulario y recarga la tabla (Vista).

**Armado de cada módulo** (lo hace `CtrlPrincipal` al pulsar el botón del menú):
```java
FrmCita vista = new FrmCita();                                   // Vista
new CtrlCita(new ConsultasCita(), new ConsultasUsuario(), vista) // Controlador = Modelo + Vista
        .iniciar();
vista.setVisible(true);
```

## 5. Funciones por módulo (trazabilidad con el documento)

| Pantalla | Requerimientos | Qué hace | Reglas / validaciones |
|---|---|---|---|
| **Login** (P01) | RF01 | Valida usuario y contraseña, registra el acceso en `log_auditoria` | Bloqueo a los 3 intentos; contraseña cifrada (PBKDF2) |
| **Menú** (P02) | — | Muestra usuario y rol; habilita módulos según el rol | Control por rol |
| **Clientes y mascotas** (P03, P04) | RF02–RF05 | Guardar, modificar, eliminar, buscar (mascota, especie, dueño o DNI), **historial médico** | DNI de 8 dígitos; si el DNI no existe se registra el cliente al guardar; peso 0–200 kg; fecha no futura; eliminación **lógica** (`activo = 0`) |
| **Agenda de citas** (P05) | RF06–RF08 | Programar, reprogramar, confirmar, cancelar, registrar atención (diagnóstico y tratamiento), ver agenda por día | No permite fechas pasadas ni **cruces de horario** del veterinario; estados PROGRAMADA → CONFIRMADA → ATENDIDA / CANCELADA |
| **Inventario** (P06) | RF09–RF11 | Productos, entradas y salidas, búsqueda, **alerta de stock mínimo** (fila en rojo + aviso) | El stock solo cambia con movimientos; el trigger rechaza salidas mayores al stock |
| **Facturación** (P07) | RF12–RF13 | Boleta de una atención: servicios + productos usados, subtotal, **IGV 18 %**, total, método de pago (efectivo/Yape/Plin/tarjeta), serie y número únicos (B001-000001) | Todo en una **transacción**: si falla (ej. stock insuficiente) no se guarda nada; los productos usados salen del inventario |

**Flujo completo de negocio:** *Mascotas* (registrar dueño y mascota) → *Citas* (programar → confirmar →
registrar atención) → *Facturación* (cobrar la atención) → *Inventario* (el stock se descuenta solo).

## 6. Seguridad aplicada (sección 9.3 del documento)
- La aplicación usa el usuario **`vet_app`** (SELECT, INSERT, UPDATE; sin DELETE ni DDL), **no root**.
  Si cambias su clave en el `.sql`, cámbiala también en `modelo/Conexion.java`.
- Todas las consultas usan `PreparedStatement` (sin concatenar datos del usuario → evita inyección SQL).
- Contraseñas con hash (PBKDF2-HmacSHA256, 65 536 iteraciones, sal aleatoria); nunca en texto plano.
- Eliminación lógica (`activo`) para conservar el historial; auditoría de inicios de sesión.

## 7. Notas y diferencias con el documento
- **Capas:** la clase pide solo **MVC**. Por eso las clases `Consultas*` cumplen a la vez el papel de acceso a
  datos (DAO) y de reglas simples; el documento describe además capas *servicio* y *DAO* separadas, que se
  pueden extraer después sin cambiar la Vista (aplicando SOLID: una responsabilidad por clase).
- **Contraseñas:** el documento menciona BCrypt; aquí se usa PBKDF2 porque viene incluido en el JDK y no
  requiere librerías externas. El resultado de seguridad es equivalente. Para cambiar una clave:
  `java -cp target/classes util.PasswordUtil nuevaClave` y pega el hash en `usuario.password_hash`.
- **Pendiente respecto al documento:** pantalla de *Reportes* (RF14). Las vistas SQL (`vw_stock_critico`,
  `vw_citas_detalle`, `vw_ingresos_diarios`) ya están creadas y solo falta la pantalla.
- Las ventanas están escritas a mano (no con el diseñador de NetBeans), por eso no tienen la pestaña *Design*.

## 8. Cómo agregar otro módulo
Copia el molde: `Entidad` + `ConsultasEntidad` (Modelo), `FrmEntidad` (Vista), `CtrlEntidad` (Controlador),
y agrega un botón en `FrmPrincipal` y un `else if` en `CtrlPrincipal`.
