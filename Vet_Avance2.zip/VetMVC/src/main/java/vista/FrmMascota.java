package vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableModel;

/**
 * VISTA - Clientes y mascotas (P03/P04). Solo interfaz, sin lógica ni consultas.
 * Los componentes son públicos para que el Controlador pueda escucharlos.
 */
public class FrmMascota extends JFrame {

    // Dueño (cliente)
    public JTextField txtDni = new JTextField();
    public JTextField txtDueno = new JTextField();
    public JTextField txtTelefono = new JTextField();
    public JTextField txtDireccion = new JTextField();
    public JButton btnBuscarDni = new JButton("Buscar dueño por DNI");

    // Mascota
    public JTextField txtId = new JTextField();
    public JTextField txtNombre = new JTextField();
    public JTextField txtEspecie = new JTextField();
    public JTextField txtRaza = new JTextField();
    public JComboBox<String> cmbSexo = new JComboBox<>(new String[]{"Macho", "Hembra"});
    public JTextField txtNacimiento = new JTextField();
    public JTextField txtPeso = new JTextField();

    public JTextField txtBuscar = new JTextField(22);
    public JButton btnBuscar = new JButton("Buscar");
    public JButton btnTodos = new JButton("Mostrar todos");

    public JButton btnGuardar = new JButton("Guardar");
    public JButton btnModificar = new JButton("Modificar");
    public JButton btnEliminar = new JButton("Eliminar");
    public JButton btnLimpiar = new JButton("Limpiar");
    public JButton btnHistorial = new JButton("Ver historial médico");

    public JLabel lblEstado = new JLabel(" ");
    public DefaultTableModel modeloTabla;
    public JTable tabla;

    public FrmMascota() {
        super("DR.SHEEP - Clientes y mascotas");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1000, 700);
        setLayout(new BorderLayout(8, 8));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtId.setEditable(false);

        JPanel panelBusqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        panelBusqueda.add(new JLabel("Buscar (mascota, especie, dueño o DNI):"));
        panelBusqueda.add(txtBuscar);
        panelBusqueda.add(btnBuscar);
        panelBusqueda.add(btnTodos);

        JPanel panelDueno = new JPanel(new GridLayout(2, 4, 8, 8));
        panelDueno.setBorder(BorderFactory.createTitledBorder("Dueño (si el DNI no existe, se registra al guardar)"));
        panelDueno.add(new JLabel("DNI:"));
        panelDueno.add(txtDni);
        panelDueno.add(new JLabel("Nombres:"));
        panelDueno.add(txtDueno);
        panelDueno.add(new JLabel("Teléfono:"));
        panelDueno.add(txtTelefono);
        panelDueno.add(new JLabel("Dirección:"));
        panelDueno.add(txtDireccion);

        JPanel buscarDni = new JPanel(new FlowLayout(FlowLayout.LEFT));
        buscarDni.add(btnBuscarDni);

        JPanel panelMascota = new JPanel(new GridLayout(4, 4, 8, 8));
        panelMascota.setBorder(BorderFactory.createTitledBorder("Datos de la mascota"));
        panelMascota.add(new JLabel("ID:"));
        panelMascota.add(txtId);
        panelMascota.add(new JLabel("Nombre:"));
        panelMascota.add(txtNombre);
        panelMascota.add(new JLabel("Especie:"));
        panelMascota.add(txtEspecie);
        panelMascota.add(new JLabel("Raza:"));
        panelMascota.add(txtRaza);
        panelMascota.add(new JLabel("Sexo:"));
        panelMascota.add(cmbSexo);
        panelMascota.add(new JLabel("Nacimiento (aaaa-mm-dd):"));
        panelMascota.add(txtNacimiento);
        panelMascota.add(new JLabel("Peso (kg):"));
        panelMascota.add(txtPeso);
        panelMascota.add(new JLabel(""));
        panelMascota.add(new JLabel(""));

        JPanel formularios = new JPanel(new BorderLayout(0, 6));
        JPanel dueno = new JPanel(new BorderLayout());
        dueno.add(panelDueno, BorderLayout.CENTER);
        dueno.add(buscarDni, BorderLayout.SOUTH);
        formularios.add(dueno, BorderLayout.NORTH);
        formularios.add(panelMascota, BorderLayout.CENTER);

        JPanel norte = new JPanel(new BorderLayout(0, 8));
        norte.add(panelBusqueda, BorderLayout.NORTH);
        norte.add(formularios, BorderLayout.CENTER);
        add(norte, BorderLayout.NORTH);

        String[] columnas = {"ID", "Mascota", "Especie", "Raza", "Sexo", "Nacimiento", "Peso (kg)",
            "DNI", "Dueño", "Teléfono", "Dirección"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(24);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 4));
        botones.add(btnGuardar);
        botones.add(btnModificar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);
        botones.add(btnHistorial);
        JPanel sur = new JPanel(new BorderLayout());
        sur.add(botones, BorderLayout.CENTER);
        sur.add(lblEstado, BorderLayout.SOUTH);
        add(sur, BorderLayout.SOUTH);
    }
}
