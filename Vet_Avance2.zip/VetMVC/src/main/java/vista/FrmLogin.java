package vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JTextField;

/** VISTA - Pantalla de inicio de sesión (P01). Solo interfaz, sin lógica. */
public class FrmLogin extends JFrame {

    public JTextField txtUsuario = new JTextField(16);
    public JPasswordField txtClave = new JPasswordField(16);
    public JButton btnIngresar = new JButton("Ingresar");
    public JLabel lblMensaje = new JLabel(" ", JLabel.CENTER);

    public FrmLogin() {
        super("DR.SHEEP - Iniciar sesión");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(380, 280);
        setResizable(false);
        setLayout(new BorderLayout(8, 8));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(14, 20, 14, 20));

        JLabel titulo = new JLabel("DR.SHEEP Veterinaria", JLabel.CENTER);
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 20f));
        add(titulo, BorderLayout.NORTH);

        JPanel form = new JPanel(new GridLayout(2, 2, 8, 12));
        form.add(new JLabel("Usuario:"));
        form.add(txtUsuario);
        form.add(new JLabel("Contraseña:"));
        form.add(txtClave);
        JPanel centro = new JPanel(new FlowLayout(FlowLayout.CENTER, 0, 20));
        centro.add(form);
        add(centro, BorderLayout.CENTER);

        JPanel sur = new JPanel(new GridLayout(2, 1, 0, 6));
        JPanel fila = new JPanel(new FlowLayout(FlowLayout.CENTER));
        fila.add(btnIngresar);
        sur.add(fila);
        lblMensaje.setForeground(java.awt.Color.RED.darker());
        sur.add(lblMensaje);
        add(sur, BorderLayout.SOUTH);

        getRootPane().setDefaultButton(btnIngresar);   // Enter = Ingresar
    }
}
