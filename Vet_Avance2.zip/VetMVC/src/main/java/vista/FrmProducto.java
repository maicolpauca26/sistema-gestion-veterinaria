package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;

/** VISTA - Inventario (P06). Solo interfaz, sin lógica ni consultas. */
public class FrmProducto extends JFrame {

    public JTextField txtId = new JTextField();
    public JTextField txtCodigo = new JTextField();
    public JTextField txtNombre = new JTextField();
    public JTextField txtPrecio = new JTextField();
    public JTextField txtStockMinimo = new JTextField();
    public JTextField txtStock = new JTextField();
    public JTextField txtCantidad = new JTextField();

    public JTextField txtBuscar = new JTextField(20);
    public JButton btnBuscar = new JButton("Buscar");
    public JButton btnTodos = new JButton("Mostrar todos");
    public JButton btnCriticos = new JButton("Ver stock crítico");

    public JButton btnGuardar = new JButton("Guardar");
    public JButton btnModificar = new JButton("Modificar");
    public JButton btnEliminar = new JButton("Eliminar");
    public JButton btnLimpiar = new JButton("Limpiar");
    public JButton btnEntrada = new JButton("Registrar ENTRADA");
    public JButton btnSalida = new JButton("Registrar SALIDA");

    public JLabel lblAlerta = new JLabel(" ");
    public JLabel lblEstado = new JLabel(" ");
    public DefaultTableModel modeloTabla;
    public JTable tabla;

    public FrmProducto() {
        super("DR.SHEEP - Inventario");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(980, 660);
        setLayout(new BorderLayout(8, 8));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtId.setEditable(false);
        txtStock.setEditable(false);
        lblAlerta.setForeground(Color.RED.darker());

        JPanel busqueda = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        busqueda.add(new JLabel("Buscar (código o nombre):"));
        busqueda.add(txtBuscar);
        busqueda.add(btnBuscar);
        busqueda.add(btnTodos);
        busqueda.add(btnCriticos);

        JPanel form = new JPanel(new GridLayout(4, 4, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Datos del producto"));
        form.add(new JLabel("ID:"));
        form.add(txtId);
        form.add(new JLabel("Código:"));
        form.add(txtCodigo);
        form.add(new JLabel("Nombre:"));
        form.add(txtNombre);
        form.add(new JLabel("Precio (S/):"));
        form.add(txtPrecio);
        form.add(new JLabel("Stock mínimo:"));
        form.add(txtStockMinimo);
        form.add(new JLabel("Stock actual:"));
        form.add(txtStock);
        form.add(new JLabel("Cantidad del movimiento:"));
        form.add(txtCantidad);
        form.add(new JLabel(""));
        form.add(new JLabel(""));

        JPanel norte = new JPanel(new BorderLayout(0, 8));
        JPanel arriba = new JPanel(new BorderLayout());
        arriba.add(busqueda, BorderLayout.NORTH);
        arriba.add(lblAlerta, BorderLayout.SOUTH);
        norte.add(arriba, BorderLayout.NORTH);
        norte.add(form, BorderLayout.CENTER);
        add(norte, BorderLayout.NORTH);

        String[] columnas = {"ID", "Código", "Producto", "Precio (S/)", "Stock", "Mínimo"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new JTable(modeloTabla) {
            // Fila en rojo cuando stock <= mínimo (alerta visible)
            @Override
            public Component prepareRenderer(javax.swing.table.TableCellRenderer r, int fila, int col) {
                Component c = super.prepareRenderer(r, fila, col);
                if (!isRowSelected(fila)) {
                    int stock = Integer.parseInt(getValueAt(fila, 4).toString());
                    int min = Integer.parseInt(getValueAt(fila, 5).toString());
                    c.setForeground(stock <= min ? Color.RED.darker() : Color.BLACK);
                }
                return c;
            }
        };
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(24);
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 4));
        botones.add(btnGuardar);
        botones.add(btnModificar);
        botones.add(btnEliminar);
        botones.add(btnLimpiar);
        botones.add(btnEntrada);
        botones.add(btnSalida);
        JPanel sur = new JPanel(new BorderLayout());
        sur.add(botones, BorderLayout.CENTER);
        sur.add(lblEstado, BorderLayout.SOUTH);
        add(sur, BorderLayout.SOUTH);
    }
}
