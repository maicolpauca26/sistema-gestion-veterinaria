package vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

/** VISTA - Menú principal (P02): muestra el usuario con su rol y los módulos. */
public class FrmPrincipal extends JFrame {

    public JLabel lblUsuario = new JLabel(" ");
    public JButton btnMascotas = new JButton("Clientes y mascotas");
    public JButton btnCitas = new JButton("Agenda de citas");
    public JButton btnInventario = new JButton("Inventario");
    public JButton btnFacturacion = new JButton("Facturación");
    public JButton btnCerrarSesion = new JButton("Cerrar sesión");

    public FrmPrincipal() {
        super("DR.SHEEP - Sistema Integral de Gestión Veterinaria");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(520, 380);
        setLayout(new BorderLayout(10, 10));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(12, 16, 12, 16));

        JPanel norte = new JPanel(new BorderLayout());
        JLabel titulo = new JLabel("Menú principal");
        titulo.setFont(titulo.getFont().deriveFont(Font.BOLD, 20f));
        norte.add(titulo, BorderLayout.WEST);
        norte.add(lblUsuario, BorderLayout.EAST);
        add(norte, BorderLayout.NORTH);

        JPanel menu = new JPanel(new GridLayout(2, 2, 14, 14));
        for (JButton b : new JButton[]{btnMascotas, btnCitas, btnInventario, btnFacturacion}) {
            b.setFont(b.getFont().deriveFont(Font.BOLD, 15f));
            menu.add(b);
        }
        add(menu, BorderLayout.CENTER);

        JPanel sur = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        sur.add(btnCerrarSesion);
        add(sur, BorderLayout.SOUTH);
    }
}
