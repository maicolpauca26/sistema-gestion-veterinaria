package vista;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import modelo.Cita;
import modelo.Mascota;
import modelo.Usuario;

/** VISTA - Agenda de citas (P05). Solo interfaz, sin lógica ni consultas. */
public class FrmCita extends JFrame {

    public JTextField txtId = new JTextField();
    public JComboBox<Mascota> cmbMascota = new JComboBox<>();
    public JComboBox<Usuario> cmbVeterinario = new JComboBox<>();
    public JTextField txtFecha = new JTextField();
    public JComboBox<String> cmbHora = new JComboBox<>();
    public JTextField txtMotivo = new JTextField();
    public JTextField txtDiagnostico = new JTextField();
    public JTextField txtTratamiento = new JTextField();

    public JTextField txtFiltroFecha = new JTextField(10);
    public JButton btnVerDia = new JButton("Ver día");
    public JButton btnTodas = new JButton("Ver todas");

    public JButton btnProgramar = new JButton("Programar");
    public JButton btnModificar = new JButton("Reprogramar");
    public JButton btnConfirmar = new JButton("Confirmar");
    public JButton btnCancelar = new JButton("Cancelar cita");
    public JButton btnAtender = new JButton("Registrar atención");
    public JButton btnLimpiar = new JButton("Limpiar");

    public JLabel lblEstado = new JLabel(" ");
    public DefaultTableModel modeloTabla;
    public JTable tabla;

    public FrmCita() {
        super("DR.SHEEP - Agenda de citas");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1000, 680);
        setLayout(new BorderLayout(8, 8));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        txtId.setEditable(false);
        for (int h = 8; h <= 19; h++) {
            cmbHora.addItem(String.format("%02d:00", h));
            cmbHora.addItem(String.format("%02d:30", h));
        }

        JPanel filtro = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
        filtro.add(new JLabel("Fecha (aaaa-mm-dd):"));
        filtro.add(txtFiltroFecha);
        filtro.add(btnVerDia);
        filtro.add(btnTodas);

        JPanel form = new JPanel(new GridLayout(4, 4, 8, 8));
        form.setBorder(BorderFactory.createTitledBorder("Datos de la cita"));
        form.add(new JLabel("ID:"));
        form.add(txtId);
        form.add(new JLabel("Mascota:"));
        form.add(cmbMascota);
        form.add(new JLabel("Veterinario:"));
        form.add(cmbVeterinario);
        form.add(new JLabel("Motivo:"));
        form.add(txtMotivo);
        form.add(new JLabel("Fecha (aaaa-mm-dd):"));
        form.add(txtFecha);
        form.add(new JLabel("Hora:"));
        form.add(cmbHora);
        form.add(new JLabel("Diagnóstico (atención):"));
        form.add(txtDiagnostico);
        form.add(new JLabel("Tratamiento (atención):"));
        form.add(txtTratamiento);

        JPanel norte = new JPanel(new BorderLayout(0, 8));
        norte.add(filtro, BorderLayout.NORTH);
        norte.add(form, BorderLayout.CENTER);
        add(norte, BorderLayout.NORTH);

        String[] columnas = {"ID", "Fecha", "Hora", "Mascota", "Dueño", "Veterinario", "Motivo", "Estado"};
        modeloTabla = new DefaultTableModel(columnas, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tabla = new JTable(modeloTabla);
        tabla.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tabla.setRowHeight(24);
        // Color de la columna Estado
        tabla.getColumnModel().getColumn(7).setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable t, Object v, boolean sel, boolean foco,
                                                           int fila, int col) {
                Component c = super.getTableCellRendererComponent(t, v, sel, foco, fila, col);
                if (!sel) {
                    String e = String.valueOf(v);
                    c.setForeground(e.equals(Cita.CANCELADA) ? Color.RED.darker()
                            : e.equals(Cita.ATENDIDA) ? new Color(0, 110, 0)
                            : e.equals(Cita.CONFIRMADA) ? new Color(0, 70, 160) : Color.BLACK);
                }
                return c;
            }
        });
        add(new JScrollPane(tabla), BorderLayout.CENTER);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 4));
        botones.add(btnProgramar);
        botones.add(btnModificar);
        botones.add(btnConfirmar);
        botones.add(btnCancelar);
        botones.add(btnAtender);
        botones.add(btnLimpiar);
        JPanel sur = new JPanel(new BorderLayout());
        sur.add(botones, BorderLayout.CENTER);
        sur.add(lblEstado, BorderLayout.SOUTH);
        add(sur, BorderLayout.SOUTH);
    }
}
