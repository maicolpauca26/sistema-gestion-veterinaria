package vista;

import java.awt.BorderLayout;
import java.awt.FlowLayout;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSpinner;
import javax.swing.JTable;
import javax.swing.ListSelectionModel;
import javax.swing.SpinnerNumberModel;
import javax.swing.table.DefaultTableModel;
import modelo.Atencion;
import modelo.Producto;
import modelo.Servicio;

/** VISTA - Facturación (P07). Solo interfaz, sin lógica ni consultas. */
public class FrmComprobante extends JFrame {

    public JComboBox<Atencion> cmbAtencion = new JComboBox<>();
    public JComboBox<Servicio> cmbServicio = new JComboBox<>();
    public JSpinner spnServicio = new JSpinner(new SpinnerNumberModel(1, 1, 99, 1));
    public JButton btnAgregarServicio = new JButton("Agregar servicio");
    public JComboBox<Producto> cmbProducto = new JComboBox<>();
    public JSpinner spnProducto = new JSpinner(new SpinnerNumberModel(1, 1, 999, 1));
    public JButton btnAgregarProducto = new JButton("Agregar producto");

    public JComboBox<String> cmbPago = new JComboBox<>(new String[]{"EFECTIVO", "YAPE", "PLIN", "TARJETA"});
    public JLabel lblSubtotal = new JLabel("S/ 0.00");
    public JLabel lblIgv = new JLabel("S/ 0.00");
    public JLabel lblTotal = new JLabel("S/ 0.00");

    public JButton btnQuitar = new JButton("Quitar línea");
    public JButton btnEmitir = new JButton("Emitir comprobante");
    public JButton btnLimpiar = new JButton("Limpiar");

    public JLabel lblEstado = new JLabel(" ");
    public DefaultTableModel modeloDetalle;
    public JTable tablaDetalle;
    public DefaultTableModel modeloEmitidos;
    public JTable tablaEmitidos;

    public FrmComprobante() {
        super("DR.SHEEP - Facturación");
        setDefaultCloseOperation(DISPOSE_ON_CLOSE);
        setSize(1020, 720);
        setLayout(new BorderLayout(8, 8));
        ((JPanel) getContentPane()).setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JPanel selector = new JPanel(new GridLayout(3, 4, 8, 8));
        selector.setBorder(BorderFactory.createTitledBorder("Nueva boleta"));
        selector.add(new JLabel("Atención a cobrar:"));
        selector.add(cmbAtencion);
        selector.add(new JLabel(""));
        selector.add(new JLabel(""));
        selector.add(new JLabel("Servicio:"));
        selector.add(cmbServicio);
        selector.add(spnServicio);
        selector.add(btnAgregarServicio);
        selector.add(new JLabel("Producto usado:"));
        selector.add(cmbProducto);
        selector.add(spnProducto);
        selector.add(btnAgregarProducto);
        add(selector, BorderLayout.NORTH);

        modeloDetalle = new DefaultTableModel(new String[]{"Descripción", "Cant.", "P. unitario (S/)", "Subtotal (S/)"}, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tablaDetalle = new JTable(modeloDetalle);
        tablaDetalle.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        tablaDetalle.setRowHeight(24);

        JPanel totales = new JPanel(new GridLayout(4, 2, 6, 6));
        totales.add(new JLabel("Subtotal:"));
        totales.add(lblSubtotal);
        totales.add(new JLabel("IGV (18 %):"));
        totales.add(lblIgv);
        totales.add(new JLabel("TOTAL:"));
        lblTotal.setFont(lblTotal.getFont().deriveFont(Font.BOLD, 16f));
        totales.add(lblTotal);
        totales.add(new JLabel("Método de pago:"));
        totales.add(cmbPago);
        JPanel panelTotales = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelTotales.add(totales);

        JPanel botones = new JPanel(new FlowLayout(FlowLayout.CENTER, 12, 4));
        botones.add(btnQuitar);
        botones.add(btnEmitir);
        botones.add(btnLimpiar);

        JPanel bloqueDetalle = new JPanel(new BorderLayout(4, 4));
        bloqueDetalle.add(new JScrollPane(tablaDetalle), BorderLayout.CENTER);
        JPanel pieDetalle = new JPanel(new BorderLayout());
        pieDetalle.add(panelTotales, BorderLayout.NORTH);
        pieDetalle.add(botones, BorderLayout.SOUTH);
        bloqueDetalle.add(pieDetalle, BorderLayout.SOUTH);

        modeloEmitidos = new DefaultTableModel(
                new String[]{"N.º", "Fecha", "Cliente", "Pago", "Subtotal", "IGV", "Total"}, 0) {
            @Override
            public boolean isCellEditable(int fila, int columna) {
                return false;
            }
        };
        tablaEmitidos = new JTable(modeloEmitidos);
        tablaEmitidos.setRowHeight(22);
        JPanel bloqueEmitidos = new JPanel(new BorderLayout());
        bloqueEmitidos.setBorder(BorderFactory.createTitledBorder("Comprobantes emitidos"));
        bloqueEmitidos.add(new JScrollPane(tablaEmitidos), BorderLayout.CENTER);

        JPanel centro = new JPanel(new GridLayout(2, 1, 8, 8));
        centro.add(bloqueDetalle);
        centro.add(bloqueEmitidos);
        add(centro, BorderLayout.CENTER);
        add(lblEstado, BorderLayout.SOUTH);
    }
}
