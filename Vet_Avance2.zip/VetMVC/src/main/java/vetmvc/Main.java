package vetmvc;

import controlador.CtrlLogin;
import javax.swing.SwingUtilities;
import javax.swing.UIManager;
import modelo.ConsultasUsuario;
import vista.FrmLogin;

/**
 * Punto de entrada: abre el login. Después de iniciar sesión, el menú principal
 * crea el Modelo, la Vista y el Controlador de cada módulo y los conecta.
 */
public class Main {

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignorada) {
            // si falla, Swing usa su aspecto por defecto
        }

        SwingUtilities.invokeLater(() -> {
            ConsultasUsuario modelo = new ConsultasUsuario();
            FrmLogin vista = new FrmLogin();
            CtrlLogin controlador = new CtrlLogin(modelo, vista);
            controlador.iniciar();
        });
    }
}
