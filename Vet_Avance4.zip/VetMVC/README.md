# VetMVC — DR.SHEEP · Sistema Integral de Gestión Veterinaria (MVC + DAO + Servicios, con TDD y SOLID)

Aplicación de escritorio con **Java Swing + MySQL**, organizada en **Modelo – Vista – Controlador** y, por debajo, capas de **Servicio** y **DAO** (ver `docs/TDD_DAO_SOLID.md`), con pruebas unitarias escritas con **TDD**.
Cubre los 4 procesos del alcance del proyecto (citas, mascotas, inventario y facturación) más el
inicio de sesión con roles. Es la **Alternativa 1** del documento *Avance de Proyecto Final 2*.

| Login | Menú principal |
|---|---|
| ![Login](docs/login.png) | ![Menú](docs/menu.png) |

![Clientes y mascotas](docs/mascotas.png)
![Agenda de citas](docs/citas.png)
![Inventario](docs/inventario.png)
![Facturación](docs/facturacion.png)

## 1. Requisitos
- JDK 11 o superior (probado con 21) y NetBeans (proyecto Maven).
- MySQL de Laragon iniciado (usuario `root`, sin contraseña, solo para crear la base).

## 2. Cómo ponerlo a funcionar
1. **Crear la base de datos:** ejecuta `sql/dr_sheep_vet.sql` **una sola vez** (HeidiSQL: abrir el
   archivo y pulsar F9; o en consola: `mysql -u root < sql/dr_sheep_vet.sql`).
   Crea la BD `dr_sheep_vet`, las tablas, el trigger de stock, las vistas, el usuario `vet_app`
   y los datos de ejemplo. *Si lo vuelves a ejecutar, la base se reinicia desde cero.*
2. **Abrir en NetBeans:** *File → Open Project* → carpeta `VetMVC` (la del `pom.xml`).
3. **Dependencias:** Maven descarga solo el conector de MySQL. Si sale en rojo:
   clic derecho al proyecto → **Reload POM** → *Dependencies* → **Download Declared Dependencies**
   → **Clean and Build**.
4. **Ejecutar:** clic derecho → *Run* (clase principal `vetmvc.Main`).
5. **Pruebas (TDD):** clic derecho al proyecto → *Test* (Alt+F6) o en consola `mvn test`. No necesitan MySQL.

### Usuarios de prueba
| Usuario | Contraseña | Rol | Módulos que ve |
|---|---|---|---|
| `admin` | `admin123` | Administrador | Todos |
| `recepcion` | `recep123` | Recepcionista | Mascotas, Citas, Facturación |
| `vet` | `vet123` | Veterinario | Mascotas (solo consulta), Citas (registra atención), Inventario |

Tras **3 intentos fallidos** la cuenta se bloquea (para desbloquearla:
`UPDATE usuario SET intentos_fallidos = 0 WHERE username = 'vet';`).

## 3. Estructura

```
src/main/java/
├── vista/        ← VISTA (solo interfaz Swing): FrmLogin, FrmPrincipal, FrmMascota, FrmCita, FrmProducto, FrmComprobante, Tema
├── controlador/  ← CONTROLADOR (escucha clics, lee la Vista, llama al Servicio, muestra el resultado)
│   └── ControladorBase, CtrlLogin, CtrlPrincipal, CtrlMascota, CtrlCita, CtrlProducto, CtrlComprobante
├── servicio/     ← REGLAS DE NEGOCIO (validaciones, cruce de horarios, stock, IGV...) — sin Swing y sin SQL
│   └── AutenticacionService, MascotaService (+ MascotaValidador), CitaService, InventarioService, FacturacionService
│       + formularios (MascotaFormulario, CitaFormulario, ProductoFormulario), ResultadoLogin, ValidacionException
├── dao/          ← DAO: INTERFACES de acceso a datos (CredencialDAO, UsuarioDAO, ClienteDAO, MascotaDAO, CitaDAO,
│   │               ProductoDAO, MovimientoInventarioDAO, ServicioDAO, ComprobanteDAO) y DaoException
│   └── jdbc/     ← IMPLEMENTACIONES JDBC/MySQL (*DAOJdbc), ProveedorConexion y ConexionMySQL — aquí está todo el SQL
├── modelo/       ← ENTIDADES y reglas del dato: Usuario, Cliente, Mascota, Cita, CitaEstado, Atencion, Producto,
│                   Servicio, Comprobante, DetalleComprobante, CredencialUsuario, TipoMovimiento
├── seguridad/    ← PoliticaPermisos + Permiso (qué puede hacer cada rol), PasswordHasher + Pbkdf2PasswordHasher
├── config/       ← Contenedor: único lugar que arma DAO → Servicio (raíz de composición)
├── util/         → PasswordUtil (cifrado), Mensajes (diálogos)
└── vetmvc/Main.java → crea el Contenedor y abre el login
src/test/java/   ← PRUEBAS (JUnit 5) + dobles en memoria (carpeta doble/)
sql/dr_sheep_vet.sql → esquema completo + datos de ejemplo
docs/TDD_DAO_SOLID.md → explicación de TDD, DAO y SOLID aplicados
```

## 4. Qué hace cada capa

| Capa | Responsabilidad | Lo que NO hace |
|---|---|---|
| **Vista** | Muestra formularios, tablas y botones | No valida ni consulta |
| **Controlador** | Recibe el clic, lee los campos, llama al Servicio y actualiza la Vista | No valida reglas ni escribe SQL |
| **Servicio** | Aplica las reglas de negocio y valida | No sabe de ventanas ni de SQL |
| **DAO (interfaz)** | Define *qué* datos se piden/guardan | No dice *cómo* |
| **DAO JDBC** | Ejecuta el SQL en MySQL, maneja la transacción | No tiene reglas de negocio |
| **Modelo** | Entidades y reglas propias del dato (IGV 18 %, stock crítico, estados de la cita) | No conoce nada de lo demás |

Los errores viajan así: `DaoException` (falló la BD → mensaje de error) y `ValidacionException` (dato o regla inválida → aviso).

**Flujo de "Guardar mascota":**
`clic en Guardar (Vista)` → `CtrlMascota` lee los textos y arma un `MascotaFormulario` → `MascotaService.registrar()`
valida con `MascotaValidador` → `MascotaDAO.insertar()` (implementado por `MascotaDAOJdbc`, crea al cliente si el DNI no existe)
→ el controlador limpia el formulario y recarga la tabla.

**Armado de cada módulo** (lo hace `CtrlPrincipal` al pulsar el botón del menú, con los servicios del `Contenedor`):
```java
FrmCita vista = new FrmCita();
new CtrlCita(contenedor.citas(), vista, usuario, contenedor.permisos()).iniciar();
vista.setVisible(true);
```

## 5. Funciones por módulo (trazabilidad con el documento)

| Pantalla | Requerimientos | Qué hace | Reglas / validaciones |
|---|---|---|---|
| **Login** (P01) | RF01 | Valida usuario y contraseña, registra el acceso en `log_auditoria` | Bloqueo a los 3 intentos; contraseña cifrada (PBKDF2) |
| **Menú** (P02) | — | Muestra usuario y rol; habilita módulos según el rol | Control por rol |
| **Clientes y mascotas** (P03, P04) | RF02–RF05 | Guardar, modificar, eliminar, buscar (mascota, especie, dueño o DNI), **historial médico** | DNI de 8 dígitos; si el DNI no existe se registra el cliente al guardar; peso 0–200 kg; fecha no futura; eliminación **lógica** (`activo = 0`) |
| **Agenda de citas** (P05) | RF06–RF08 | Programar, reprogramar, confirmar, cancelar, registrar atención (diagnóstico y tratamiento), ver agenda por día | No permite fechas pasadas ni **cruces de horario** del veterinario; estados PROGRAMADA → CONFIRMADA → ATENDIDA / CANCELADA |
| **Inventario** (P06) | RF09–RF11 | Productos, entradas y salidas, búsqueda, **alerta de stock mínimo** (fila en rojo + aviso) | El stock solo cambia con movimientos; el trigger rechaza salidas mayores al stock |
| **Facturación** (P07) | RF12–RF13 | Boleta de una atención: servicios + productos usados, subtotal, **IGV 18 %**, total, método de pago (efectivo/Yape/Plin/tarjeta), serie y número únicos (B001-000001) | Todo en una **transacción**: si falla (ej. stock insuficiente) no se guarda nada; los productos usados salen del inventario |

**Flujo completo de negocio:** *Mascotas* (registrar dueño y mascota) → *Citas* (programar → confirmar →
registrar atención) → *Facturación* (cobrar la atención) → *Inventario* (el stock se descuenta solo).

## 5.1 Tema visual (interfaz)
Todo el diseño está en **`vista/Tema.java`** (capa Vista; los controladores y el modelo no lo conocen) y no usa
librerías externas: Java Swing con Nimbus + dibujo propio.
- **Cambiar colores:** edita la paleta al inicio de `Tema.java` (`PRIMARIO`, `PRIMARIO_OSC`, `FONDO`, ...).
  Con un solo cambio se repinta cabecera, botones, tablas e íconos de todas las ventanas.
- **Botones:** `Tema.primario(btn)` (verde), `Tema.secundario(btn)` (contorno) y `Tema.peligro(btn)` (rojo).
- **Tarjetas, formularios y tablas:** `Tema.tarjeta(...)`, `Tema.formulario(...)`, `Tema.scroll(tabla)`.
- **Ventana nueva:** `Tema.marco(this, "Título", "Subtítulo", Tema.Icono.PATA, null, cuerpo)` agrega la cabecera.
- Los íconos (patita, calendario, caja, boleta) se dibujan con Java2D: no necesitan archivos de imagen.

## 6. Seguridad aplicada (sección 9.3 del documento)
- La aplicación usa el usuario **`vet_app`** (SELECT, INSERT, UPDATE; sin DELETE ni DDL), **no root**.
  Si cambias su clave en el `.sql`, cámbiala también en `dao/jdbc/ConexionMySQL.java`.
- Todas las consultas usan `PreparedStatement` (sin concatenar datos del usuario → evita inyección SQL).
- Contraseñas con hash (PBKDF2-HmacSHA256, 65 536 iteraciones, sal aleatoria); nunca en texto plano.
- Eliminación lógica (`activo`) para conservar el historial; auditoría de inicios de sesión.

## 7. Pruebas (TDD)
- `mvn test` (o *Test Project* en NetBeans) ejecuta **94 pruebas** sin necesitar MySQL: los servicios se prueban con DAO en memoria
  (`src/test/java/doble`) y los DAO JDBC con una conexión espía (`ConexionEspia`).
- Cubren: login y bloqueo a 3 intentos, permisos por rol, validación de mascotas, cruce de horarios, estados de la cita,
  stock y movimientos, IGV 18 %, emisión de boleta, y el SQL/transacciones del DAO de citas.
- Para agregar una regla nueva: escribe primero la prueba (debe fallar), luego el código mínimo que la hace pasar, y después limpia.

## 8. Notas y diferencias con el documento
- **Capas:** ahora existen las capas *servicio* y *DAO* que describe el documento; las antiguas `Consultas*` se separaron en
  interfaz DAO + implementación JDBC + servicio.
- **Contraseñas:** el documento menciona BCrypt; aquí se usa PBKDF2 porque viene incluido en el JDK y no
  requiere librerías externas. Para cambiar una clave:
  `java -cp target/classes util.PasswordUtil nuevaClave` y pega el hash en `usuario.password_hash`.
- **Pendiente respecto al documento:** pantalla de *Reportes* (RF14). Las vistas SQL (`vw_stock_critico`,
  `vw_citas_detalle`, `vw_ingresos_diarios`) ya están creadas y solo falta la pantalla.
- Las ventanas están escritas a mano (no con el diseñador de NetBeans), por eso no tienen la pestaña *Design*.

## 9. Cómo agregar otro módulo
1. **Prueba primero:** `XxxServiceTest` con un `XxxDAOFalso` en `src/test/java/doble`.
2. **Modelo:** `Entidad`. **DAO:** interfaz `XxxDAO` (en `dao/`) e implementación `XxxDAOJdbc` (en `dao/jdbc/`).
3. **Servicio:** `XxxService` con las reglas. **Vista:** `FrmXxx`. **Controlador:** `CtrlXxx extends ControladorBase`.
4. Conecta todo en `config/Contenedor.java`, agrega un `Permiso` en `seguridad/` y el botón en `FrmPrincipal` + `CtrlPrincipal`.
