# VetMVC — TDD, DAO y SOLID aplicados

Este documento explica **qué se cambió** en VetMVC y **dónde está cada cosa** en el código.

## 1. El problema del código original

Antes, cada módulo tenía solo dos clases con mucha carga:

| Clase | Hacía a la vez |
|---|---|
| `ConsultasCita` (Modelo) | SQL + reglas de negocio (estados válidos) + abrir conexión + guardar el último error |
| `CtrlCita` (Controlador) | leer la pantalla + **validar reglas** (fecha pasada, cruce de horario) + permisos por rol + armar la tabla |
| `CtrlPrincipal` | permisos por rol + `new ConsultasX()` (creaba sus propias dependencias) |

Eso no se podía probar sin MySQL ni sin abrir ventanas, y cada cambio tocaba varias cosas a la vez.

## 2. Arquitectura nueva

```
Vista (Swing)  →  Controlador  →  Servicio  →  DAO (interfaz)  ←  DAO JDBC (MySQL)
                                     │
                                     └→ Modelo (entidades y reglas del dato)
```

Todo se conecta en un solo lugar: `config/Contenedor.java` (raíz de composición).

## 3. DAO (Data Access Object)

Un **DAO** es una clase que encapsula *todo* el acceso a la base de datos de una entidad. El resto del sistema pide
datos a través de una **interfaz** y no sabe si por debajo hay MySQL, otro motor o una lista en memoria.

| Interfaz (`dao/`) | Implementación (`dao/jdbc/`) | Antes |
|---|---|---|
| `CredencialDAO`, `UsuarioDAO` | `UsuarioDAOJdbc` | `ConsultasUsuario` |
| `ClienteDAO` | `ClienteDAOJdbc` (+ `ClienteSql`) | parte de `ConsultasMascota` |
| `MascotaDAO` | `MascotaDAOJdbc` | `ConsultasMascota` |
| `CitaDAO` | `CitaDAOJdbc` | `ConsultasCita` |
| `ProductoDAO`, `MovimientoInventarioDAO` | `ProductoDAOJdbc`, `MovimientoInventarioDAOJdbc` | `ConsultasProducto` |
| `ServicioDAO`, `ComprobanteDAO` | `ServicioDAOJdbc`, `ComprobanteDAOJdbc` | `ConsultasComprobante` |

Mejoras concretas:
- `JdbcDAO` centraliza abrir/cerrar conexión, `commit`/`rollback` y la conversión de `SQLException` → `DaoException`.
  Cada DAO solo contiene su SQL.
- Se eliminó el patrón `ultimoError` (había que acordarse de consultarlo después de cada llamada). Ahora un fallo de BD
  **lanza** `DaoException` y no se puede ignorar por descuido.
- `horarioOcupado` antes devolvía `true` ante un error de BD (confundía "error" con "ocupado"); ahora lanza `DaoException`.
- `ConsultasCita.listarMascotas()` llamaba a otro DAO por dentro; ahora cada servicio recibe los DAO que necesita.

## 4. SOLID — dónde se aplica cada principio

| Principio | Cómo se aplicó | Dónde verlo |
|---|---|---|
| **S** — Responsabilidad única | Cada clase hace una sola cosa: la Vista dibuja, el Controlador coordina, el Servicio aplica reglas, el DAO ejecuta SQL. Las validaciones de mascota salieron a `MascotaValidador`. El comportamiento común de los controladores (mostrar estado, traducir errores) está en `ControladorBase`. | `servicio/`, `dao/jdbc/`, `controlador/ControladorBase` |
| **O** — Abierto/cerrado | Los permisos por rol eran `if/else` repartidos; ahora son una **tabla** en `PoliticaPermisos` (rol nuevo = una línea). Las transiciones de la cita viven en el enum `CitaEstado` y el DAO arma su `UPDATE ... IN (...)` a partir de ellas: un estado nuevo no obliga a editar SQL ni controladores. | `seguridad/PoliticaPermisos`, `modelo/CitaEstado` |
| **L** — Sustitución de Liskov | Cualquier implementación de un DAO se puede usar en lugar de otra sin que el servicio note la diferencia: las pruebas usan `CitaDAOFalso` (en memoria) y producción usa `CitaDAOJdbc`, y los mismos servicios funcionan con ambos con el mismo contrato (`false` = no se pudo, `DaoException` = falló la BD). | `src/test/java/doble/*`, `dao/*DAO` |
| **I** — Segregación de interfaces | Interfaces pequeñas, cada cliente depende solo de lo que usa: `AutenticacionService` solo ve `CredencialDAO` (no `listarVeterinarios`); inventario separa `ProductoDAO` de `MovimientoInventarioDAO`. `UsuarioDAOJdbc` implementa las dos interfaces de usuario. | `dao/CredencialDAO`, `dao/UsuarioDAO`, `dao/MovimientoInventarioDAO` |
| **D** — Inversión de dependencias | Los servicios dependen de **interfaces** (`MascotaDAO`, `PasswordHasher`, `Clock`), no de JDBC ni de PBKDF2. Los controladores reciben servicios por constructor; ya nadie hace `new ConsultasX()`. Solo `Contenedor` conoce las clases concretas. La clase estática `SesionUsuario` se eliminó: el `Usuario` se pasa por constructor. | `config/Contenedor`, constructores de `servicio/*` y `controlador/*` |

## 5. TDD (Test-Driven Development)

TDD es el ciclo **Rojo → Verde → Refactor**: primero se escribe una prueba que falla, luego el mínimo código que la hace pasar,
y por último se limpia sin romper nada.

**Cómo se hizo aquí**
1. **Rojo:** se escribieron primero las 94 pruebas y los dobles en memoria. Al compilar, el proyecto daba **100 errores**
   (las clases y métodos todavía no existían): eso es el "rojo".
2. **Verde:** se implementaron el modelo, las interfaces DAO, la seguridad y los servicios hasta que las pruebas pasaron.
3. **Refactor:** con las pruebas en verde se movieron los controladores a los servicios y el SQL a los DAO JDBC, volviendo a correr
   las pruebas.

**Ejemplo de un ciclo** (regla: "la cuenta se bloquea a los 3 intentos, aunque la clave sea correcta")
```java
// 1) Prueba (ROJA: AutenticacionService aún no existía)
@Test
public void conTresIntentosFallidosLaCuentaEstaBloqueadaAunqueLaClaveSeaCorrecta() {
    dao.usuarios.put("vet", new CredencialUsuario(3, "vet", "hash:vet123", "Dra. Rosa Quispe",
            Usuario.VETERINARIO, true, 3));
    assertEquals(Estado.BLOQUEADO, servicio.autenticar("vet", "vet123").getEstado());
}
// 2) Código mínimo (VERDE) en AutenticacionService:
if (!c.isActivo() || c.getIntentosFallidos() >= MAX_INTENTOS) { return ResultadoLogin.bloqueado(); }
```

**Qué cubren las pruebas (94)**

| Clase de prueba | Pruebas | Qué verifica |
|---|---|---|
| `CitaEstadoTest` | 7 | transiciones válidas, estados finales, orígenes permitidos |
| `ComprobanteTest` | 4 | subtotal, IGV 18 %, total, número `B001-000007`, stock crítico |
| `PoliticaPermisosTest` | 4 | permisos de Administrador, Recepcionista, Veterinario y rol desconocido |
| `Pbkdf2PasswordHasherTest` | 5 | hash/verificación, sal aleatoria, hash corrupto |
| `AutenticacionServiceTest` | 6 | login OK, clave mala, bloqueo a 3 intentos, cuenta inactiva, BD caída |
| `MascotaValidadorTest` | 12 | DNI, obligatorios, teléfono, peso (0–200, coma decimal), fechas |
| `MascotaServiceTest` | 9 | registrar/modificar/eliminar/buscar, búsqueda de dueño por DNI |
| `CitaServiceTest` | 17 | fecha pasada, cruce de horario, reprogramar, confirmar/cancelar, atender |
| `InventarioServiceTest` | 13 | validación de producto, entradas/salidas, stock insuficiente, críticos |
| `FacturacionServiceTest` | 10 | líneas de boleta, stock ya agregado, emitir, totales con IGV |
| `CitaDAOJdbcTest` | 7 | SQL generado, `commit`/`rollback`, conexión cerrada (con `ConexionEspia`, sin MySQL) |

**Cómo se comprobó que las pruebas sirven:** se rompió a propósito el código (bloqueo a 4 intentos en vez de 3; IGV 19 % en vez de 18 %)
y las pruebas correspondientes fallaron; al restaurar volvieron a pasar.

## 6. Qué NO está probado (para no engañarse)
- Las **ventanas Swing** (`vista/` y la parte visual de los controladores) no tienen pruebas automáticas; se prueban abriendo el programa.
- Los DAO JDBC, salvo el de citas, no se probaron contra una base real: el SQL es el mismo del código original, movido de clase.
  Conviene recorrer el flujo completo una vez con MySQL de Laragon: **login → mascota → cita → confirmar → atender → boleta → inventario**.
- Las pruebas se verificaron compilando con `javac` (JDK 21) y un ejecutor mínimo compatible con la API de JUnit 5; `mvn test` con el
  JUnit real lo ejecutas tú en NetBeans/consola (el `pom.xml` ya trae la dependencia).

## 7. Cambios de comportamiento a tener en cuenta
- Un error de base de datos ahora sale como mensaje "No se pudo <acción>: <detalle>" (antes también, pero vía `ultimoError`).
- "Solo se puede atender una cita CONFIRMADA" ahora se valida en el servicio antes de ir a la BD (el DAO mantiene el `UPDATE` condicional por si dos usuarios actúan a la vez).
- Se agregó la validación `cantidad > 0` al agregar líneas a la boleta (los spinners ya lo impedían).
- `Conexion` pasó a `dao/jdbc/ConexionMySQL` (mismos valores por defecto y mismas propiedades `-Dvet.url/-Dvet.user/-Dvet.pass`).
