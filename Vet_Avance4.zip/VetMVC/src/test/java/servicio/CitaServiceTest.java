package servicio;

import static org.junit.jupiter.api.Assertions.*;

import doble.CitaDAOFalso;
import doble.MascotaDAOFalso;
import doble.Reloj;
import doble.UsuarioDAOFalso;
import java.time.LocalDate;
import java.time.LocalDateTime;
import modelo.Cita;
import modelo.Mascota;
import modelo.Usuario;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Reloj fijo: hoy es 2026-10-22 10:00. */
public class CitaServiceTest {

    private CitaDAOFalso citas;
    private CitaService servicio;
    private Mascota firulais;
    private Usuario dra;

    @BeforeEach
    public void preparar() {
        citas = new CitaDAOFalso();
        servicio = new CitaService(citas, new MascotaDAOFalso(), new UsuarioDAOFalso(), Reloj.fijo());
        firulais = new Mascota();
        firulais.setId(1);
        firulais.setNombre("Firulais");
        dra = new Usuario(3, "vet", "Dra. Rosa Quispe", Usuario.VETERINARIO);
    }

    private CitaFormulario form(String fecha, String hora, String motivo) {
        return new CitaFormulario(firulais, dra, fecha, hora, motivo);
    }

    private String aviso(Runnable r) {
        return assertThrows(ValidacionException.class, r::run).getMessage();
    }

    @Test
    public void programarGuardaLaCitaConElRegistrador() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        assertEquals(1, citas.citas.size());
        Cita c = citas.citas.get(0);
        assertEquals(LocalDateTime.of(2026, 10, 23, 9, 0), c.getFechaHora());
        assertEquals("Vacuna", c.getMotivo());
        assertEquals(Cita.PROGRAMADA, c.getEstado());
        assertEquals(2, citas.ultimoRegistrador);
    }

    @Test
    public void programarExigeMascotaYVeterinario() {
        CitaFormulario f = new CitaFormulario(null, dra, "2026-10-23", "09:00", "Vacuna");
        assertEquals("Elige la mascota y el veterinario.", aviso(() -> servicio.programar(f, 2)));
    }

    @Test
    public void programarExigeMotivo() {
        assertEquals("El motivo de la consulta es obligatorio.",
                aviso(() -> servicio.programar(form("2026-10-23", "09:00", "  "), 2)));
    }

    @Test
    public void programarExigeFechaConFormatoValido() {
        assertEquals("La fecha debe tener el formato aaaa-mm-dd (ej. 2026-10-15).",
                aviso(() -> servicio.programar(form("23/10/2026", "09:00", "Vacuna"), 2)));
    }

    @Test
    public void noSePuedeProgramarEnElPasado() {
        assertEquals("No se puede programar una cita en el pasado.",
                aviso(() -> servicio.programar(form("2026-10-22", "09:30", "Vacuna"), 2)));
        assertEquals(0, citas.citas.size());
    }

    @Test
    public void unaHoraPosteriorDeHoyEsValida() {
        servicio.programar(form("2026-10-22", "10:30", "Control"), 2);
        assertEquals(1, citas.citas.size());
    }

    @Test
    public void noPermiteCruceDeHorarioDelVeterinario() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        String msg = aviso(() -> servicio.programar(form("2026-10-23", "09:00", "Control"), 2));
        assertEquals("Dra. Rosa Quispe ya tiene una cita a esa hora. Elige otro horario.", msg);
        assertEquals(1, citas.citas.size());
    }

    @Test
    public void unaCitaCanceladaLiberaElHorario() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        servicio.cancelar(citas.citas.get(0));
        servicio.programar(form("2026-10-23", "09:00", "Control"), 2);
        assertEquals(2, citas.citas.size());
    }

    @Test
    public void reprogramarNoChocaConSuPropioHorario() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        Cita actual = citas.citas.get(0);
        servicio.reprogramar(actual, form("2026-10-23", "09:00", "Vacuna y desparasitación"));
        assertEquals("Vacuna y desparasitación", citas.citas.get(0).getMotivo());
    }

    @Test
    public void reprogramarSoloSiEstaProgramadaOConfirmada() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        Cita c = citas.citas.get(0);
        c.setEstado(Cita.ATENDIDA);
        assertEquals("Solo se pueden modificar citas PROGRAMADAS o CONFIRMADAS.",
                aviso(() -> servicio.reprogramar(c, form("2026-10-24", "09:00", "Vacuna"))));
    }

    @Test
    public void confirmarPasaDeProgramadaAConfirmada() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        servicio.confirmar(citas.citas.get(0));
        assertEquals(Cita.CONFIRMADA, citas.citas.get(0).getEstado());
    }

    @Test
    public void noSePuedeConfirmarUnaCitaCancelada() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        Cita c = citas.citas.get(0);
        servicio.cancelar(c);
        assertEquals("La cita está CANCELADA: no se puede dejar como CONFIRMADA.", aviso(() -> servicio.confirmar(c)));
    }

    @Test
    public void atenderExigeDiagnostico() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        Cita c = citas.citas.get(0);
        servicio.confirmar(c);
        assertEquals("Escribe el diagnóstico para registrar la atención.", aviso(() -> servicio.atender(c, " ", "x")));
    }

    @Test
    public void atenderSoloUnaCitaConfirmada() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        Cita c = citas.citas.get(0);
        assertEquals("Solo se puede atender una cita CONFIRMADA.", aviso(() -> servicio.atender(c, "Sano", "Ninguno")));
    }

    @Test
    public void atenderRegistraDiagnosticoYTratamientoYCierraLaCita() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        Cita c = citas.citas.get(0);
        servicio.confirmar(c);
        servicio.atender(c, "Gastritis leve", "Dieta blanda");
        assertEquals(Cita.ATENDIDA, citas.citas.get(0).getEstado());
        assertEquals("Gastritis leve", citas.ultimoDiagnostico);
        assertEquals("Dieta blanda", citas.ultimoTratamiento);
    }

    @Test
    public void agendaDelDiaFiltraPorFecha() {
        servicio.programar(form("2026-10-23", "09:00", "Vacuna"), 2);
        servicio.programar(form("2026-10-24", "09:00", "Control"), 2);
        assertEquals(1, servicio.agenda(LocalDate.of(2026, 10, 24)).size());
    }

    @Test
    public void parsearFechaRechazaFormatoInvalido() {
        assertEquals(LocalDate.of(2026, 10, 15), servicio.parsearFecha("2026-10-15"));
        assertEquals("La fecha debe tener el formato aaaa-mm-dd (ej. 2026-10-15).", aviso(() -> servicio.parsearFecha("15-10-2026")));
    }
}
