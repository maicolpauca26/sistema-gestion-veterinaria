package servicio;

import static org.junit.jupiter.api.Assertions.*;

import doble.MovimientoDAOFalso;
import doble.ProductoDAOFalso;
import java.math.BigDecimal;
import modelo.Producto;
import modelo.TipoMovimiento;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class InventarioServiceTest {

    private ProductoDAOFalso productos;
    private MovimientoDAOFalso movimientos;
    private InventarioService servicio;

    @BeforeEach
    public void preparar() {
        productos = new ProductoDAOFalso();
        movimientos = new MovimientoDAOFalso();
        servicio = new InventarioService(productos, movimientos);
    }

    private Producto productoConStock(int stock, int minimo) {
        servicio.registrar(new ProductoFormulario("AMX-01", "Amoxicilina", "3.50", String.valueOf(minimo)));
        Producto p = productos.productos.get(0);
        p.setStock(stock);
        return p;
    }

    private String aviso(Runnable r) {
        return assertThrows(ValidacionException.class, r::run).getMessage();
    }

    @Test
    public void registrarCreaElProductoConStockCero() {
        servicio.registrar(new ProductoFormulario("AMX-01", "Amoxicilina", "3,50", "5"));
        Producto p = productos.productos.get(0);
        assertEquals("AMX-01", p.getCodigo());
        assertEquals(new BigDecimal("3.50"), p.getPrecio());
        assertEquals(5, p.getStockMinimo());
        assertEquals(0, p.getStock());
    }

    @Test
    public void codigoYNombreSonObligatorios() {
        assertEquals("Código y nombre son obligatorios.",
                aviso(() -> servicio.registrar(new ProductoFormulario("", "Amoxicilina", "3.50", "5"))));
    }

    @Test
    public void elPrecioDebeSerNumero() {
        assertEquals("El precio debe ser un número (ej. 3.50).",
                aviso(() -> servicio.registrar(new ProductoFormulario("A", "B", "caro", "5"))));
    }

    @Test
    public void elStockMinimoDebeSerEntero() {
        assertEquals("El stock mínimo debe ser un número entero.",
                aviso(() -> servicio.registrar(new ProductoFormulario("A", "B", "3.50", "1.5"))));
    }

    @Test
    public void precioYMinimoNoPuedenSerNegativos() {
        assertEquals("El precio y el stock mínimo no pueden ser negativos.",
                aviso(() -> servicio.registrar(new ProductoFormulario("A", "B", "-1", "5"))));
        assertEquals("El precio y el stock mínimo no pueden ser negativos.",
                aviso(() -> servicio.registrar(new ProductoFormulario("A", "B", "1", "-5"))));
    }

    @Test
    public void modificarActualizaNombreYPrecioPeroNoElStock() {
        Producto p = productoConStock(10, 2);
        servicio.modificar(p.getId(), new ProductoFormulario("AMX-01", "Amoxicilina 500", "4.00", "3"));
        assertEquals("Amoxicilina 500", productos.productos.get(0).getNombre());
        assertEquals(10, productos.productos.get(0).getStock());
    }

    @Test
    public void unaEntradaSeRegistraConUsuarioYCantidad() {
        Producto p = productoConStock(5, 2);
        servicio.registrarMovimiento(p, TipoMovimiento.ENTRADA, "20", 1);
        assertEquals(1, movimientos.registros.size());
        assertEquals(TipoMovimiento.ENTRADA, movimientos.registros.get(0).tipo);
        assertEquals(20, movimientos.registros.get(0).cantidad);
        assertEquals(1, movimientos.registros.get(0).idUsuario);
    }

    @Test
    public void unaSalidaMayorAlStockSeRechazaSinTocarElDao() {
        Producto p = productoConStock(5, 2);
        assertEquals("Stock insuficiente: solo hay 5 unidad(es) de Amoxicilina.",
                aviso(() -> servicio.registrarMovimiento(p, TipoMovimiento.SALIDA, "6", 1)));
        assertEquals(0, movimientos.registros.size());
    }

    @Test
    public void unaSalidaIgualAlStockEsValida() {
        Producto p = productoConStock(5, 2);
        servicio.registrarMovimiento(p, TipoMovimiento.SALIDA, "5", 1);
        assertEquals(1, movimientos.registros.size());
    }

    @Test
    public void laCantidadDebeSerEnteraYMayorQueCero() {
        Producto p = productoConStock(5, 2);
        assertEquals("La cantidad debe ser un número entero.",
                aviso(() -> servicio.registrarMovimiento(p, TipoMovimiento.ENTRADA, "abc", 1)));
        assertEquals("La cantidad debe ser mayor que 0.",
                aviso(() -> servicio.registrarMovimiento(p, TipoMovimiento.ENTRADA, "0", 1)));
    }

    @Test
    public void listarCriticosDevuelveSoloLosQueLlegaronAlMinimo() {
        productoConStock(2, 5);
        servicio.registrar(new ProductoFormulario("VAC-01", "Vacuna", "30", "1"));
        productos.productos.get(1).setStock(10);
        assertEquals(1, servicio.listarCriticos().size());
        assertEquals("Amoxicilina", servicio.listarCriticos().get(0).getNombre());
    }

    @Test
    public void buscarSinTextoDevuelveTodos() {
        productoConStock(2, 5);
        assertEquals(1, servicio.buscar("").size());
    }

    @Test
    public void eliminarAvisaSiElProductoNoExiste() {
        assertEquals("No se encontró el producto.", aviso(() -> servicio.eliminar(99)));
    }
}
