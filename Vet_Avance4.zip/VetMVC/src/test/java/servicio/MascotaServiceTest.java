package servicio;

import static org.junit.jupiter.api.Assertions.*;

import doble.ClienteDAOFalso;
import doble.MascotaDAOFalso;
import doble.Reloj;
import java.util.List;
import java.util.Optional;
import modelo.Cliente;
import modelo.Mascota;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class MascotaServiceTest {

    private MascotaDAOFalso mascotas;
    private ClienteDAOFalso clientes;
    private MascotaService servicio;

    @BeforeEach
    public void preparar() {
        mascotas = new MascotaDAOFalso();
        clientes = new ClienteDAOFalso();
        servicio = new MascotaService(mascotas, clientes, Reloj.fijo());
    }

    private MascotaFormulario formulario(String nombre) {
        return new MascotaFormulario("12345678", "Carlos Ramos", "987654321", "Av. Lima 123",
                nombre, "Perro", "Mestizo", "M", "2022-03-10", "12.5");
    }

    @Test
    public void registrarGuardaLaMascotaEnElDao() {
        servicio.registrar(formulario("Firulais"));
        assertEquals(1, mascotas.mascotas.size());
        assertEquals("Firulais", mascotas.mascotas.get(0).getNombre());
    }

    @Test
    public void registrarConDatosInvalidosNoTocaElDao() {
        MascotaFormulario malo = new MascotaFormulario("1", "Ana", "", "", "Luna", "Gato", "", "H", "", "4");
        assertThrows(ValidacionException.class, () -> servicio.registrar(malo));
        assertEquals(0, mascotas.mascotas.size());
    }

    @Test
    public void modificarConservaElIdDeLaMascota() {
        servicio.registrar(formulario("Firulais"));
        int id = mascotas.mascotas.get(0).getId();
        servicio.modificar(id, formulario("Rocky"));
        assertEquals(1, mascotas.mascotas.size());
        assertEquals(id, mascotas.mascotas.get(0).getId());
        assertEquals("Rocky", mascotas.mascotas.get(0).getNombre());
    }

    @Test
    public void eliminarQuitaLaMascotaYAvisaSiNoExiste() {
        servicio.registrar(formulario("Firulais"));
        servicio.eliminar(mascotas.mascotas.get(0).getId());
        assertEquals(0, mascotas.mascotas.size());
        assertThrows(ValidacionException.class, () -> servicio.eliminar(99));
    }

    @Test
    public void buscarSinTextoDevuelveTodas() {
        servicio.registrar(formulario("Firulais"));
        servicio.registrar(formulario("Rocky"));
        assertEquals(2, servicio.buscar("   ").size());
    }

    @Test
    public void buscarConTextoFiltra() {
        servicio.registrar(formulario("Firulais"));
        servicio.registrar(formulario("Rocky"));
        List<Mascota> r = servicio.buscar("rock");
        assertEquals(1, r.size());
        assertEquals("Rocky", r.get(0).getNombre());
    }

    @Test
    public void buscarDuenoExigeDniDeOchoDigitos() {
        ValidacionException e = assertThrows(ValidacionException.class, () -> servicio.buscarDueno("12"));
        assertEquals("El DNI debe tener 8 dígitos.", e.getMessage());
    }

    @Test
    public void buscarDuenoDevuelveVacioSiNoExiste() {
        assertFalse(servicio.buscarDueno("12345678").isPresent());
    }

    @Test
    public void buscarDuenoDevuelveElClienteRegistrado() {
        Cliente c = new Cliente();
        c.setDni("12345678");
        c.setNombres("Carlos Ramos");
        clientes.clientes.put("12345678", c);
        Optional<Cliente> r = servicio.buscarDueno("12345678");
        assertTrue(r.isPresent());
        assertEquals("Carlos Ramos", r.get().getNombres());
    }
}
