package servicio;

import static org.junit.jupiter.api.Assertions.*;

import doble.ComprobanteDAOFalso;
import doble.ProductoDAOFalso;
import doble.ServicioDAOFalso;
import java.math.BigDecimal;
import modelo.Atencion;
import modelo.Comprobante;
import modelo.Producto;
import modelo.Servicio;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class FacturacionServiceTest {

    private ComprobanteDAOFalso comprobantes;
    private ProductoDAOFalso productos;
    private ServicioDAOFalso servicios;
    private FacturacionService servicio;
    private Servicio consulta;
    private Producto vacuna;
    private Atencion atencion;

    @BeforeEach
    public void preparar() {
        comprobantes = new ComprobanteDAOFalso();
        productos = new ProductoDAOFalso();
        servicios = new ServicioDAOFalso();
        servicio = new FacturacionService(comprobantes, servicios, productos);

        consulta = new Servicio(1, "Consulta general", new BigDecimal("40.00"));
        vacuna = new Producto();
        vacuna.setId(7);
        vacuna.setNombre("Vacuna");
        vacuna.setPrecio(new BigDecimal("30.00"));
        vacuna.setStock(3);
        atencion = new Atencion();
        atencion.setId(9);
    }

    private String aviso(Runnable r) {
        return assertThrows(ValidacionException.class, r::run).getMessage();
    }

    @Test
    public void agregarServicioSumaUnaLineaYRecalculaTotales() {
        Comprobante c = new Comprobante();
        servicio.agregarServicio(c, consulta, 2);
        assertEquals(1, c.getDetalles().size());
        assertEquals(new BigDecimal("80.00"), c.getSubtotal());
        assertEquals(new BigDecimal("94.40"), c.getTotal());
    }

    @Test
    public void agregarProductoRespetaElStockDisponible() {
        Comprobante c = new Comprobante();
        servicio.agregarProducto(c, vacuna, 2);
        assertEquals(1, c.getDetalles().size());
    }

    @Test
    public void agregarProductoConsideraLoYaAgregado() {
        Comprobante c = new Comprobante();
        servicio.agregarProducto(c, vacuna, 2);
        assertEquals("Stock insuficiente de Vacuna: hay 3 y ya agregaste 2.", aviso(() -> servicio.agregarProducto(c, vacuna, 2)));
        assertEquals(1, c.getDetalles().size());
    }

    @Test
    public void laCantidadDebeSerPositiva() {
        Comprobante c = new Comprobante();
        assertEquals("La cantidad debe ser mayor que 0.", aviso(() -> servicio.agregarServicio(c, consulta, 0)));
    }

    @Test
    public void quitarLineaElimnaYRecalcula() {
        Comprobante c = new Comprobante();
        servicio.agregarServicio(c, consulta, 1);
        servicio.agregarProducto(c, vacuna, 1);
        servicio.quitarLinea(c, 0);
        assertEquals(1, c.getDetalles().size());
        assertEquals(new BigDecimal("30.00"), c.getSubtotal());
    }

    @Test
    public void quitarSinSeleccionAvisa() {
        Comprobante c = new Comprobante();
        assertEquals("Selecciona una línea del detalle para quitarla.", aviso(() -> servicio.quitarLinea(c, -1)));
    }

    @Test
    public void emitirExigeAtencion() {
        Comprobante c = new Comprobante();
        servicio.agregarServicio(c, consulta, 1);
        assertEquals("No hay una atención seleccionada. Registra primero la atención en la agenda de citas.",
                aviso(() -> servicio.emitir(c, null, "YAPE", 1)));
    }

    @Test
    public void emitirExigeAlMenosUnaLinea() {
        assertEquals("Agrega al menos un servicio o producto.",
                aviso(() -> servicio.emitir(new Comprobante(), atencion, "YAPE", 1)));
        assertEquals(0, comprobantes.emitidos.size());
    }

    @Test
    public void emitirCompletaLaBoletaYLaGuardaConElUsuario() {
        Comprobante c = new Comprobante();
        servicio.agregarServicio(c, consulta, 1);
        servicio.agregarProducto(c, vacuna, 1);
        servicio.emitir(c, atencion, "YAPE", 2);
        assertEquals(1, comprobantes.emitidos.size());
        assertEquals(9, c.getIdAtencion());
        assertEquals("YAPE", c.getMetodoPago());
        assertEquals(new BigDecimal("70.00"), c.getSubtotal());
        assertEquals(new BigDecimal("12.60"), c.getIgv());
        assertEquals(new BigDecimal("82.60"), c.getTotal());
        assertEquals("B001-000001", c.getNumeroCompleto());
        assertEquals(2, comprobantes.ultimoUsuario);
    }

    @Test
    public void soloSeOfrecenProductosConStock() {
        Producto agotado = new Producto();
        agotado.setId(8);
        agotado.setNombre("Jeringa");
        agotado.setStock(0);
        productos.productos.add(vacuna);
        productos.productos.add(agotado);
        assertEquals(1, servicio.listarProductosConStock().size());
        assertEquals("Vacuna", servicio.listarProductosConStock().get(0).getNombre());
    }
}
