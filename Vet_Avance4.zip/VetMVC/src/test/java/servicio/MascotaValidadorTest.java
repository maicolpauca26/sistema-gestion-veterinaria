package servicio;

import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDate;
import modelo.Mascota;
import org.junit.jupiter.api.Test;

public class MascotaValidadorTest {

    private static final LocalDate HOY = LocalDate.of(2026, 10, 22);

    private MascotaFormulario valido() {
        return new MascotaFormulario("12345678", "Carlos Ramos", "987654321", "Av. Lima 123",
                "Firulais", "Perro", "Mestizo", "M", "2022-03-10", "12.5");
    }

    private String mensajeDe(MascotaFormulario f) {
        return assertThrows(ValidacionException.class, () -> MascotaValidador.construir(f, HOY)).getMessage();
    }

    @Test
    public void unFormularioValidoSeConvierteEnMascotaConDueno() {
        Mascota m = MascotaValidador.construir(valido(), HOY);
        assertEquals("Firulais", m.getNombre());
        assertEquals("Perro", m.getEspecie());
        assertEquals("M", m.getSexo());
        assertEquals(LocalDate.of(2022, 3, 10), m.getFechaNacimiento());
        assertEquals(12.5, m.getPeso(), 0.0001);
        assertEquals("12345678", m.getCliente().getDni());
        assertEquals("Carlos Ramos", m.getCliente().getNombres());
    }

    @Test
    public void elDniDebeTenerOchoDigitos() {
        MascotaFormulario f = new MascotaFormulario("1234", "Carlos Ramos", "", "", "Firulais", "Perro", "", "M", "", "5");
        assertEquals("El DNI del dueño debe tener 8 dígitos.", mensajeDe(f));
    }

    @Test
    public void duenoNombreYEspecieSonObligatorios() {
        MascotaFormulario f = new MascotaFormulario("12345678", "", "", "", "Firulais", "Perro", "", "M", "", "5");
        assertEquals("Nombre del dueño, nombre de la mascota y especie son obligatorios.", mensajeDe(f));
    }

    @Test
    public void elTelefonoSoloAdmiteEntreSeisYDoceDigitos() {
        MascotaFormulario f = new MascotaFormulario("12345678", "Ana", "12ab", "", "Luna", "Gato", "", "H", "", "4");
        assertEquals("El teléfono debe tener solo números (6 a 12 dígitos).", mensajeDe(f));
    }

    @Test
    public void elTelefonoPuedeQuedarVacio() {
        MascotaFormulario f = new MascotaFormulario("12345678", "Ana", "", "", "Luna", "Gato", "", "H", "", "4");
        assertNotNull(MascotaValidador.construir(f, HOY));
    }

    @Test
    public void elPesoDebeSerNumero() {
        MascotaFormulario f = new MascotaFormulario("12345678", "Ana", "", "", "Luna", "Gato", "", "H", "", "abc");
        assertEquals("El peso debe ser un número (ej. 12.5).", mensajeDe(f));
    }

    @Test
    public void elPesoAceptaComaDecimal() {
        MascotaFormulario f = new MascotaFormulario("12345678", "Ana", "", "", "Luna", "Gato", "", "H", "", "4,2");
        assertEquals(4.2, MascotaValidador.construir(f, HOY).getPeso(), 0.0001);
    }

    @Test
    public void elPesoDebeEstarEntreCeroYDoscientos() {
        for (String peso : new String[]{"0", "-3", "200.1"}) {
            MascotaFormulario f = new MascotaFormulario("12345678", "Ana", "", "", "Luna", "Gato", "", "H", "", peso);
            assertEquals("El peso debe ser mayor que 0 y no más de 200 kg.", mensajeDe(f));
        }
    }

    @Test
    public void elPesoLimiteDeDoscientosEsValido() {
        MascotaFormulario f = new MascotaFormulario("12345678", "Ana", "", "", "Toro", "Bovino", "", "M", "", "200");
        assertEquals(200.0, MascotaValidador.construir(f, HOY).getPeso(), 0.0001);
    }

    @Test
    public void laFechaDeNacimientoTieneFormatoAnioMesDia() {
        MascotaFormulario f = new MascotaFormulario("12345678", "Ana", "", "", "Luna", "Gato", "", "H", "10/03/2022", "4");
        assertEquals("La fecha de nacimiento debe tener el formato aaaa-mm-dd (ej. 2022-03-10).", mensajeDe(f));
    }

    @Test
    public void laFechaDeNacimientoNoPuedeSerFutura() {
        MascotaFormulario f = new MascotaFormulario("12345678", "Ana", "", "", "Luna", "Gato", "", "H", "2026-10-23", "4");
        assertEquals("La fecha de nacimiento no puede ser futura.", mensajeDe(f));
    }

    @Test
    public void laFechaDeNacimientoEsOpcional() {
        MascotaFormulario f = new MascotaFormulario("12345678", "Ana", "", "", "Luna", "Gato", "", "H", "", "4");
        assertNull(MascotaValidador.construir(f, HOY).getFechaNacimiento());
    }
}
