package servicio;

import static org.junit.jupiter.api.Assertions.*;

import dao.DaoException;
import doble.CredencialDAOFalso;
import doble.HasherFalso;
import modelo.CredencialUsuario;
import modelo.Usuario;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import servicio.ResultadoLogin.Estado;

public class AutenticacionServiceTest {

    private CredencialDAOFalso dao;
    private AutenticacionService servicio;

    @BeforeEach
    public void preparar() {
        dao = new CredencialDAOFalso();
        dao.usuarios.put("vet", new CredencialUsuario(3, "vet", "hash:vet123", "Dra. Rosa Quispe", Usuario.VETERINARIO, true, 0));
        servicio = new AutenticacionService(dao, new HasherFalso());
    }

    @Test
    public void credencialesCorrectasIniciaSesionYRegistraElAcceso() {
        ResultadoLogin r = servicio.autenticar("vet", "vet123");
        assertEquals(Estado.OK, r.getEstado());
        assertEquals(Usuario.VETERINARIO, r.getUsuario().getRol());
        assertEquals(3, r.getUsuario().getId());
        assertEquals(1, (int) dao.exitosos.get(3));
    }

    @Test
    public void usuarioInexistenteEsCredencialInvalida() {
        ResultadoLogin r = servicio.autenticar("nadie", "x");
        assertEquals(Estado.CREDENCIALES_INVALIDAS, r.getEstado());
        assertNull(r.getUsuario());
    }

    @Test
    public void claveIncorrectaCuentaUnIntentoFallido() {
        ResultadoLogin r = servicio.autenticar("vet", "mala");
        assertEquals(Estado.CREDENCIALES_INVALIDAS, r.getEstado());
        assertEquals(1, (int) dao.fallidos.get(3));
        assertNull(dao.exitosos.get(3));
    }

    @Test
    public void conTresIntentosFallidosLaCuentaEstaBloqueadaAunqueLaClaveSeaCorrecta() {
        dao.usuarios.put("vet", new CredencialUsuario(3, "vet", "hash:vet123", "Dra. Rosa Quispe", Usuario.VETERINARIO, true, 3));
        ResultadoLogin r = servicio.autenticar("vet", "vet123");
        assertEquals(Estado.BLOQUEADO, r.getEstado());
        assertNull(dao.exitosos.get(3));
    }

    @Test
    public void unaCuentaInactivaEstaBloqueada() {
        dao.usuarios.put("vet", new CredencialUsuario(3, "vet", "hash:vet123", "Dra. Rosa Quispe", Usuario.VETERINARIO, false, 0));
        assertEquals(Estado.BLOQUEADO, servicio.autenticar("vet", "vet123").getEstado());
    }

    @Test
    public void unFalloDeBaseDeDatosSePropagaComoDaoException() {
        dao.caida = true;
        assertThrows(DaoException.class, () -> servicio.autenticar("vet", "vet123"));
    }
}
