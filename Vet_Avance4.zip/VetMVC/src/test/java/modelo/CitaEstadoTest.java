package modelo;

import static org.junit.jupiter.api.Assertions.*;

import java.util.Set;
import org.junit.jupiter.api.Test;

public class CitaEstadoTest {

    @Test
    public void programadaPuedeConfirmarseOCancelarse() {
        assertTrue(CitaEstado.PROGRAMADA.puedePasarA(CitaEstado.CONFIRMADA));
        assertTrue(CitaEstado.PROGRAMADA.puedePasarA(CitaEstado.CANCELADA));
    }

    @Test
    public void programadaNoPuedeAtenderseSinConfirmar() {
        assertFalse(CitaEstado.PROGRAMADA.puedePasarA(CitaEstado.ATENDIDA));
    }

    @Test
    public void confirmadaPuedeAtenderseOCancelarse() {
        assertTrue(CitaEstado.CONFIRMADA.puedePasarA(CitaEstado.ATENDIDA));
        assertTrue(CitaEstado.CONFIRMADA.puedePasarA(CitaEstado.CANCELADA));
    }

    @Test
    public void canceladaYAtendidaSonEstadosFinales() {
        for (CitaEstado destino : CitaEstado.values()) {
            assertFalse(CitaEstado.CANCELADA.puedePasarA(destino));
            assertFalse(CitaEstado.ATENDIDA.puedePasarA(destino));
        }
    }

    @Test
    public void soloProgramadaYConfirmadaSonEditables() {
        assertTrue(CitaEstado.PROGRAMADA.esEditable());
        assertTrue(CitaEstado.CONFIRMADA.esEditable());
        assertFalse(CitaEstado.CANCELADA.esEditable());
        assertFalse(CitaEstado.ATENDIDA.esEditable());
    }

    @Test
    public void origenesPermitidosSeDerivanDeLasTransiciones() {
        assertEquals(Set.of(CitaEstado.PROGRAMADA), CitaEstado.origenesPara(CitaEstado.CONFIRMADA));
        assertEquals(Set.of(CitaEstado.PROGRAMADA, CitaEstado.CONFIRMADA), CitaEstado.origenesPara(CitaEstado.CANCELADA));
        assertEquals(Set.of(CitaEstado.CONFIRMADA), CitaEstado.origenesPara(CitaEstado.ATENDIDA));
    }

    @Test
    public void seConvierteDesdeElTextoDeLaBaseDeDatos() {
        assertEquals(CitaEstado.CONFIRMADA, CitaEstado.de("CONFIRMADA"));
        assertThrows(IllegalArgumentException.class, () -> CitaEstado.de("INEXISTENTE"));
    }
}
