package modelo;

import static org.junit.jupiter.api.Assertions.*;

import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

public class ComprobanteTest {

    @Test
    public void calculaSubtotalIgvYTotal() {
        Comprobante c = new Comprobante();
        c.getDetalles().add(new DetalleComprobante(1, null, "Consulta", 2, new BigDecimal("25.00")));
        c.getDetalles().add(new DetalleComprobante(null, 5, "Vacuna", 1, new BigDecimal("10.50")));
        c.calcularTotales();
        assertEquals(new BigDecimal("60.50"), c.getSubtotal());
        assertEquals(new BigDecimal("10.89"), c.getIgv());
        assertEquals(new BigDecimal("71.39"), c.getTotal());
    }

    @Test
    public void unaBoletaVaciaTieneTotalCero() {
        Comprobante c = new Comprobante();
        c.calcularTotales();
        assertEquals(0, c.getTotal().signum());
    }

    @Test
    public void numeroCompletoLlevaSerieYSeisDigitos() {
        Comprobante c = new Comprobante();
        c.setSerie(Comprobante.SERIE);
        c.setNumero(7);
        assertEquals("B001-000007", c.getNumeroCompleto());
    }

    @Test
    public void productoEsCriticoCuandoLlegaAlMinimo() {
        Producto p = new Producto();
        p.setStockMinimo(5);
        p.setStock(5);
        assertTrue(p.esCritico());
        p.setStock(6);
        assertFalse(p.esCritico());
    }
}
