package dao.jdbc;

import static org.junit.jupiter.api.Assertions.*;

import dao.DaoException;
import doble.ConexionEspia;
import java.time.LocalDateTime;
import modelo.Cita;
import modelo.CitaEstado;
import modelo.Mascota;
import modelo.Usuario;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

/** Prueba el SQL que genera el DAO y su manejo de transacciones, sin necesidad de MySQL. */
public class CitaDAOJdbcTest {

    private ConexionEspia conexion;
    private CitaDAOJdbc dao;

    @BeforeEach
    public void preparar() {
        conexion = new ConexionEspia();
        dao = new CitaDAOJdbc(conexion);
    }

    @Test
    public void confirmarSoloPartiendoDeProgramada() {
        assertTrue(dao.cambiarEstado(5, CitaEstado.CONFIRMADA));
        assertEquals("UPDATE cita SET estado = ? WHERE id_cita = ? AND estado IN ('PROGRAMADA')", conexion.sentencias.get(0));
    }

    @Test
    public void cancelarPartiendoDeProgramadaOConfirmada() {
        dao.cambiarEstado(5, CitaEstado.CANCELADA);
        assertEquals("UPDATE cita SET estado = ? WHERE id_cita = ? AND estado IN ('PROGRAMADA','CONFIRMADA')", conexion.sentencias.get(0));
    }

    @Test
    public void cambiarEstadoDevuelveFalseSiNingunaFilaCambio() {
        conexion.filasAfectadas = 0;
        assertFalse(dao.cambiarEstado(5, CitaEstado.CONFIRMADA));
    }

    @Test
    public void modificarSoloAfectaCitasEditables() {
        Cita c = new Cita();
        Mascota m = new Mascota();
        m.setId(1);
        c.setMascota(m);
        c.setVeterinario(new Usuario(3, "vet", "Dra. Rosa", Usuario.VETERINARIO));
        c.setFechaHora(LocalDateTime.of(2026, 10, 23, 9, 0));
        c.setMotivo("Vacuna");
        dao.modificar(c);
        assertTrue(conexion.sentencias.get(0).endsWith("estado IN ('PROGRAMADA','CONFIRMADA')"));
    }

    @Test
    public void atenderConfirmaLaTransaccionYCierraLaConexion() {
        assertTrue(dao.atender(5, "Gastritis", "Dieta"));
        assertEquals(2, conexion.sentencias.size());
        assertTrue(conexion.sentencias.get(1).startsWith("INSERT INTO atencion"));
        assertTrue(conexion.eventos.contains("autocommit=false"));
        assertTrue(conexion.eventos.contains("commit"));
        assertFalse(conexion.eventos.contains("rollback"));
        assertEquals("close", conexion.eventos.get(conexion.eventos.size() - 1));
    }

    @Test
    public void atenderUnaCitaNoConfirmadaNoInsertaLaAtencion() {
        conexion.filasAfectadas = 0;
        assertFalse(dao.atender(5, "Gastritis", "Dieta"));
        assertEquals(1, conexion.sentencias.size());
    }

    @Test
    public void siFallaElInsertDeLaAtencionSeHaceRollbackYNoCommit() {
        conexion.fallarSiContiene = "INSERT INTO atencion";
        DaoException e = assertThrows(DaoException.class, () -> dao.atender(5, "Gastritis", "Dieta"));
        assertEquals("fallo simulado en: INSERT INTO atencion", e.getMessage());
        assertTrue(conexion.eventos.contains("rollback"));
        assertFalse(conexion.eventos.contains("commit"));
        assertEquals("close", conexion.eventos.get(conexion.eventos.size() - 1));
    }
}
