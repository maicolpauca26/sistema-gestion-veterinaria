package doble;

import dao.CitaDAO;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import modelo.Cita;
import modelo.CitaEstado;

public class CitaDAOFalso implements CitaDAO {
    public final List<Cita> citas = new ArrayList<>();
    public int ultimoRegistrador;
    public String ultimoDiagnostico;
    public String ultimoTratamiento;
    private int siguiente = 1;

    @Override
    public boolean horarioOcupado(int idVeterinario, LocalDateTime fechaHora, int idCitaExcluida) {
        for (Cita c : citas) {
            if (c.getVeterinario().getId() == idVeterinario && c.getFechaHora().equals(fechaHora)
                    && !c.getEstado().equals(Cita.CANCELADA) && c.getId() != idCitaExcluida) return true;
        }
        return false;
    }

    @Override
    public void insertar(Cita c, int idRegistrador) {
        c.setId(siguiente++);
        c.setEstado(Cita.PROGRAMADA);
        ultimoRegistrador = idRegistrador;
        citas.add(c);
    }

    @Override
    public boolean modificar(Cita nueva) {
        for (Cita c : citas) {
            if (c.getId() == nueva.getId() && CitaEstado.de(c.getEstado()).esEditable()) {
                c.setFechaHora(nueva.getFechaHora());
                c.setMotivo(nueva.getMotivo());
                c.setMascota(nueva.getMascota());
                c.setVeterinario(nueva.getVeterinario());
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean cambiarEstado(int idCita, CitaEstado nuevo) {
        for (Cita c : citas) {
            if (c.getId() == idCita && CitaEstado.origenesPara(nuevo).contains(CitaEstado.de(c.getEstado()))) {
                c.setEstado(nuevo.name());
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean atender(int idCita, String diagnostico, String tratamiento) {
        for (Cita c : citas) {
            if (c.getId() == idCita && c.getEstado().equals(Cita.CONFIRMADA)) {
                c.setEstado(Cita.ATENDIDA);
                ultimoDiagnostico = diagnostico;
                ultimoTratamiento = tratamiento;
                return true;
            }
        }
        return false;
    }

    @Override
    public List<Cita> listarPorFecha(LocalDate dia) {
        List<Cita> r = new ArrayList<>();
        for (Cita c : citas) if (c.getFechaHora().toLocalDate().equals(dia)) r.add(c);
        return r;
    }

    @Override
    public List<Cita> listarTodas() { return new ArrayList<>(citas); }
}
