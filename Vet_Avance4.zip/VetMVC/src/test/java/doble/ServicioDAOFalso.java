package doble;

import dao.ServicioDAO;
import java.util.ArrayList;
import java.util.List;
import modelo.Servicio;

public class ServicioDAOFalso implements ServicioDAO {
    public final List<Servicio> servicios = new ArrayList<>();
    @Override public List<Servicio> listar() { return servicios; }
}
