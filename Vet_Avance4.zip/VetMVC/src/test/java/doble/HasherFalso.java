package doble;

import seguridad.PasswordHasher;

/** Hasher de mentira: rápido y predecible ("hash:" + clave). */
public class HasherFalso implements PasswordHasher {
    @Override public String hash(String password) { return "hash:" + password; }
    @Override public boolean verificar(String password, String guardado) { return hash(password).equals(guardado); }
}
