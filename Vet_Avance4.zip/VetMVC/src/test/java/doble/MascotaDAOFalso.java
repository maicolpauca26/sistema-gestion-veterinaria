package doble;

import dao.MascotaDAO;
import java.util.ArrayList;
import java.util.List;
import modelo.Atencion;
import modelo.Mascota;

public class MascotaDAOFalso implements MascotaDAO {
    public final List<Mascota> mascotas = new ArrayList<>();
    public final List<Atencion> atenciones = new ArrayList<>();
    private int siguiente = 1;

    @Override
    public void insertar(Mascota m) { m.setId(siguiente++); mascotas.add(m); }

    @Override
    public void modificar(Mascota m) {
        for (int i = 0; i < mascotas.size(); i++) {
            if (mascotas.get(i).getId() == m.getId()) mascotas.set(i, m);
        }
    }

    @Override
    public boolean eliminar(int id) { return mascotas.removeIf(m -> m.getId() == id); }

    @Override
    public List<Mascota> listar() { return new ArrayList<>(mascotas); }

    @Override
    public List<Mascota> buscar(String texto) {
        List<Mascota> r = new ArrayList<>();
        for (Mascota m : mascotas) {
            if (m.getNombre().toLowerCase().contains(texto.toLowerCase())) r.add(m);
        }
        return r;
    }

    @Override
    public List<Atencion> historial(int idMascota) { return atenciones; }
}
