package doble;

import dao.UsuarioDAO;
import java.util.ArrayList;
import java.util.List;
import modelo.Usuario;

public class UsuarioDAOFalso implements UsuarioDAO {
    public final List<Usuario> veterinarios = new ArrayList<>();
    @Override public List<Usuario> listarVeterinarios() { return veterinarios; }
}
