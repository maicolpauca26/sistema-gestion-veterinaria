package doble;

import dao.jdbc.ProveedorConexion;
import java.lang.reflect.InvocationHandler;
import java.lang.reflect.Proxy;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Conexión falsa que solo anota qué se le pidió (SQL ejecutado, commit, rollback, close) para probar
 * los DAO JDBC sin necesitar MySQL. Cada executeUpdate responde {@code filasAfectadas}.
 */
public class ConexionEspia implements ProveedorConexion {

    public final List<String> sentencias = new ArrayList<>();   // SQL preparado
    public final List<String> eventos = new ArrayList<>();      // commit, rollback, close...
    public int filasAfectadas = 1;
    public String fallarSiContiene;                             // si el SQL contiene esto, lanza SQLException

    @Override
    public Connection obtener() {
        InvocationHandler handlerCon = (proxy, metodo, args) -> {
            switch (metodo.getName()) {
                case "prepareStatement":
                    String sql = (String) args[0];
                    sentencias.add(sql);
                    return nuevaSentencia(sql);
                case "setAutoCommit": eventos.add("autocommit=" + args[0]); return null;
                case "commit": eventos.add("commit"); return null;
                case "rollback": eventos.add("rollback"); return null;
                case "close": eventos.add("close"); return null;
                default: return null;
            }
        };
        return (Connection) Proxy.newProxyInstance(getClass().getClassLoader(), new Class<?>[]{Connection.class}, handlerCon);
    }

    private PreparedStatement nuevaSentencia(String sql) {
        InvocationHandler h = (proxy, metodo, args) -> {
            switch (metodo.getName()) {
                case "executeUpdate":
                    if (fallarSiContiene != null && sql.contains(fallarSiContiene)) {
                        throw new SQLException("fallo simulado en: " + fallarSiContiene);
                    }
                    return filasAfectadas;
                default: return null;
            }
        };
        return (PreparedStatement) Proxy.newProxyInstance(getClass().getClassLoader(), new Class<?>[]{PreparedStatement.class}, h);
    }
}
