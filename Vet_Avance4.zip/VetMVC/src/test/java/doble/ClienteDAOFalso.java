package doble;

import dao.ClienteDAO;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import modelo.Cliente;

public class ClienteDAOFalso implements ClienteDAO {
    public final Map<String, Cliente> clientes = new HashMap<>();
    @Override public Optional<Cliente> buscarPorDni(String dni) { return Optional.ofNullable(clientes.get(dni)); }
}
