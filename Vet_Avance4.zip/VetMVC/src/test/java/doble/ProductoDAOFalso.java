package doble;

import dao.ProductoDAO;
import java.util.ArrayList;
import java.util.List;
import modelo.Producto;

public class ProductoDAOFalso implements ProductoDAO {
    public final List<Producto> productos = new ArrayList<>();
    private int siguiente = 1;

    @Override public void insertar(Producto p) { p.setId(siguiente++); productos.add(p); }

    @Override
    public boolean modificar(Producto p) {
        for (Producto x : productos) {
            if (x.getId() == p.getId()) { x.setCodigo(p.getCodigo()); x.setNombre(p.getNombre());
                x.setPrecio(p.getPrecio()); x.setStockMinimo(p.getStockMinimo()); return true; }
        }
        return false;
    }

    @Override public boolean eliminar(int id) { return productos.removeIf(p -> p.getId() == id); }
    @Override public List<Producto> listar() { return new ArrayList<>(productos); }

    @Override
    public List<Producto> buscar(String texto) {
        List<Producto> r = new ArrayList<>();
        for (Producto p : productos) if (p.getNombre().toLowerCase().contains(texto.toLowerCase())) r.add(p);
        return r;
    }

    @Override
    public List<Producto> listarCriticos() {
        List<Producto> r = new ArrayList<>();
        for (Producto p : productos) if (p.esCritico()) r.add(p);
        return r;
    }
}
