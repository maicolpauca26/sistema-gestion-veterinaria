package doble;

import dao.MovimientoInventarioDAO;
import java.util.ArrayList;
import java.util.List;
import modelo.TipoMovimiento;

public class MovimientoDAOFalso implements MovimientoInventarioDAO {
    public static class Registro {
        public final int idProducto; public final TipoMovimiento tipo; public final int cantidad; public final int idUsuario;
        Registro(int p, TipoMovimiento t, int c, int u) { idProducto = p; tipo = t; cantidad = c; idUsuario = u; }
    }
    public final List<Registro> registros = new ArrayList<>();

    @Override
    public void registrar(int idProducto, TipoMovimiento tipo, int cantidad, int idUsuario) {
        registros.add(new Registro(idProducto, tipo, cantidad, idUsuario));
    }
}
