package doble;

import dao.ComprobanteDAO;
import java.util.ArrayList;
import java.util.List;
import modelo.Atencion;
import modelo.Comprobante;

public class ComprobanteDAOFalso implements ComprobanteDAO {
    public final List<Comprobante> emitidos = new ArrayList<>();
    public final List<Atencion> pendientes = new ArrayList<>();
    public int ultimoUsuario;

    @Override
    public void emitir(Comprobante c, int idUsuario) {
        c.setSerie(Comprobante.SERIE);
        c.setNumero(emitidos.size() + 1);
        ultimoUsuario = idUsuario;
        emitidos.add(c);
    }

    @Override public List<Comprobante> listar() { return emitidos; }
    @Override public List<Atencion> listarAtencionesPendientes() { return pendientes; }
}
