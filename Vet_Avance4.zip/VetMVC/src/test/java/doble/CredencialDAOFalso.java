package doble;

import dao.CredencialDAO;
import dao.DaoException;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import modelo.CredencialUsuario;

public class CredencialDAOFalso implements CredencialDAO {
    public final Map<String, CredencialUsuario> usuarios = new HashMap<>();
    public final Map<Integer, Integer> fallidos = new HashMap<>();
    public final Map<Integer, Integer> exitosos = new HashMap<>();
    public boolean caida = false;

    @Override
    public Optional<CredencialUsuario> buscarPorUsername(String username) {
        if (caida) throw new DaoException("Communications link failure");
        return Optional.ofNullable(usuarios.get(username));
    }

    @Override
    public void registrarIntentoFallido(int idUsuario) { fallidos.merge(idUsuario, 1, Integer::sum); }

    @Override
    public void registrarAccesoExitoso(int idUsuario) { exitosos.merge(idUsuario, 1, Integer::sum); }
}
