package doble;

import java.time.Clock;
import java.time.LocalDateTime;
import java.time.ZoneId;

/** Reloj fijo para que las pruebas no dependan de la fecha real: hoy es 2026-10-22 10:00 (Lima). */
public final class Reloj {
    public static final ZoneId ZONA = ZoneId.of("America/Lima");
    public static final LocalDateTime AHORA = LocalDateTime.of(2026, 10, 22, 10, 0);

    private Reloj() { }

    public static Clock fijo() {
        return Clock.fixed(AHORA.atZone(ZONA).toInstant(), ZONA);
    }
}
