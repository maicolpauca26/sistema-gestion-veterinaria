package seguridad;

import static org.junit.jupiter.api.Assertions.*;

import modelo.Usuario;
import org.junit.jupiter.api.Test;

public class PoliticaPermisosTest {

    private final PoliticaPermisos politica = new PoliticaPermisos();

    @Test
    public void administradorPuedeTodo() {
        for (Permiso p : Permiso.values()) {
            assertTrue(politica.puede(Usuario.ADMIN, p), "Administrador sin " + p);
        }
    }

    @Test
    public void recepcionistaAgendaYFacturaPeroNoVeInventario() {
        assertTrue(politica.puede(Usuario.RECEPCIONISTA, Permiso.EDITAR_MASCOTAS));
        assertTrue(politica.puede(Usuario.RECEPCIONISTA, Permiso.AGENDAR_CITAS));
        assertTrue(politica.puede(Usuario.RECEPCIONISTA, Permiso.VER_FACTURACION));
        assertFalse(politica.puede(Usuario.RECEPCIONISTA, Permiso.VER_INVENTARIO));
        assertFalse(politica.puede(Usuario.RECEPCIONISTA, Permiso.ATENDER_CITAS));
    }

    @Test
    public void veterinarioAtiendeYVeInventarioPeroSoloConsultaMascotas() {
        assertTrue(politica.puede(Usuario.VETERINARIO, Permiso.VER_MASCOTAS));
        assertFalse(politica.puede(Usuario.VETERINARIO, Permiso.EDITAR_MASCOTAS));
        assertTrue(politica.puede(Usuario.VETERINARIO, Permiso.ATENDER_CITAS));
        assertTrue(politica.puede(Usuario.VETERINARIO, Permiso.VER_INVENTARIO));
        assertFalse(politica.puede(Usuario.VETERINARIO, Permiso.AGENDAR_CITAS));
        assertFalse(politica.puede(Usuario.VETERINARIO, Permiso.VER_FACTURACION));
    }

    @Test
    public void unRolDesconocidoNoTienePermisos() {
        for (Permiso p : Permiso.values()) {
            assertFalse(politica.puede("Invitado", p));
            assertFalse(politica.puede(null, p));
        }
    }
}
