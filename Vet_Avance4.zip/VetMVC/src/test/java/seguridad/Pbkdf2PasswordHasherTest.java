package seguridad;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class Pbkdf2PasswordHasherTest {

    private final PasswordHasher hasher = new Pbkdf2PasswordHasher();

    @Test
    public void laClaveCorrectaSeVerifica() {
        assertTrue(hasher.verificar("admin123", hasher.hash("admin123")));
    }

    @Test
    public void unaClaveIncorrectaNoSeVerifica() {
        assertFalse(hasher.verificar("otra", hasher.hash("admin123")));
    }

    @Test
    public void elHashNuncaEsLaClaveEnTextoPlano() {
        String h = hasher.hash("admin123");
        assertFalse(h.contains("admin123"));
    }

    @Test
    public void dosHashesDeLaMismaClaveSonDistintosPorLaSal() {
        assertFalse(hasher.hash("admin123").equals(hasher.hash("admin123")));
    }

    @Test
    public void unHashCorruptoNoVerificaNiLanzaError() {
        assertFalse(hasher.verificar("admin123", "esto-no-es-un-hash"));
    }
}
