package vetmvc;

import config.Contenedor;
import controlador.CtrlLogin;
import javax.swing.SwingUtilities;
import vista.FrmLogin;
import vista.Tema;

/**
 * Punto de entrada: arma el contenedor de dependencias (DAO -> Servicio) y abre el login.
 * Después de iniciar sesión, el menú principal crea la Vista y el Controlador de cada módulo.
 */
public class Main {

    public static void main(String[] args) {
        Tema.instalar();   // colores y aspecto visual de DR.SHEEP (clase vista.Tema)

        SwingUtilities.invokeLater(() -> {
            Contenedor contenedor = Contenedor.porDefecto();
            new CtrlLogin(contenedor.autenticacion(), new FrmLogin(), contenedor).iniciar();
        });
    }
}
