package controlador;

import config.Contenedor;
import dao.DaoException;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import servicio.AutenticacionService;
import servicio.ResultadoLogin;
import util.Mensajes;
import vista.FrmLogin;
import vista.FrmPrincipal;

/** CONTROLADOR - Pide validar el inicio de sesión (RF01) al servicio y abre el menú principal. */
public class CtrlLogin implements ActionListener {

    private final AutenticacionService servicio;
    private final FrmLogin frm;
    private final Contenedor contenedor;

    public CtrlLogin(AutenticacionService servicio, FrmLogin frm, Contenedor contenedor) {
        this.servicio = servicio;
        this.frm = frm;
        this.contenedor = contenedor;
        frm.btnIngresar.addActionListener(this);
    }

    public void iniciar() {
        frm.setLocationRelativeTo(null);
        frm.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        String usuario = frm.txtUsuario.getText().trim();
        String clave = new String(frm.txtClave.getPassword());
        if (usuario.isEmpty() || clave.isEmpty()) {
            frm.lblMensaje.setText("Ingresa tu usuario y contraseña.");
            return;
        }
        try {
            ResultadoLogin r = servicio.autenticar(usuario, clave);
            switch (r.getEstado()) {
                case OK:
                    new CtrlPrincipal(new FrmPrincipal(), r.getUsuario(), contenedor).iniciar();
                    frm.dispose();
                    break;
                case BLOQUEADO:
                    frm.lblMensaje.setText("Cuenta bloqueada (3 intentos fallidos). Habla con el administrador.");
                    break;
                default:
                    frm.lblMensaje.setText("Usuario o contraseña incorrectos.");
                    break;
            }
        } catch (DaoException ex) {
            Mensajes.sinConexion(frm, ex.getMessage());
            frm.lblMensaje.setText("Sin conexión a la base de datos.");
        }
        frm.txtClave.setText("");
    }
}
