package controlador;

import config.Contenedor;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import modelo.Usuario;
import seguridad.Permiso;
import vista.FrmCita;
import vista.FrmComprobante;
import vista.FrmLogin;
import vista.FrmMascota;
import vista.FrmPrincipal;
import vista.FrmProducto;

/**
 * CONTROLADOR - Menú principal. Habilita los módulos según los permisos del rol (PoliticaPermisos)
 * y abre cada pantalla creando su Vista y su Controlador con los servicios del contenedor.
 */
public class CtrlPrincipal implements ActionListener {

    private final FrmPrincipal frm;
    private final Usuario usuario;
    private final Contenedor contenedor;
    private JFrame abierta;   // evita abrir dos veces la misma ventana

    public CtrlPrincipal(FrmPrincipal frm, Usuario usuario, Contenedor contenedor) {
        this.frm = frm;
        this.usuario = usuario;
        this.contenedor = contenedor;
        frm.btnMascotas.addActionListener(this);
        frm.btnCitas.addActionListener(this);
        frm.btnInventario.addActionListener(this);
        frm.btnFacturacion.addActionListener(this);
        frm.btnCerrarSesion.addActionListener(this);
    }

    public void iniciar() {
        frm.lblUsuario.setText(usuario.getNombreCompleto() + "  |  " + usuario.getRol());

        String rol = usuario.getRol();
        frm.btnMascotas.setEnabled(contenedor.permisos().puede(rol, Permiso.VER_MASCOTAS));
        frm.btnCitas.setEnabled(contenedor.permisos().puede(rol, Permiso.VER_CITAS));
        frm.btnInventario.setEnabled(contenedor.permisos().puede(rol, Permiso.VER_INVENTARIO));
        frm.btnFacturacion.setEnabled(contenedor.permisos().puede(rol, Permiso.VER_FACTURACION));

        frm.setLocationRelativeTo(null);
        frm.setVisible(true);
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object origen = e.getSource();
        if (origen == frm.btnMascotas) {
            FrmMascota v = new FrmMascota();
            abrir(v, () -> new CtrlMascota(contenedor.mascotas(), v, usuario, contenedor.permisos()).iniciar());
        } else if (origen == frm.btnCitas) {
            FrmCita v = new FrmCita();
            abrir(v, () -> new CtrlCita(contenedor.citas(), v, usuario, contenedor.permisos()).iniciar());
        } else if (origen == frm.btnInventario) {
            FrmProducto v = new FrmProducto();
            abrir(v, () -> new CtrlProducto(contenedor.inventario(), v, usuario).iniciar());
        } else if (origen == frm.btnFacturacion) {
            FrmComprobante v = new FrmComprobante();
            abrir(v, () -> new CtrlComprobante(contenedor.facturacion(), v, usuario).iniciar());
        } else if (origen == frm.btnCerrarSesion) {
            if (abierta != null) {
                abierta.dispose();
            }
            frm.dispose();
            new CtrlLogin(contenedor.autenticacion(), new FrmLogin(), contenedor).iniciar();
        }
    }

    /** Cierra la ventana de módulo anterior (si la hay) y muestra la nueva. */
    private void abrir(JFrame ventana, Runnable configurar) {
        if (abierta != null) {
            abierta.dispose();
        }
        abierta = ventana;
        configurar.run();
        ventana.setVisible(true);
    }
}
