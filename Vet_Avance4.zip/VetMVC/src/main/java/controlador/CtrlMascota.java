package controlador;

import java.awt.event.ActionEvent;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import modelo.Atencion;
import modelo.Cliente;
import modelo.Mascota;
import modelo.Usuario;
import seguridad.Permiso;
import seguridad.PoliticaPermisos;
import servicio.MascotaFormulario;
import servicio.MascotaService;
import util.Mensajes;
import vista.FrmMascota;

/**
 * CONTROLADOR - Clientes y mascotas. Escucha los botones de la Vista, le pasa los textos al
 * MascotaService (que valida y guarda) y actualiza la Vista con el resultado.
 */
public class CtrlMascota extends ControladorBase {

    private static final DateTimeFormatter FECHA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final MascotaService servicio;
    private final FrmMascota frm;
    private final Usuario usuario;
    private final PoliticaPermisos permisos;
    private List<Mascota> mostradas = new ArrayList<>();

    public CtrlMascota(MascotaService servicio, FrmMascota frm, Usuario usuario, PoliticaPermisos permisos) {
        super(frm, frm.lblEstado);
        this.servicio = servicio;
        this.frm = frm;
        this.usuario = usuario;
        this.permisos = permisos;

        frm.btnGuardar.addActionListener(this);
        frm.btnModificar.addActionListener(this);
        frm.btnEliminar.addActionListener(this);
        frm.btnLimpiar.addActionListener(this);
        frm.btnBuscar.addActionListener(this);
        frm.btnTodos.addActionListener(this);
        frm.btnBuscarDni.addActionListener(this);
        frm.btnHistorial.addActionListener(this);

        frm.tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                seleccionarFila();
            }
        });
    }

    public void iniciar() {
        frm.setLocationRelativeTo(null);
        // Quien no tiene permiso de edición (ej. el veterinario) solo consulta.
        boolean edita = permisos.puede(usuario.getRol(), Permiso.EDITAR_MASCOTAS);
        frm.btnGuardar.setEnabled(edita);
        frm.btnModificar.setEnabled(edita);
        frm.btnEliminar.setEnabled(edita);
        cargarInicial(() -> {
            cargarTabla(servicio.listar());
            estado("Listo. " + mostradas.size() + " mascota(s) registrada(s).");
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        if (o == frm.btnGuardar) {
            guardar();
        } else if (o == frm.btnModificar) {
            modificar();
        } else if (o == frm.btnEliminar) {
            eliminar();
        } else if (o == frm.btnLimpiar) {
            limpiar();
        } else if (o == frm.btnBuscar) {
            buscar();
        } else if (o == frm.btnTodos) {
            ejecutar("consultar", () -> {
                frm.txtBuscar.setText("");
                cargarTabla(servicio.listar());
                estado("Mostrando todas las mascotas.");
            });
        } else if (o == frm.btnBuscarDni) {
            buscarDueno();
        } else if (o == frm.btnHistorial) {
            verHistorial();
        }
    }

    // ---------------- Operaciones ----------------

    private void guardar() {
        ejecutar("guardar", () -> {
            servicio.registrar(leerFormulario());
            limpiar();
            cargarTabla(servicio.listar());
            estado("Mascota registrada correctamente.");
        });
    }

    private void modificar() {
        if (!haySeleccion()) {
            return;
        }
        ejecutar("modificar", () -> {
            servicio.modificar(idSeleccionado(), leerFormulario());
            limpiar();
            cargarTabla(servicio.listar());
            estado("Mascota modificada correctamente.");
        });
    }

    private void eliminar() {
        if (!haySeleccion()) {
            return;
        }
        if (!Mensajes.confirmar(frm, "¿Eliminar a \"" + frm.txtNombre.getText().trim()
                + "\"? (se conserva su historial)")) {
            return;
        }
        ejecutar("eliminar", () -> {
            servicio.eliminar(idSeleccionado());
            limpiar();
            cargarTabla(servicio.listar());
            estado("Mascota eliminada.");
        });
    }

    private void buscar() {
        ejecutar("consultar", () -> {
            String texto = frm.txtBuscar.getText().trim();
            cargarTabla(servicio.buscar(texto));
            estado(texto.isEmpty() ? "Mostrando todas las mascotas."
                    : mostradas.size() + " resultado(s) para \"" + texto + "\".");
        });
    }

    private void buscarDueno() {
        ejecutar("consultar al dueño", () -> {
            Cliente c = servicio.buscarDueno(frm.txtDni.getText()).orElse(null);
            if (c == null) {
                estado("DNI no registrado: completa los datos del dueño y se registrará al guardar.");
                return;
            }
            frm.txtDueno.setText(c.getNombres());
            frm.txtTelefono.setText(c.getTelefono() == null ? "" : c.getTelefono());
            frm.txtDireccion.setText(c.getDireccion() == null ? "" : c.getDireccion());
            estado("Dueño encontrado: " + c.getNombres());
        });
    }

    /** RF04: muestra el historial médico de la mascota seleccionada. */
    private void verHistorial() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0) {
            Mensajes.aviso(frm, "Selecciona una mascota de la tabla.");
            return;
        }
        Mascota m = mostradas.get(fila);
        ejecutar("consultar el historial", () -> {
            List<Atencion> atenciones = servicio.historial(m.getId());
            StringBuilder sb = new StringBuilder();
            if (atenciones.isEmpty()) {
                sb.append("Esta mascota aún no tiene atenciones registradas.");
            }
            for (Atencion a : atenciones) {
                sb.append(a.getFecha().format(FECHA_HORA)).append('\n')
                  .append("  Diagnóstico: ").append(a.getDiagnostico()).append('\n')
                  .append("  Tratamiento: ").append(a.getTratamiento() == null ? "-" : a.getTratamiento())
                  .append("\n\n");
            }
            JTextArea area = new JTextArea(sb.toString(), 14, 48);
            area.setEditable(false);
            javax.swing.JOptionPane.showMessageDialog(frm, new JScrollPane(area),
                    "Historial médico de " + m.getNombre(), javax.swing.JOptionPane.PLAIN_MESSAGE);
        });
    }

    // ---------------- Apoyo ----------------

    /** Solo lee los textos de la Vista; la validación la hace el servicio. */
    private MascotaFormulario leerFormulario() {
        return new MascotaFormulario(frm.txtDni.getText(), frm.txtDueno.getText(), frm.txtTelefono.getText(),
                frm.txtDireccion.getText(), frm.txtNombre.getText(), frm.txtEspecie.getText(),
                frm.txtRaza.getText(), frm.cmbSexo.getSelectedIndex() == 0 ? "M" : "H",
                frm.txtNacimiento.getText(), frm.txtPeso.getText());
    }

    private boolean haySeleccion() {
        if (frm.txtId.getText().trim().isEmpty()) {
            Mensajes.aviso(frm, "Primero selecciona una mascota de la tabla.");
            return false;
        }
        return true;
    }

    private int idSeleccionado() {
        return Integer.parseInt(frm.txtId.getText().trim());
    }

    private void cargarTabla(List<Mascota> lista) {
        mostradas = lista;
        frm.modeloTabla.setRowCount(0);
        for (Mascota m : lista) {
            Cliente c = m.getCliente();
            frm.modeloTabla.addRow(new Object[]{
                m.getId(), m.getNombre(), m.getEspecie(), m.getRaza(),
                m.getSexo().equals("M") ? "Macho" : "Hembra",
                m.getFechaNacimiento() == null ? "" : m.getFechaNacimiento().toString(),
                m.getPeso(), c.getDni(), c.getNombres(), c.getTelefono(), c.getDireccion()
            });
        }
    }

    private void seleccionarFila() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0 || fila >= mostradas.size()) {
            return;
        }
        Mascota m = mostradas.get(fila);
        Cliente c = m.getCliente();
        frm.txtId.setText(String.valueOf(m.getId()));
        frm.txtNombre.setText(m.getNombre());
        frm.txtEspecie.setText(m.getEspecie());
        frm.txtRaza.setText(m.getRaza() == null ? "" : m.getRaza());
        frm.cmbSexo.setSelectedIndex(m.getSexo().equals("M") ? 0 : 1);
        frm.txtNacimiento.setText(m.getFechaNacimiento() == null ? "" : m.getFechaNacimiento().toString());
        frm.txtPeso.setText(String.valueOf(m.getPeso()));
        frm.txtDni.setText(c.getDni());
        frm.txtDueno.setText(c.getNombres());
        frm.txtTelefono.setText(c.getTelefono() == null ? "" : c.getTelefono());
        frm.txtDireccion.setText(c.getDireccion() == null ? "" : c.getDireccion());
    }

    private void limpiar() {
        for (JTextField t : new JTextField[]{frm.txtId, frm.txtDni, frm.txtDueno,
            frm.txtTelefono, frm.txtDireccion, frm.txtNombre, frm.txtEspecie, frm.txtRaza,
            frm.txtNacimiento, frm.txtPeso}) {
            t.setText("");
        }
        frm.cmbSexo.setSelectedIndex(0);
        frm.tabla.clearSelection();
        frm.txtDni.requestFocus();
    }
}
