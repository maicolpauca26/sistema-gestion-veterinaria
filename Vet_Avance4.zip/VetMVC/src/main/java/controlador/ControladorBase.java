package controlador;

import dao.DaoException;
import java.awt.event.ActionListener;
import javax.swing.JFrame;
import javax.swing.JLabel;
import servicio.ValidacionException;
import util.Mensajes;

/**
 * CONTROLADOR - Comportamiento común de los controladores de módulo (SRP/DRY): muestra el estado,
 * y traduce los errores del servicio a mensajes para el usuario.
 *   ValidacionException -> aviso (dato inválido o regla de negocio)
 *   DaoException        -> error (la base de datos falló)
 */
abstract class ControladorBase implements ActionListener {

    private final JFrame ventana;
    private final JLabel lblEstado;

    protected ControladorBase(JFrame ventana, JLabel lblEstado) {
        this.ventana = ventana;
        this.lblEstado = lblEstado;
    }

    protected void estado(String mensaje) {
        lblEstado.setText("  " + mensaje);
    }

    /** Ejecuta una operación y muestra el mensaje adecuado si falla. {@code accion}: "guardar", "modificar"... */
    protected void ejecutar(String accion, Runnable operacion) {
        try {
            operacion.run();
        } catch (ValidacionException e) {
            Mensajes.aviso(ventana, e.getMessage());
        } catch (DaoException e) {
            Mensajes.error(ventana, "No se pudo " + accion + ":\n" + e.getMessage());
        }
    }

    /** Carga inicial: si la BD no responde muestra el aviso estándar de "sin conexión". */
    protected void cargarInicial(Runnable carga) {
        try {
            carga.run();
        } catch (DaoException e) {
            Mensajes.sinConexion(ventana, e.getMessage());
            estado("Sin conexión a la base de datos.");
        }
    }
}
