package controlador;

import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.List;
import modelo.Producto;
import modelo.TipoMovimiento;
import modelo.Usuario;
import servicio.InventarioService;
import servicio.ProductoFormulario;
import util.Mensajes;
import vista.FrmProducto;

/** CONTROLADOR - Inventario: productos, entradas, salidas y alerta de stock mínimo (RF09 a RF11). */
public class CtrlProducto extends ControladorBase {

    private final InventarioService servicio;
    private final FrmProducto frm;
    private final Usuario usuario;
    private List<Producto> mostrados = new ArrayList<>();

    public CtrlProducto(InventarioService servicio, FrmProducto frm, Usuario usuario) {
        super(frm, frm.lblEstado);
        this.servicio = servicio;
        this.frm = frm;
        this.usuario = usuario;

        frm.btnGuardar.addActionListener(this);
        frm.btnModificar.addActionListener(this);
        frm.btnEliminar.addActionListener(this);
        frm.btnLimpiar.addActionListener(this);
        frm.btnBuscar.addActionListener(this);
        frm.btnTodos.addActionListener(this);
        frm.btnCriticos.addActionListener(this);
        frm.btnEntrada.addActionListener(this);
        frm.btnSalida.addActionListener(this);

        frm.tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                seleccionarFila();
            }
        });
    }

    public void iniciar() {
        frm.setLocationRelativeTo(null);
        cargarInicial(() -> {
            cargarTabla(servicio.listar());
            actualizarAlerta();
            estado("Listo. " + mostrados.size() + " producto(s).");
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        if (o == frm.btnGuardar) {
            guardar();
        } else if (o == frm.btnModificar) {
            modificar();
        } else if (o == frm.btnEliminar) {
            eliminar();
        } else if (o == frm.btnLimpiar) {
            limpiar();
        } else if (o == frm.btnBuscar) {
            buscar();
        } else if (o == frm.btnTodos) {
            ejecutar("consultar", () -> {
                frm.txtBuscar.setText("");
                cargarTabla(servicio.listar());
                estado("Mostrando todos los productos.");
            });
        } else if (o == frm.btnCriticos) {
            ejecutar("consultar", () -> {
                cargarTabla(servicio.listarCriticos());
                estado(mostrados.size() + " producto(s) con stock crítico.");
            });
        } else if (o == frm.btnEntrada) {
            movimiento(TipoMovimiento.ENTRADA);
        } else if (o == frm.btnSalida) {
            movimiento(TipoMovimiento.SALIDA);
        }
    }

    // ---------------- Operaciones ----------------

    private void guardar() {
        ejecutar("guardar", () -> {
            servicio.registrar(leerFormulario());
            limpiar();
            recargar();
            estado("Producto registrado. Usa \"Registrar ENTRADA\" para darle stock.");
        });
    }

    private void modificar() {
        if (!haySeleccion()) {
            return;
        }
        ejecutar("modificar", () -> {
            servicio.modificar(idSeleccionado(), leerFormulario());
            limpiar();
            recargar();
            estado("Producto modificado.");
        });
    }

    private void eliminar() {
        if (!haySeleccion()) {
            return;
        }
        if (!Mensajes.confirmar(frm, "¿Eliminar \"" + frm.txtNombre.getText().trim() + "\"?")) {
            return;
        }
        ejecutar("eliminar", () -> {
            servicio.eliminar(idSeleccionado());
            limpiar();
            recargar();
            estado("Producto eliminado.");
        });
    }

    private void buscar() {
        ejecutar("consultar", () -> {
            cargarTabla(servicio.buscar(frm.txtBuscar.getText()));
            estado(mostrados.size() + " resultado(s).");
        });
    }

    /** Entrada (compra) o salida (consumo) de stock. */
    private void movimiento(TipoMovimiento tipo) {
        int fila = frm.tabla.getSelectedRow();
        if (!haySeleccion() || fila < 0 || fila >= mostrados.size()) {
            return;
        }
        Producto elegido = mostrados.get(fila);
        ejecutar("registrar el movimiento", () -> {
            servicio.registrarMovimiento(elegido, tipo, frm.txtCantidad.getText(), usuario.getId());
            String cantidad = frm.txtCantidad.getText().trim();
            limpiar();
            recargar();
            estado(tipo + " de " + cantidad + " unidad(es) de " + elegido.getNombre() + " registrada.");
        });
    }

    // ---------------- Apoyo ----------------

    /** Solo lee los textos de la Vista; la validación la hace el servicio. */
    private ProductoFormulario leerFormulario() {
        return new ProductoFormulario(frm.txtCodigo.getText(), frm.txtNombre.getText(),
                frm.txtPrecio.getText(), frm.txtStockMinimo.getText());
    }

    private boolean haySeleccion() {
        if (frm.txtId.getText().trim().isEmpty()) {
            Mensajes.aviso(frm, "Primero selecciona un producto de la tabla.");
            return false;
        }
        return true;
    }

    private int idSeleccionado() {
        return Integer.parseInt(frm.txtId.getText().trim());
    }

    private void recargar() {
        cargarTabla(servicio.listar());
        actualizarAlerta();
    }

    /** RF11: muestra una alerta visible si hay productos en o por debajo del stock mínimo. */
    private void actualizarAlerta() {
        List<Producto> criticos = servicio.listarCriticos();
        if (criticos.isEmpty()) {
            frm.lblAlerta.setText(" ");
            return;
        }
        StringBuilder sb = new StringBuilder("  ⚠ ALERTA de stock mínimo: ");
        for (int i = 0; i < criticos.size(); i++) {
            sb.append(i > 0 ? ", " : "").append(criticos.get(i).getNombre())
              .append(" (").append(criticos.get(i).getStock()).append(')');
        }
        frm.lblAlerta.setText(sb.toString());
    }

    private void cargarTabla(List<Producto> lista) {
        mostrados = lista;
        frm.modeloTabla.setRowCount(0);
        for (Producto p : lista) {
            frm.modeloTabla.addRow(new Object[]{
                p.getId(), p.getCodigo(), p.getNombre(), p.getPrecio(), p.getStock(), p.getStockMinimo()
            });
        }
    }

    private void seleccionarFila() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0 || fila >= mostrados.size()) {
            return;
        }
        Producto p = mostrados.get(fila);
        frm.txtId.setText(String.valueOf(p.getId()));
        frm.txtCodigo.setText(p.getCodigo());
        frm.txtNombre.setText(p.getNombre());
        frm.txtPrecio.setText(p.getPrecio().toPlainString());
        frm.txtStockMinimo.setText(String.valueOf(p.getStockMinimo()));
        frm.txtStock.setText(String.valueOf(p.getStock()));
    }

    private void limpiar() {
        frm.txtId.setText("");
        frm.txtCodigo.setText("");
        frm.txtNombre.setText("");
        frm.txtPrecio.setText("");
        frm.txtStockMinimo.setText("");
        frm.txtStock.setText("");
        frm.txtCantidad.setText("");
        frm.tabla.clearSelection();
        frm.txtCodigo.requestFocus();
    }
}
