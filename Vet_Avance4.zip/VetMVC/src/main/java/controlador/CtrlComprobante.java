package controlador;

import java.awt.event.ActionEvent;
import java.time.format.DateTimeFormatter;
import modelo.Atencion;
import modelo.Comprobante;
import modelo.DetalleComprobante;
import modelo.Producto;
import modelo.Servicio;
import modelo.Usuario;
import servicio.FacturacionService;
import util.Mensajes;
import vista.FrmComprobante;

/** CONTROLADOR - Facturación: arma la boleta en pantalla y pide al servicio emitirla (RF12 y RF13). */
public class CtrlComprobante extends ControladorBase {

    private static final DateTimeFormatter FECHA_HORA = DateTimeFormatter.ofPattern("dd/MM/yyyy HH:mm");

    private final FacturacionService servicio;
    private final FrmComprobante frm;
    private final Usuario usuario;
    private Comprobante actual = new Comprobante();   // boleta en construcción

    public CtrlComprobante(FacturacionService servicio, FrmComprobante frm, Usuario usuario) {
        super(frm, frm.lblEstado);
        this.servicio = servicio;
        this.frm = frm;
        this.usuario = usuario;
        frm.btnAgregarServicio.addActionListener(this);
        frm.btnAgregarProducto.addActionListener(this);
        frm.btnQuitar.addActionListener(this);
        frm.btnEmitir.addActionListener(this);
        frm.btnLimpiar.addActionListener(this);
    }

    public void iniciar() {
        frm.setLocationRelativeTo(null);
        cargarInicial(() -> {
            for (Servicio s : servicio.listarServicios()) {
                frm.cmbServicio.addItem(s);
            }
            recargarListas();
            estado("Listo. Elige una atención y agrega servicios y productos.");
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        if (o == frm.btnAgregarServicio) {
            agregarServicio();
        } else if (o == frm.btnAgregarProducto) {
            agregarProducto();
        } else if (o == frm.btnQuitar) {
            quitarLinea();
        } else if (o == frm.btnEmitir) {
            emitir();
        } else if (o == frm.btnLimpiar) {
            limpiar();
        }
    }

    // ---------------- Operaciones ----------------

    private void agregarServicio() {
        Servicio s = (Servicio) frm.cmbServicio.getSelectedItem();
        if (s == null) {
            return;
        }
        ejecutar("agregar el servicio", () -> {
            servicio.agregarServicio(actual, s, (Integer) frm.spnServicio.getValue());
            refrescarDetalle();
        });
    }

    private void agregarProducto() {
        Producto p = (Producto) frm.cmbProducto.getSelectedItem();
        if (p == null) {
            return;
        }
        ejecutar("agregar el producto", () -> {
            servicio.agregarProducto(actual, p, (Integer) frm.spnProducto.getValue());
            refrescarDetalle();
        });
    }

    private void quitarLinea() {
        ejecutar("quitar la línea", () -> {
            servicio.quitarLinea(actual, frm.tablaDetalle.getSelectedRow());
            refrescarDetalle();
        });
    }

    private void emitir() {
        Atencion a = (Atencion) frm.cmbAtencion.getSelectedItem();
        ejecutar("emitir el comprobante (no se guardó nada)", () -> {
            servicio.emitir(actual, a, (String) frm.cmbPago.getSelectedItem(), usuario.getId());
            Mensajes.info(frm, "Boleta " + actual.getNumeroCompleto() + " emitida.\n"
                    + "Cliente: " + a.getCliente() + "\nTotal: S/ " + actual.getTotal()
                    + "  (" + actual.getMetodoPago() + ")");
            estado("Boleta " + actual.getNumeroCompleto() + " emitida correctamente.");
            limpiar();
            recargarListas();
        });
    }

    // ---------------- Apoyo ----------------

    private void refrescarDetalle() {
        frm.modeloDetalle.setRowCount(0);
        for (DetalleComprobante d : actual.getDetalles()) {
            frm.modeloDetalle.addRow(new Object[]{
                d.getDescripcion(), d.getCantidad(), d.getPrecioUnitario(), d.getSubtotal()
            });
        }
        actual.calcularTotales();
        frm.lblSubtotal.setText("S/ " + actual.getSubtotal());
        frm.lblIgv.setText("S/ " + actual.getIgv());
        frm.lblTotal.setText("S/ " + actual.getTotal());
    }

    /** Recarga las atenciones pendientes, los productos con su stock actual y los comprobantes emitidos. */
    private void recargarListas() {
        frm.cmbAtencion.removeAllItems();
        for (Atencion a : servicio.listarAtencionesPendientes()) {
            frm.cmbAtencion.addItem(a);
        }
        frm.cmbProducto.removeAllItems();
        for (Producto p : servicio.listarProductosConStock()) {
            frm.cmbProducto.addItem(p);
        }
        frm.modeloEmitidos.setRowCount(0);
        for (Comprobante c : servicio.listarEmitidos()) {
            frm.modeloEmitidos.addRow(new Object[]{
                c.getNumeroCompleto(), c.getFecha().format(FECHA_HORA), c.getCliente(), c.getMetodoPago(),
                c.getSubtotal(), c.getIgv(), c.getTotal()
            });
        }
    }

    private void limpiar() {
        actual = new Comprobante();
        refrescarDetalle();
    }
}
