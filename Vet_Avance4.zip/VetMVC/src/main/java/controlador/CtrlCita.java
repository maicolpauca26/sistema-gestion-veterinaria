package controlador;

import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import modelo.Cita;
import modelo.Mascota;
import modelo.Usuario;
import seguridad.Permiso;
import seguridad.PoliticaPermisos;
import servicio.CitaFormulario;
import servicio.CitaService;
import util.Mensajes;
import vista.FrmCita;

/** CONTROLADOR - Agenda de citas: programar, confirmar, cancelar y registrar la atención (RF06 a RF08). */
public class CtrlCita extends ControladorBase {

    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private final CitaService servicio;
    private final FrmCita frm;
    private final Usuario usuario;
    private final PoliticaPermisos permisos;
    private List<Cita> mostradas = new ArrayList<>();

    public CtrlCita(CitaService servicio, FrmCita frm, Usuario usuario, PoliticaPermisos permisos) {
        super(frm, frm.lblEstado);
        this.servicio = servicio;
        this.frm = frm;
        this.usuario = usuario;
        this.permisos = permisos;

        frm.btnProgramar.addActionListener(this);
        frm.btnModificar.addActionListener(this);
        frm.btnConfirmar.addActionListener(this);
        frm.btnCancelar.addActionListener(this);
        frm.btnAtender.addActionListener(this);
        frm.btnLimpiar.addActionListener(this);
        frm.btnVerDia.addActionListener(this);
        frm.btnTodas.addActionListener(this);

        frm.tabla.getSelectionModel().addListSelectionListener(e -> {
            if (!e.getValueIsAdjusting()) {
                seleccionarFila();
            }
        });
    }

    public void iniciar() {
        frm.setLocationRelativeTo(null);

        // Permisos por rol: el veterinario atiende; recepción programa, confirma y cancela.
        boolean puedeAgendar = permisos.puede(usuario.getRol(), Permiso.AGENDAR_CITAS);
        boolean puedeAtender = permisos.puede(usuario.getRol(), Permiso.ATENDER_CITAS);
        frm.btnProgramar.setEnabled(puedeAgendar);
        frm.btnModificar.setEnabled(puedeAgendar);
        frm.btnConfirmar.setEnabled(puedeAgendar);
        frm.btnCancelar.setEnabled(puedeAgendar);
        frm.btnAtender.setEnabled(puedeAtender);

        frm.txtFiltroFecha.setText(LocalDate.now().format(FECHA));
        frm.txtFecha.setText(LocalDate.now().format(FECHA));
        cargarInicial(() -> {
            for (Mascota m : servicio.mascotasDisponibles()) {
                frm.cmbMascota.addItem(m);
            }
            for (Usuario v : servicio.veterinariosDisponibles()) {
                frm.cmbVeterinario.addItem(v);
            }
            cargarTabla(servicio.listarTodas());
            estado("Listo. " + mostradas.size() + " cita(s) registrada(s).");
        });
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        Object o = e.getSource();
        if (o == frm.btnProgramar) {
            programar();
        } else if (o == frm.btnModificar) {
            reprogramar();
        } else if (o == frm.btnConfirmar) {
            confirmar();
        } else if (o == frm.btnCancelar) {
            cancelar();
        } else if (o == frm.btnAtender) {
            atender();
        } else if (o == frm.btnLimpiar) {
            limpiar();
        } else if (o == frm.btnVerDia) {
            verDia();
        } else if (o == frm.btnTodas) {
            ejecutar("consultar", () -> {
                cargarTabla(servicio.listarTodas());
                estado("Mostrando todas las citas.");
            });
        }
    }

    // ---------------- Operaciones ----------------

    private void programar() {
        ejecutar("programar", () -> {
            servicio.programar(leerFormulario(), usuario.getId());
            limpiar();
            cargarTabla(servicio.listarTodas());
            estado("Cita programada correctamente (estado PROGRAMADA).");
        });
    }

    private void reprogramar() {
        Cita actual = citaSeleccionada();
        if (actual == null) {
            return;
        }
        ejecutar("modificar", () -> {
            servicio.reprogramar(actual, leerFormulario());
            limpiar();
            cargarTabla(servicio.listarTodas());
            estado("Cita reprogramada.");
        });
    }

    private void confirmar() {
        Cita c = citaSeleccionada();
        if (c == null) {
            return;
        }
        ejecutar("actualizar", () -> {
            servicio.confirmar(c);
            limpiar();
            cargarTabla(servicio.listarTodas());
            estado("Cita confirmada.");
        });
    }

    private void cancelar() {
        Cita c = citaSeleccionada();
        if (c == null) {
            return;
        }
        ejecutar("actualizar", () -> {
            servicio.cancelar(c);
            limpiar();
            cargarTabla(servicio.listarTodas());
            estado("Cita cancelada.");
        });
    }

    private void atender() {
        Cita c = citaSeleccionada();
        if (c == null) {
            return;
        }
        ejecutar("registrar la atención", () -> {
            servicio.atender(c, frm.txtDiagnostico.getText(), frm.txtTratamiento.getText());
            limpiar();
            cargarTabla(servicio.listarTodas());
            estado("Atención registrada. La cita quedó ATENDIDA y ya se puede facturar.");
        });
    }

    private void verDia() {
        ejecutar("consultar", () -> {
            LocalDate dia = servicio.parsearFecha(frm.txtFiltroFecha.getText());
            cargarTabla(servicio.agenda(dia));
            estado(mostradas.size() + " cita(s) el " + dia + ".");
        });
    }

    // ---------------- Apoyo ----------------

    /** Solo lee lo elegido en la Vista; las reglas (pasado, cruce de horario...) las aplica el servicio. */
    private CitaFormulario leerFormulario() {
        return new CitaFormulario((Mascota) frm.cmbMascota.getSelectedItem(),
                (Usuario) frm.cmbVeterinario.getSelectedItem(),
                frm.txtFecha.getText(), (String) frm.cmbHora.getSelectedItem(), frm.txtMotivo.getText());
    }

    private Cita citaSeleccionada() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0 || fila >= mostradas.size()) {
            Mensajes.aviso(frm, "Primero selecciona una cita de la tabla.");
            return null;
        }
        return mostradas.get(fila);
    }

    private void cargarTabla(List<Cita> lista) {
        mostradas = lista;
        frm.modeloTabla.setRowCount(0);
        for (Cita c : lista) {
            frm.modeloTabla.addRow(new Object[]{
                c.getId(), c.getFechaHora().toLocalDate(), c.getFechaHora().toLocalTime(),
                c.getMascota().getNombre(), c.getMascota().getCliente().getNombres(),
                c.getVeterinario().getNombreCompleto(), c.getMotivo(), c.getEstado()
            });
        }
    }

    private void seleccionarFila() {
        int fila = frm.tabla.getSelectedRow();
        if (fila < 0 || fila >= mostradas.size()) {
            return;
        }
        Cita c = mostradas.get(fila);
        frm.txtId.setText(String.valueOf(c.getId()));
        frm.txtFecha.setText(c.getFechaHora().toLocalDate().toString());
        frm.cmbHora.setSelectedItem(c.getFechaHora().toLocalTime().toString());
        frm.txtMotivo.setText(c.getMotivo());
        for (int i = 0; i < frm.cmbMascota.getItemCount(); i++) {
            if (frm.cmbMascota.getItemAt(i).getId() == c.getMascota().getId()) {
                frm.cmbMascota.setSelectedIndex(i);
            }
        }
        for (int i = 0; i < frm.cmbVeterinario.getItemCount(); i++) {
            if (frm.cmbVeterinario.getItemAt(i).getId() == c.getVeterinario().getId()) {
                frm.cmbVeterinario.setSelectedIndex(i);
            }
        }
    }

    private void limpiar() {
        frm.txtId.setText("");
        frm.txtMotivo.setText("");
        frm.txtDiagnostico.setText("");
        frm.txtTratamiento.setText("");
        frm.txtFecha.setText(LocalDate.now().format(FECHA));
        frm.tabla.clearSelection();
    }
}
