package modelo;

/** MODELO - Datos de acceso de un usuario tal como están guardados (hash, intentos, estado). */
public class CredencialUsuario {

    private final int id;
    private final String username;
    private final String passwordHash;
    private final String nombreCompleto;
    private final String rol;
    private final boolean activo;
    private final int intentosFallidos;

    public CredencialUsuario(int id, String username, String passwordHash, String nombreCompleto,
                             String rol, boolean activo, int intentosFallidos) {
        this.id = id; this.username = username; this.passwordHash = passwordHash;
        this.nombreCompleto = nombreCompleto; this.rol = rol; this.activo = activo;
        this.intentosFallidos = intentosFallidos;
    }

    public int getId() { return id; }
    public String getUsername() { return username; }
    public String getPasswordHash() { return passwordHash; }
    public String getNombreCompleto() { return nombreCompleto; }
    public String getRol() { return rol; }
    public boolean isActivo() { return activo; }
    public int getIntentosFallidos() { return intentosFallidos; }

    public Usuario aUsuario() { return new Usuario(id, username, nombreCompleto, rol); }
}
