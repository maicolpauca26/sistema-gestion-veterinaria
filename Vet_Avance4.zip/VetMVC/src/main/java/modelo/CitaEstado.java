package modelo;

import java.util.EnumSet;
import java.util.Set;

/**
 * MODELO - Ciclo de vida de una cita. Las transiciones permitidas viven aquí, en un solo lugar
 * (OCP): agregar un estado nuevo no obliga a tocar el DAO ni los controladores.
 *
 *   PROGRAMADA -> CONFIRMADA -> ATENDIDA
 *        \            \
 *         +-> CANCELADA <-+
 */
public enum CitaEstado {
    PROGRAMADA, CONFIRMADA, CANCELADA, ATENDIDA;

    /** Estados a los que se puede pasar desde este. */
    public Set<CitaEstado> destinos() {
        switch (this) {
            case PROGRAMADA: return EnumSet.of(CONFIRMADA, CANCELADA);
            case CONFIRMADA: return EnumSet.of(ATENDIDA, CANCELADA);
            default:         return EnumSet.noneOf(CitaEstado.class);
        }
    }

    public boolean puedePasarA(CitaEstado destino) {
        return destinos().contains(destino);
    }

    /** Solo una cita PROGRAMADA o CONFIRMADA puede reprogramarse. */
    public boolean esEditable() {
        return this == PROGRAMADA || this == CONFIRMADA;
    }

    /** Estados desde los que se puede llegar a {@code destino} (lo usa el DAO para el UPDATE condicional). */
    public static Set<CitaEstado> origenesPara(CitaEstado destino) {
        Set<CitaEstado> origenes = EnumSet.noneOf(CitaEstado.class);
        for (CitaEstado e : values()) {
            if (e.puedePasarA(destino)) {
                origenes.add(e);
            }
        }
        return origenes;
    }

    /** Convierte el texto guardado en la BD (lanza IllegalArgumentException si no existe). */
    public static CitaEstado de(String texto) {
        return valueOf(texto);
    }
}
