package modelo;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

/** MODELO - Entidad Comprobante (boleta). Aquí vive la regla de negocio de subtotal, IGV y total. */
public class Comprobante {

    public static final BigDecimal IGV = new BigDecimal("0.18");
    /** Serie de las boletas. */
    public static final String SERIE = "B001";

    private int id;
    private int idAtencion;
    private String serie;
    private int numero;
    private LocalDateTime fecha;
    private String metodoPago;
    private String cliente;   // solo para mostrar
    private BigDecimal subtotal = BigDecimal.ZERO;
    private BigDecimal igv = BigDecimal.ZERO;
    private BigDecimal total = BigDecimal.ZERO;
    private final List<DetalleComprobante> detalles = new ArrayList<>();

    public int getId() { return id; }
    public void setId(int id) { this.id = id; }
    public int getIdAtencion() { return idAtencion; }
    public void setIdAtencion(int idAtencion) { this.idAtencion = idAtencion; }
    public String getSerie() { return serie; }
    public void setSerie(String serie) { this.serie = serie; }
    public int getNumero() { return numero; }
    public void setNumero(int numero) { this.numero = numero; }
    public LocalDateTime getFecha() { return fecha; }
    public void setFecha(LocalDateTime fecha) { this.fecha = fecha; }
    public String getMetodoPago() { return metodoPago; }
    public void setMetodoPago(String metodoPago) { this.metodoPago = metodoPago; }
    public String getCliente() { return cliente; }
    public void setCliente(String cliente) { this.cliente = cliente; }
    public BigDecimal getSubtotal() { return subtotal; }
    public BigDecimal getIgv() { return igv; }
    public BigDecimal getTotal() { return total; }
    public List<DetalleComprobante> getDetalles() { return detalles; }

    /** Se usa al leer un comprobante guardado en la BD. */
    public void setMontos(BigDecimal subtotal, BigDecimal igv, BigDecimal total) {
        this.subtotal = subtotal; this.igv = igv; this.total = total;
    }

    public String getNumeroCompleto() { return serie + "-" + String.format("%06d", numero); }

    /** Calcula subtotal, IGV (18 %) y total a partir de las líneas (RF12). */
    public void calcularTotales() {
        BigDecimal suma = BigDecimal.ZERO;
        for (DetalleComprobante d : detalles) {
            suma = suma.add(d.getSubtotal());
        }
        subtotal = suma.setScale(2, RoundingMode.HALF_UP);
        igv = subtotal.multiply(IGV).setScale(2, RoundingMode.HALF_UP);
        total = subtotal.add(igv);
    }
}
