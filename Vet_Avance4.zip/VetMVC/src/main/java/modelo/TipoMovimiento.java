package modelo;

/** MODELO - Tipo de movimiento de inventario. */
public enum TipoMovimiento { ENTRADA, SALIDA }
