package servicio;

import dao.ClienteDAO;
import dao.MascotaDAO;
import java.time.Clock;
import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import modelo.Atencion;
import modelo.Cliente;
import modelo.Mascota;

/** SERVICIO - Clientes y mascotas (RF02 a RF05). Depende de interfaces DAO, no de JDBC (DIP). */
public class MascotaService {

    private final MascotaDAO mascotas;
    private final ClienteDAO clientes;
    private final Clock reloj;

    public MascotaService(MascotaDAO mascotas, ClienteDAO clientes, Clock reloj) {
        this.mascotas = mascotas;
        this.clientes = clientes;
        this.reloj = reloj;
    }

    public void registrar(MascotaFormulario f) {
        mascotas.insertar(MascotaValidador.construir(f, LocalDate.now(reloj)));
    }

    public void modificar(int idMascota, MascotaFormulario f) {
        Mascota m = MascotaValidador.construir(f, LocalDate.now(reloj));
        m.setId(idMascota);
        mascotas.modificar(m);
    }

    public void eliminar(int idMascota) {
        if (!mascotas.eliminar(idMascota)) {
            throw new ValidacionException("No se encontró la mascota.");
        }
    }

    public List<Mascota> listar() {
        return mascotas.listar();
    }

    /** Sin texto devuelve todas las mascotas. */
    public List<Mascota> buscar(String texto) {
        String t = texto == null ? "" : texto.trim();
        return t.isEmpty() ? mascotas.listar() : mascotas.buscar(t);
    }

    /** Busca al dueño por DNI para autocompletar el formulario. */
    public Optional<Cliente> buscarDueno(String dni) {
        if (dni == null || !dni.trim().matches("\\d{8}")) {
            throw new ValidacionException("El DNI debe tener 8 dígitos.");
        }
        return clientes.buscarPorDni(dni.trim());
    }

    public List<Atencion> historial(int idMascota) {
        return mascotas.historial(idMascota);
    }
}
