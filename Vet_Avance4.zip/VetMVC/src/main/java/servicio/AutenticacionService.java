package servicio;

import dao.CredencialDAO;
import modelo.CredencialUsuario;
import seguridad.PasswordHasher;

/** SERVICIO - Inicio de sesión (RF01). Bloquea la cuenta tras 3 intentos fallidos. */
public class AutenticacionService {

    public static final int MAX_INTENTOS = 3;

    private final CredencialDAO credenciales;
    private final PasswordHasher hasher;

    public AutenticacionService(CredencialDAO credenciales, PasswordHasher hasher) {
        this.credenciales = credenciales;
        this.hasher = hasher;
    }

    /** Valida usuario y contraseña. Lanza DaoException si la BD no responde. */
    public ResultadoLogin autenticar(String username, String password) {
        CredencialUsuario c = credenciales.buscarPorUsername(username).orElse(null);
        if (c == null) {
            return ResultadoLogin.invalido();
        }
        if (!c.isActivo() || c.getIntentosFallidos() >= MAX_INTENTOS) {
            return ResultadoLogin.bloqueado();
        }
        if (!hasher.verificar(password, c.getPasswordHash())) {
            credenciales.registrarIntentoFallido(c.getId());
            return ResultadoLogin.invalido();
        }
        credenciales.registrarAccesoExitoso(c.getId());
        return ResultadoLogin.ok(c.aUsuario());
    }
}
