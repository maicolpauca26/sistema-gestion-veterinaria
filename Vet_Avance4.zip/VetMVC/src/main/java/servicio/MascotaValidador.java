package servicio;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import modelo.Cliente;
import modelo.Mascota;

/** Reglas de validación de mascota y dueño (SRP: solo valida y construye la entidad). */
public final class MascotaValidador {

    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd");

    private MascotaValidador() {
    }

    /** Valida el formulario y arma la Mascota con su Cliente. Lanza ValidacionException si hay un dato inválido. */
    public static Mascota construir(MascotaFormulario f, LocalDate hoy) {
        String dni = f.dni.trim();
        String dueno = f.dueno.trim();
        String telefono = f.telefono.trim();
        String nombre = f.nombre.trim();
        String especie = f.especie.trim();

        if (!dni.matches("\\d{8}")) {
            throw new ValidacionException("El DNI del dueño debe tener 8 dígitos.");
        }
        if (dueno.isEmpty() || nombre.isEmpty() || especie.isEmpty()) {
            throw new ValidacionException("Nombre del dueño, nombre de la mascota y especie son obligatorios.");
        }
        if (!telefono.isEmpty() && !telefono.matches("\\d{6,12}")) {
            throw new ValidacionException("El teléfono debe tener solo números (6 a 12 dígitos).");
        }
        double peso;
        try {
            peso = Double.parseDouble(f.peso.trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            throw new ValidacionException("El peso debe ser un número (ej. 12.5).");
        }
        if (peso <= 0 || peso > 200) {
            throw new ValidacionException("El peso debe ser mayor que 0 y no más de 200 kg.");
        }
        LocalDate nacimiento = null;
        String textoFecha = f.nacimiento.trim();
        if (!textoFecha.isEmpty()) {
            try {
                nacimiento = LocalDate.parse(textoFecha, FECHA);
            } catch (DateTimeParseException ex) {
                throw new ValidacionException("La fecha de nacimiento debe tener el formato aaaa-mm-dd (ej. 2022-03-10).");
            }
            if (nacimiento.isAfter(hoy)) {
                throw new ValidacionException("La fecha de nacimiento no puede ser futura.");
            }
        }

        Cliente c = new Cliente();
        c.setDni(dni);
        c.setNombres(dueno);
        c.setTelefono(telefono);
        c.setDireccion(f.direccion.trim());

        Mascota m = new Mascota();
        m.setCliente(c);
        m.setNombre(nombre);
        m.setEspecie(especie);
        m.setRaza(f.raza.trim());
        m.setSexo(f.sexo);
        m.setFechaNacimiento(nacimiento);
        m.setPeso(peso);
        return m;
    }
}
