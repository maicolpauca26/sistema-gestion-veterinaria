package servicio;

import dao.MovimientoInventarioDAO;
import dao.ProductoDAO;
import java.math.BigDecimal;
import java.util.List;
import modelo.Producto;
import modelo.TipoMovimiento;

/** SERVICIO - Inventario: productos, entradas, salidas y alerta de stock mínimo (RF09 a RF11). */
public class InventarioService {

    private final ProductoDAO productos;
    private final MovimientoInventarioDAO movimientos;

    public InventarioService(ProductoDAO productos, MovimientoInventarioDAO movimientos) {
        this.productos = productos;
        this.movimientos = movimientos;
    }

    public void registrar(ProductoFormulario f) {
        productos.insertar(construir(f));
    }

    public void modificar(int idProducto, ProductoFormulario f) {
        Producto p = construir(f);
        p.setId(idProducto);
        if (!productos.modificar(p)) {
            throw new ValidacionException("No se encontró el producto.");
        }
    }

    public void eliminar(int idProducto) {
        if (!productos.eliminar(idProducto)) {
            throw new ValidacionException("No se encontró el producto.");
        }
    }

    public List<Producto> listar() {
        return productos.listar();
    }

    public List<Producto> buscar(String texto) {
        String t = texto == null ? "" : texto.trim();
        return t.isEmpty() ? productos.listar() : productos.buscar(t);
    }

    public List<Producto> listarCriticos() {
        return productos.listarCriticos();
    }

    /** Entrada (compra) o salida (consumo). La salida no puede superar el stock del producto elegido. */
    public void registrarMovimiento(Producto elegido, TipoMovimiento tipo, String cantidadTexto, int idUsuario) {
        int cantidad;
        try {
            cantidad = Integer.parseInt(cantidadTexto.trim());
        } catch (NumberFormatException ex) {
            throw new ValidacionException("La cantidad debe ser un número entero.");
        }
        if (cantidad <= 0) {
            throw new ValidacionException("La cantidad debe ser mayor que 0.");
        }
        if (tipo == TipoMovimiento.SALIDA && cantidad > elegido.getStock()) {
            throw new ValidacionException("Stock insuficiente: solo hay " + elegido.getStock()
                    + " unidad(es) de " + elegido.getNombre() + ".");
        }
        movimientos.registrar(elegido.getId(), tipo, cantidad, idUsuario);
    }

    private Producto construir(ProductoFormulario f) {
        String codigo = f.codigo.trim();
        String nombre = f.nombre.trim();
        if (codigo.isEmpty() || nombre.isEmpty()) {
            throw new ValidacionException("Código y nombre son obligatorios.");
        }
        BigDecimal precio;
        int minimo;
        try {
            precio = new BigDecimal(f.precio.trim().replace(',', '.'));
        } catch (NumberFormatException ex) {
            throw new ValidacionException("El precio debe ser un número (ej. 3.50).");
        }
        try {
            minimo = Integer.parseInt(f.stockMinimo.trim());
        } catch (NumberFormatException ex) {
            throw new ValidacionException("El stock mínimo debe ser un número entero.");
        }
        if (precio.signum() < 0 || minimo < 0) {
            throw new ValidacionException("El precio y el stock mínimo no pueden ser negativos.");
        }
        Producto p = new Producto();
        p.setCodigo(codigo);
        p.setNombre(nombre);
        p.setPrecio(precio);
        p.setStockMinimo(minimo);
        return p;
    }
}
