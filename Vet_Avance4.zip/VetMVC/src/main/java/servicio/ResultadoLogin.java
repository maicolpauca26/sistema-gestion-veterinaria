package servicio;

import modelo.Usuario;

/** Resultado de un intento de inicio de sesión. */
public class ResultadoLogin {

    public enum Estado { OK, CREDENCIALES_INVALIDAS, BLOQUEADO }

    private final Estado estado;
    private final Usuario usuario;

    private ResultadoLogin(Estado estado, Usuario usuario) {
        this.estado = estado;
        this.usuario = usuario;
    }

    public static ResultadoLogin ok(Usuario u) { return new ResultadoLogin(Estado.OK, u); }
    public static ResultadoLogin invalido() { return new ResultadoLogin(Estado.CREDENCIALES_INVALIDAS, null); }
    public static ResultadoLogin bloqueado() { return new ResultadoLogin(Estado.BLOQUEADO, null); }

    public Estado getEstado() { return estado; }
    /** Usuario autenticado (solo si el estado es OK). */
    public Usuario getUsuario() { return usuario; }
}
