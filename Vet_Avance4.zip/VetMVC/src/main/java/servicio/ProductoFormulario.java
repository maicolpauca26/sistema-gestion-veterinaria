package servicio;

/** Datos de la pantalla de inventario tal como los escribió el usuario. */
public class ProductoFormulario {

    public final String codigo, nombre, precio, stockMinimo;

    public ProductoFormulario(String codigo, String nombre, String precio, String stockMinimo) {
        this.codigo = codigo; this.nombre = nombre; this.precio = precio; this.stockMinimo = stockMinimo;
    }
}
