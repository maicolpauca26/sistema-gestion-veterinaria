package servicio;

/** Datos de la pantalla de mascotas tal como los escribió el usuario (todo texto, sin validar). */
public class MascotaFormulario {

    public final String dni, dueno, telefono, direccion, nombre, especie, raza, sexo, nacimiento, peso;

    public MascotaFormulario(String dni, String dueno, String telefono, String direccion, String nombre,
                             String especie, String raza, String sexo, String nacimiento, String peso) {
        this.dni = dni; this.dueno = dueno; this.telefono = telefono; this.direccion = direccion;
        this.nombre = nombre; this.especie = especie; this.raza = raza; this.sexo = sexo;
        this.nacimiento = nacimiento; this.peso = peso;
    }
}
