package servicio;

/** Una regla de negocio no se cumple (dato inválido, stock insuficiente, estado no permitido...). El mensaje es para el usuario. */
public class ValidacionException extends RuntimeException {

    public ValidacionException(String mensaje) {
        super(mensaje);
    }
}
