package servicio;

import dao.CitaDAO;
import dao.MascotaDAO;
import dao.UsuarioDAO;
import java.time.Clock;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import modelo.Cita;
import modelo.CitaEstado;
import modelo.Mascota;
import modelo.Usuario;

/** SERVICIO - Agenda de citas: programar, reprogramar, confirmar, cancelar y atender (RF06 a RF08). */
public class CitaService {

    private static final DateTimeFormatter FECHA = DateTimeFormatter.ofPattern("yyyy-MM-dd");
    private static final String MSG_FECHA = "La fecha debe tener el formato aaaa-mm-dd (ej. 2026-10-15).";

    private final CitaDAO citas;
    private final MascotaDAO mascotas;
    private final UsuarioDAO usuarios;
    private final Clock reloj;

    public CitaService(CitaDAO citas, MascotaDAO mascotas, UsuarioDAO usuarios, Clock reloj) {
        this.citas = citas;
        this.mascotas = mascotas;
        this.usuarios = usuarios;
        this.reloj = reloj;
    }

    public void programar(CitaFormulario f, int idRegistrador) {
        citas.insertar(validar(f, 0), idRegistrador);
    }

    public void reprogramar(Cita actual, CitaFormulario f) {
        Cita nueva = validar(f, actual.getId());
        nueva.setId(actual.getId());
        if (!CitaEstado.de(actual.getEstado()).esEditable() || !citas.modificar(nueva)) {
            throw new ValidacionException("Solo se pueden modificar citas PROGRAMADAS o CONFIRMADAS.");
        }
    }

    public void confirmar(Cita c) {
        cambiarEstado(c, CitaEstado.CONFIRMADA);
    }

    public void cancelar(Cita c) {
        cambiarEstado(c, CitaEstado.CANCELADA);
    }

    /** Registra el diagnóstico y deja la cita ATENDIDA (solo si estaba CONFIRMADA). */
    public void atender(Cita c, String diagnostico, String tratamiento) {
        String diag = diagnostico == null ? "" : diagnostico.trim();
        if (diag.isEmpty()) {
            throw new ValidacionException("Escribe el diagnóstico para registrar la atención.");
        }
        String trat = tratamiento == null ? "" : tratamiento.trim();
        if (!CitaEstado.de(c.getEstado()).puedePasarA(CitaEstado.ATENDIDA) || !citas.atender(c.getId(), diag, trat)) {
            throw new ValidacionException("Solo se puede atender una cita CONFIRMADA.");
        }
    }

    public List<Cita> agenda(LocalDate dia) {
        return citas.listarPorFecha(dia);
    }

    public List<Cita> listarTodas() {
        return citas.listarTodas();
    }

    public List<Mascota> mascotasDisponibles() {
        return mascotas.listar();
    }

    public List<Usuario> veterinariosDisponibles() {
        return usuarios.listarVeterinarios();
    }

    /** Convierte el texto "aaaa-mm-dd" en fecha o lanza ValidacionException. */
    public LocalDate parsearFecha(String texto) {
        try {
            return LocalDate.parse(texto.trim(), FECHA);
        } catch (DateTimeParseException ex) {
            throw new ValidacionException(MSG_FECHA);
        }
    }

    // ---------------- Apoyo ----------------

    private void cambiarEstado(Cita c, CitaEstado nuevo) {
        if (!CitaEstado.de(c.getEstado()).puedePasarA(nuevo) || !citas.cambiarEstado(c.getId(), nuevo)) {
            throw new ValidacionException("La cita está " + c.getEstado() + ": no se puede dejar como " + nuevo + ".");
        }
    }

    /** Valida mascota, veterinario, motivo, fecha, que no sea pasada y que no haya cruce de horario. */
    private Cita validar(CitaFormulario f, int idCitaExcluida) {
        if (f.mascota == null || f.veterinario == null) {
            throw new ValidacionException("Elige la mascota y el veterinario.");
        }
        String motivo = f.motivo == null ? "" : f.motivo.trim();
        if (motivo.isEmpty()) {
            throw new ValidacionException("El motivo de la consulta es obligatorio.");
        }
        LocalDateTime fechaHora;
        try {
            fechaHora = LocalDateTime.of(LocalDate.parse(f.fecha.trim(), FECHA), LocalTime.parse(f.hora));
        } catch (DateTimeParseException ex) {
            throw new ValidacionException(MSG_FECHA);
        }
        if (fechaHora.isBefore(LocalDateTime.now(reloj))) {
            throw new ValidacionException("No se puede programar una cita en el pasado.");
        }
        if (citas.horarioOcupado(f.veterinario.getId(), fechaHora, idCitaExcluida)) {
            throw new ValidacionException(f.veterinario.getNombreCompleto()
                    + " ya tiene una cita a esa hora. Elige otro horario.");
        }
        Cita c = new Cita();
        c.setMascota(f.mascota);
        c.setVeterinario(f.veterinario);
        c.setFechaHora(fechaHora);
        c.setMotivo(motivo);
        return c;
    }
}
