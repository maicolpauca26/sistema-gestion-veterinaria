package servicio;

import dao.ComprobanteDAO;
import dao.ProductoDAO;
import dao.ServicioDAO;
import java.util.ArrayList;
import java.util.List;
import modelo.Atencion;
import modelo.Comprobante;
import modelo.DetalleComprobante;
import modelo.Producto;
import modelo.Servicio;

/** SERVICIO - Facturación: arma la boleta, calcula subtotal, IGV y total, y la emite (RF12 y RF13). */
public class FacturacionService {

    private final ComprobanteDAO comprobantes;
    private final ServicioDAO servicios;
    private final ProductoDAO productos;

    public FacturacionService(ComprobanteDAO comprobantes, ServicioDAO servicios, ProductoDAO productos) {
        this.comprobantes = comprobantes;
        this.servicios = servicios;
        this.productos = productos;
    }

    public void agregarServicio(Comprobante boleta, Servicio s, int cantidad) {
        exigirCantidadPositiva(cantidad);
        boleta.getDetalles().add(new DetalleComprobante(s.getId(), null, s.getNombre(), cantidad, s.getPrecio()));
        boleta.calcularTotales();
    }

    /** Agrega un producto sin superar su stock (considera lo que ya está en la boleta). */
    public void agregarProducto(Comprobante boleta, Producto p, int cantidad) {
        exigirCantidadPositiva(cantidad);
        int yaAgregado = 0;
        for (DetalleComprobante d : boleta.getDetalles()) {
            if (d.getIdProducto() != null && d.getIdProducto() == p.getId()) {
                yaAgregado += d.getCantidad();
            }
        }
        if (yaAgregado + cantidad > p.getStock()) {
            throw new ValidacionException("Stock insuficiente de " + p.getNombre() + ": hay " + p.getStock()
                    + " y ya agregaste " + yaAgregado + ".");
        }
        boleta.getDetalles().add(new DetalleComprobante(null, p.getId(), p.getNombre(), cantidad, p.getPrecio()));
        boleta.calcularTotales();
    }

    public void quitarLinea(Comprobante boleta, int fila) {
        if (fila < 0 || fila >= boleta.getDetalles().size()) {
            throw new ValidacionException("Selecciona una línea del detalle para quitarla.");
        }
        boleta.getDetalles().remove(fila);
        boleta.calcularTotales();
    }

    /** Valida y emite la boleta (todo o nada en la BD). Completa serie y número en {@code boleta}. */
    public void emitir(Comprobante boleta, Atencion atencion, String metodoPago, int idUsuario) {
        if (atencion == null) {
            throw new ValidacionException("No hay una atención seleccionada. Registra primero la atención en la agenda de citas.");
        }
        if (boleta.getDetalles().isEmpty()) {
            throw new ValidacionException("Agrega al menos un servicio o producto.");
        }
        boleta.setIdAtencion(atencion.getId());
        boleta.setMetodoPago(metodoPago);
        boleta.calcularTotales();
        comprobantes.emitir(boleta, idUsuario);
    }

    public List<Servicio> listarServicios() {
        return servicios.listar();
    }

    public List<Atencion> listarAtencionesPendientes() {
        return comprobantes.listarAtencionesPendientes();
    }

    /** Solo los productos que todavía tienen stock (los demás no se pueden vender). */
    public List<Producto> listarProductosConStock() {
        List<Producto> r = new ArrayList<>();
        for (Producto p : productos.listar()) {
            if (p.getStock() > 0) {
                r.add(p);
            }
        }
        return r;
    }

    public List<Comprobante> listarEmitidos() {
        return comprobantes.listar();
    }

    private void exigirCantidadPositiva(int cantidad) {
        if (cantidad <= 0) {
            throw new ValidacionException("La cantidad debe ser mayor que 0.");
        }
    }
}
