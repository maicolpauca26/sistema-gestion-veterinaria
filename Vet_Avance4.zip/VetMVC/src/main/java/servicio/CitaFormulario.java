package servicio;

import modelo.Mascota;
import modelo.Usuario;

/** Datos de la pantalla de citas: mascota y veterinario elegidos, y fecha/hora/motivo como texto. */
public class CitaFormulario {

    public final Mascota mascota;
    public final Usuario veterinario;
    public final String fecha;
    public final String hora;
    public final String motivo;

    public CitaFormulario(Mascota mascota, Usuario veterinario, String fecha, String hora, String motivo) {
        this.mascota = mascota; this.veterinario = veterinario;
        this.fecha = fecha; this.hora = hora; this.motivo = motivo;
    }
}
