package config;

import dao.ClienteDAO;
import dao.CitaDAO;
import dao.ComprobanteDAO;
import dao.CredencialDAO;
import dao.MascotaDAO;
import dao.MovimientoInventarioDAO;
import dao.ProductoDAO;
import dao.ServicioDAO;
import dao.UsuarioDAO;
import dao.jdbc.CitaDAOJdbc;
import dao.jdbc.ClienteDAOJdbc;
import dao.jdbc.ComprobanteDAOJdbc;
import dao.jdbc.ConexionMySQL;
import dao.jdbc.MascotaDAOJdbc;
import dao.jdbc.MovimientoInventarioDAOJdbc;
import dao.jdbc.ProductoDAOJdbc;
import dao.jdbc.ProveedorConexion;
import dao.jdbc.ServicioDAOJdbc;
import dao.jdbc.UsuarioDAOJdbc;
import java.time.Clock;
import seguridad.PasswordHasher;
import seguridad.Pbkdf2PasswordHasher;
import seguridad.PoliticaPermisos;
import servicio.AutenticacionService;
import servicio.CitaService;
import servicio.FacturacionService;
import servicio.InventarioService;
import servicio.MascotaService;

/**
 * RAÍZ DE COMPOSICIÓN (DIP). Es el único lugar que conoce las clases concretas (JDBC, PBKDF2) y las
 * conecta con las interfaces: DAO -> Servicio -> Controlador. Para cambiar de motor de base de datos
 * o de algoritmo de cifrado solo se cambia este archivo.
 */
public class Contenedor {

    private final PoliticaPermisos permisos = new PoliticaPermisos();
    private final AutenticacionService autenticacion;
    private final MascotaService mascotas;
    private final CitaService citas;
    private final InventarioService inventario;
    private final FacturacionService facturacion;

    public Contenedor(ProveedorConexion conexiones, Clock reloj, PasswordHasher hasher) {
        UsuarioDAOJdbc usuarioDao = new UsuarioDAOJdbc(conexiones);
        CredencialDAO credencialDao = usuarioDao;
        UsuarioDAO usuarios = usuarioDao;
        ClienteDAO clienteDao = new ClienteDAOJdbc(conexiones);
        MascotaDAO mascotaDao = new MascotaDAOJdbc(conexiones);
        CitaDAO citaDao = new CitaDAOJdbc(conexiones);
        ProductoDAO productoDao = new ProductoDAOJdbc(conexiones);
        MovimientoInventarioDAO movimientoDao = new MovimientoInventarioDAOJdbc(conexiones);
        ServicioDAO servicioDao = new ServicioDAOJdbc(conexiones);
        ComprobanteDAO comprobanteDao = new ComprobanteDAOJdbc(conexiones);

        this.autenticacion = new AutenticacionService(credencialDao, hasher);
        this.mascotas = new MascotaService(mascotaDao, clienteDao, reloj);
        this.citas = new CitaService(citaDao, mascotaDao, usuarios, reloj);
        this.inventario = new InventarioService(productoDao, movimientoDao);
        this.facturacion = new FacturacionService(comprobanteDao, servicioDao, productoDao);
    }

    /** Configuración real: MySQL de Laragon, reloj del sistema y PBKDF2. */
    public static Contenedor porDefecto() {
        return new Contenedor(new ConexionMySQL(), Clock.systemDefaultZone(), new Pbkdf2PasswordHasher());
    }

    public PoliticaPermisos permisos() { return permisos; }
    public AutenticacionService autenticacion() { return autenticacion; }
    public MascotaService mascotas() { return mascotas; }
    public CitaService citas() { return citas; }
    public InventarioService inventario() { return inventario; }
    public FacturacionService facturacion() { return facturacion; }
}
