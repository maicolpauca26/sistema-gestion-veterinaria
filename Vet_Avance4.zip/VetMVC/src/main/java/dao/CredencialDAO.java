package dao;

import java.util.Optional;
import modelo.CredencialUsuario;

/** DAO (ISP) - Solo lo que necesita el inicio de sesión. */
public interface CredencialDAO {

    Optional<CredencialUsuario> buscarPorUsername(String username);

    /** Suma un intento fallido y deja constancia en la auditoría. */
    void registrarIntentoFallido(int idUsuario);

    /** Reinicia los intentos fallidos y deja constancia del inicio de sesión. */
    void registrarAccesoExitoso(int idUsuario);
}
