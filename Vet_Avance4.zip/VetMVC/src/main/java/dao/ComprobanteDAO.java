package dao;

import java.util.List;
import modelo.Atencion;
import modelo.Comprobante;

/** DAO - Comprobantes (RF12 y RF13). */
public interface ComprobanteDAO {

    /**
     * Emite el comprobante: cabecera, detalle y SALIDA de cada producto, todo en una transacción.
     * Completa serie, número e id en {@code c}. Si algo falla (ej. stock insuficiente) no se guarda nada.
     */
    void emitir(Comprobante c, int idUsuario);

    /** Comprobantes emitidos (los más recientes primero). */
    List<Comprobante> listar();

    /** Atenciones que todavía no tienen comprobante. */
    List<Atencion> listarAtencionesPendientes();
}
