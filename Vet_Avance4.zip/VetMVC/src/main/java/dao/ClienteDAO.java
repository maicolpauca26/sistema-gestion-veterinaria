package dao;

import java.util.Optional;
import modelo.Cliente;

/** DAO - Clientes (dueños de las mascotas). */
public interface ClienteDAO {

    Optional<Cliente> buscarPorDni(String dni);
}
