package dao;

import java.util.List;
import modelo.Servicio;

/** DAO - Catálogo de servicios (consulta, vacuna, baño...). */
public interface ServicioDAO {

    List<Servicio> listar();
}
