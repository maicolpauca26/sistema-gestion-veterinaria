package dao;

import modelo.TipoMovimiento;

/** DAO (ISP) - Solo registrar entradas y salidas; el trigger de la BD actualiza el stock. */
public interface MovimientoInventarioDAO {

    void registrar(int idProducto, TipoMovimiento tipo, int cantidad, int idUsuario);
}
