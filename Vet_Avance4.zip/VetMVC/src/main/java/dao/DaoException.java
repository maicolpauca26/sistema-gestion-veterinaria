package dao;

/** Error de acceso a datos (conexión caída, SQL rechazado, trigger de stock, etc.). El mensaje es el de la BD. */
public class DaoException extends RuntimeException {

    public DaoException(String mensaje) {
        super(mensaje);
    }

    public DaoException(String mensaje, Throwable causa) {
        super(mensaje, causa);
    }
}
