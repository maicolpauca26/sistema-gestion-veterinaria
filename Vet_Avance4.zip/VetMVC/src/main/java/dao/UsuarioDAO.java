package dao;

import java.util.List;
import modelo.Usuario;

/** DAO - Consulta de usuarios (personal) para las pantallas. */
public interface UsuarioDAO {

    /** Veterinarios activos (para elegir quién atiende una cita). */
    List<Usuario> listarVeterinarios();
}
