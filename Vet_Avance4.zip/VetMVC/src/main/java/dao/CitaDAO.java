package dao;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;
import modelo.Cita;
import modelo.CitaEstado;

/** DAO - Citas y atenciones (RF06 a RF08). */
public interface CitaDAO {

    /** ¿El veterinario ya tiene una cita no cancelada en ese horario? (se excluye la cita indicada). */
    boolean horarioOcupado(int idVeterinario, LocalDateTime fechaHora, int idCitaExcluida);

    /** Inserta la cita en estado PROGRAMADA. */
    void insertar(Cita c, int idRegistrador);

    /** Reprograma; devuelve false si la cita ya no está PROGRAMADA ni CONFIRMADA. */
    boolean modificar(Cita c);

    /** Cambia el estado solo si el estado actual permite la transición; false si no se pudo. */
    boolean cambiarEstado(int idCita, CitaEstado nuevo);

    /** Registra la atención y marca la cita ATENDIDA (todo o nada). False si la cita no estaba CONFIRMADA. */
    boolean atender(int idCita, String diagnostico, String tratamiento);

    List<Cita> listarPorFecha(LocalDate dia);

    List<Cita> listarTodas();
}
