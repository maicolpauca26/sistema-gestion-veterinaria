package dao.jdbc;

import dao.ServicioDAO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import modelo.Servicio;

public class ServicioDAOJdbc extends JdbcDAO implements ServicioDAO {

    public ServicioDAOJdbc(ProveedorConexion conexiones) {
        super(conexiones);
    }

    @Override
    public List<Servicio> listar() {
        return conectar(con -> {
            List<Servicio> lista = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement("SELECT id_servicio, nombre, precio FROM servicio ORDER BY nombre");
                 ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Servicio(rs.getInt(1), rs.getString(2), rs.getBigDecimal(3)));
                }
            }
            return lista;
        });
    }
}
