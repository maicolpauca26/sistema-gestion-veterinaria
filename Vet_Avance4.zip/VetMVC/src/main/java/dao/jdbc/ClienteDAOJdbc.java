package dao.jdbc;

import dao.ClienteDAO;
import java.util.Optional;
import modelo.Cliente;

public class ClienteDAOJdbc extends JdbcDAO implements ClienteDAO {

    public ClienteDAOJdbc(ProveedorConexion conexiones) {
        super(conexiones);
    }

    @Override
    public Optional<Cliente> buscarPorDni(String dni) {
        return conectar(con -> ClienteSql.porDni(con, dni));
    }
}
