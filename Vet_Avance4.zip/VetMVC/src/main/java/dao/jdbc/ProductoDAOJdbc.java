package dao.jdbc;

import dao.ProductoDAO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import modelo.Producto;

/** DAO JDBC de productos (RF09 a RF11). El stock no se edita aquí: solo cambia con movimientos. */
public class ProductoDAOJdbc extends JdbcDAO implements ProductoDAO {

    private static final String SELECT_PRODUCTO =
            "SELECT id_producto, codigo, nombre, precio, stock, stock_minimo FROM producto WHERE activo = 1 ";

    public ProductoDAOJdbc(ProveedorConexion conexiones) {
        super(conexiones);
    }

    @Override
    public void insertar(Producto p) {
        conectar(con -> {
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO producto (codigo, nombre, precio, stock, stock_minimo) VALUES (?, ?, ?, 0, ?)")) {
                ps.setString(1, p.getCodigo());
                ps.setString(2, p.getNombre());
                ps.setBigDecimal(3, p.getPrecio());
                ps.setInt(4, p.getStockMinimo());
                ps.executeUpdate();
            }
            return null;
        });
    }

    @Override
    public boolean modificar(Producto p) {
        return conectar(con -> {
            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE producto SET codigo=?, nombre=?, precio=?, stock_minimo=? WHERE id_producto=?")) {
                ps.setString(1, p.getCodigo());
                ps.setString(2, p.getNombre());
                ps.setBigDecimal(3, p.getPrecio());
                ps.setInt(4, p.getStockMinimo());
                ps.setInt(5, p.getId());
                return ps.executeUpdate() > 0;
            }
        });
    }

    @Override
    public boolean eliminar(int idProducto) {
        return conectar(con -> {
            try (PreparedStatement ps = con.prepareStatement("UPDATE producto SET activo = 0 WHERE id_producto = ?")) {
                ps.setInt(1, idProducto);
                return ps.executeUpdate() > 0;
            }
        });
    }

    @Override
    public List<Producto> listar() {
        return consultar(SELECT_PRODUCTO + "ORDER BY id_producto", null);
    }

    @Override
    public List<Producto> buscar(String texto) {
        return consultar(SELECT_PRODUCTO + "AND (codigo LIKE ? OR nombre LIKE ?) ORDER BY id_producto", "%" + texto + "%");
    }

    @Override
    public List<Producto> listarCriticos() {
        return consultar(SELECT_PRODUCTO + "AND stock <= stock_minimo ORDER BY stock", null);
    }

    private List<Producto> consultar(String sql, String patron) {
        return conectar(con -> {
            List<Producto> lista = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                if (patron != null) {
                    ps.setString(1, patron);
                    ps.setString(2, patron);
                }
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Producto p = new Producto();
                        p.setId(rs.getInt("id_producto"));
                        p.setCodigo(rs.getString("codigo"));
                        p.setNombre(rs.getString("nombre"));
                        p.setPrecio(rs.getBigDecimal("precio"));
                        p.setStock(rs.getInt("stock"));
                        p.setStockMinimo(rs.getInt("stock_minimo"));
                        lista.add(p);
                    }
                }
            }
            return lista;
        });
    }
}
