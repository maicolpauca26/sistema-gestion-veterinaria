package dao.jdbc;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Optional;
import modelo.Cliente;

/** SQL de la tabla cliente, compartido por ClienteDAOJdbc y MascotaDAOJdbc (que guarda al dueño junto con la mascota). */
final class ClienteSql {

    private ClienteSql() {
    }

    static Optional<Cliente> porDni(Connection con, String dni) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "SELECT id_cliente, dni, nombres, telefono, direccion FROM cliente WHERE dni = ?")) {
            ps.setString(1, dni);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? Optional.of(armar(rs)) : Optional.empty();
            }
        }
    }

    /** Si el DNI existe actualiza los datos del cliente; si no, lo inserta. Devuelve su id. */
    static int guardar(Connection con, Cliente c) throws SQLException {
        Optional<Cliente> existente = porDni(con, c.getDni());
        if (existente.isPresent()) {
            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE cliente SET nombres=?, telefono=?, direccion=?, activo=1 WHERE id_cliente=?")) {
                ps.setString(1, c.getNombres());
                ps.setString(2, c.getTelefono());
                ps.setString(3, c.getDireccion());
                ps.setInt(4, existente.get().getId());
                ps.executeUpdate();
            }
            return existente.get().getId();
        }
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO cliente (dni, nombres, telefono, direccion) VALUES (?, ?, ?, ?)",
                Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, c.getDni());
            ps.setString(2, c.getNombres());
            ps.setString(3, c.getTelefono());
            ps.setString(4, c.getDireccion());
            ps.executeUpdate();
            try (ResultSet keys = ps.getGeneratedKeys()) {
                keys.next();
                return keys.getInt(1);
            }
        }
    }

    static Cliente armar(ResultSet rs) throws SQLException {
        Cliente c = new Cliente();
        c.setId(rs.getInt("id_cliente"));
        c.setDni(rs.getString("dni"));
        c.setNombres(rs.getString("nombres"));
        c.setTelefono(rs.getString("telefono"));
        c.setDireccion(rs.getString("direccion"));
        return c;
    }
}
