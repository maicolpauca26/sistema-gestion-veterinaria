package dao.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 * Conexión JDBC a MySQL (Laragon). Los valores se pueden cambiar sin tocar el código con
 * -Dvet.url=... -Dvet.user=... -Dvet.pass=...
 * Si cambiaste la clave del usuario en sql/dr_sheep_vet.sql, cámbiala también aquí.
 */
public class ConexionMySQL implements ProveedorConexion {

    private static final String URL = System.getProperty("vet.url",
            "jdbc:mysql://localhost:3306/dr_sheep_vet?useSSL=false&serverTimezone=America/Lima"
            + "&allowPublicKeyRetrieval=true&useUnicode=true&characterEncoding=UTF-8");
    private static final String USUARIO = System.getProperty("vet.user", "root");
    private static final String PASSWORD = System.getProperty("vet.pass", "1234");

    @Override
    public Connection obtener() throws SQLException {
        return DriverManager.getConnection(URL, USUARIO, PASSWORD);
    }
}
