package dao.jdbc;

import dao.MascotaDAO;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import modelo.Atencion;
import modelo.Mascota;

/** DAO JDBC de mascotas (RF02 a RF05). "Eliminar" es lógico: activo = 0, para conservar el historial. */
public class MascotaDAOJdbc extends JdbcDAO implements MascotaDAO {

    private static final String SELECT_MASCOTA =
            "SELECT m.id_mascota, m.nombre, m.especie, m.raza, m.sexo, m.fecha_nacimiento, m.peso, "
            + "c.id_cliente, c.dni, c.nombres, c.telefono, c.direccion "
            + "FROM mascota m JOIN cliente c ON c.id_cliente = m.id_cliente WHERE m.activo = 1 ";

    public MascotaDAOJdbc(ProveedorConexion conexiones) {
        super(conexiones);
    }

    @Override
    public void insertar(Mascota m) {
        transaccion(con -> {
            m.getCliente().setId(ClienteSql.guardar(con, m.getCliente()));
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO mascota (id_cliente, nombre, especie, raza, sexo, fecha_nacimiento, peso) "
                    + "VALUES (?, ?, ?, ?, ?, ?, ?)")) {
                llenar(ps, m);
                ps.executeUpdate();
            }
            return null;
        });
    }

    @Override
    public void modificar(Mascota m) {
        transaccion(con -> {
            m.getCliente().setId(ClienteSql.guardar(con, m.getCliente()));
            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE mascota SET id_cliente=?, nombre=?, especie=?, raza=?, sexo=?, "
                    + "fecha_nacimiento=?, peso=? WHERE id_mascota=?")) {
                llenar(ps, m);
                ps.setInt(8, m.getId());
                ps.executeUpdate();
            }
            return null;
        });
    }

    @Override
    public boolean eliminar(int idMascota) {
        return conectar(con -> {
            try (PreparedStatement ps = con.prepareStatement("UPDATE mascota SET activo = 0 WHERE id_mascota = ?")) {
                ps.setInt(1, idMascota);
                return ps.executeUpdate() > 0;
            }
        });
    }

    @Override
    public List<Mascota> listar() {
        return consultar(SELECT_MASCOTA + "ORDER BY m.id_mascota", null);
    }

    @Override
    public List<Mascota> buscar(String texto) {
        return consultar(SELECT_MASCOTA + "AND (m.nombre LIKE ? OR m.especie LIKE ? OR c.nombres LIKE ? "
                + "OR c.dni LIKE ?) ORDER BY m.id_mascota", "%" + texto + "%");
    }

    @Override
    public List<Atencion> historial(int idMascota) {
        String sql = "SELECT a.id_atencion, a.id_cita, a.fecha, a.diagnostico, a.tratamiento "
                + "FROM atencion a JOIN cita c ON c.id_cita = a.id_cita "
                + "WHERE c.id_mascota = ? ORDER BY a.fecha DESC";
        return conectar(con -> {
            List<Atencion> lista = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, idMascota);
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Atencion a = new Atencion();
                        a.setId(rs.getInt("id_atencion"));
                        a.setIdCita(rs.getInt("id_cita"));
                        a.setFecha(rs.getTimestamp("fecha").toLocalDateTime());
                        a.setDiagnostico(rs.getString("diagnostico"));
                        a.setTratamiento(rs.getString("tratamiento"));
                        lista.add(a);
                    }
                }
            }
            return lista;
        });
    }

    // ---------------- Apoyo ----------------

    private List<Mascota> consultar(String sql, String patron) {
        return conectar(con -> {
            List<Mascota> lista = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                if (patron != null) {
                    for (int i = 1; i <= 4; i++) {
                        ps.setString(i, patron);
                    }
                }
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        lista.add(armarMascota(rs));
                    }
                }
            }
            return lista;
        });
    }

    private void llenar(PreparedStatement ps, Mascota m) throws SQLException {
        ps.setInt(1, m.getCliente().getId());
        ps.setString(2, m.getNombre());
        ps.setString(3, m.getEspecie());
        ps.setString(4, m.getRaza());
        ps.setString(5, m.getSexo());
        ps.setDate(6, m.getFechaNacimiento() == null ? null : Date.valueOf(m.getFechaNacimiento()));
        ps.setDouble(7, m.getPeso());
    }

    private Mascota armarMascota(ResultSet rs) throws SQLException {
        Mascota m = new Mascota();
        m.setId(rs.getInt("id_mascota"));
        m.setNombre(rs.getString("nombre"));
        m.setEspecie(rs.getString("especie"));
        m.setRaza(rs.getString("raza"));
        m.setSexo(rs.getString("sexo"));
        Date nac = rs.getDate("fecha_nacimiento");
        m.setFechaNacimiento(nac == null ? null : nac.toLocalDate());
        m.setPeso(rs.getDouble("peso"));
        m.setCliente(ClienteSql.armar(rs));
        return m;
    }
}
