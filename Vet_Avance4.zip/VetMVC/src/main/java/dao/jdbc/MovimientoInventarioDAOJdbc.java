package dao.jdbc;

import dao.MovimientoInventarioDAO;
import java.sql.PreparedStatement;
import modelo.TipoMovimiento;

/** DAO JDBC de movimientos. El trigger de la BD actualiza el stock y rechaza salidas mayores al stock. */
public class MovimientoInventarioDAOJdbc extends JdbcDAO implements MovimientoInventarioDAO {

    public MovimientoInventarioDAOJdbc(ProveedorConexion conexiones) {
        super(conexiones);
    }

    @Override
    public void registrar(int idProducto, TipoMovimiento tipo, int cantidad, int idUsuario) {
        conectar(con -> {
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO movimiento_inventario (id_producto, id_usuario, tipo, cantidad) VALUES (?, ?, ?, ?)")) {
                ps.setInt(1, idProducto);
                ps.setInt(2, idUsuario);
                ps.setString(3, tipo.name());
                ps.setInt(4, cantidad);
                ps.executeUpdate();
            }
            return null;
        });
    }
}
