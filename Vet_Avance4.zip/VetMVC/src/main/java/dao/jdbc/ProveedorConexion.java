package dao.jdbc;

import java.sql.Connection;
import java.sql.SQLException;

/** Abstracción de "de dónde sale la conexión" (DIP): los DAO no saben si es MySQL, otro motor o un pool. */
public interface ProveedorConexion {

    Connection obtener() throws SQLException;
}
