package dao.jdbc;

import dao.CredencialDAO;
import dao.UsuarioDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import modelo.CredencialUsuario;
import modelo.Usuario;

/** DAO JDBC de usuarios. Implementa dos interfaces pequeñas (ISP): CredencialDAO (login) y UsuarioDAO (listas). */
public class UsuarioDAOJdbc extends JdbcDAO implements CredencialDAO, UsuarioDAO {

    public UsuarioDAOJdbc(ProveedorConexion conexiones) {
        super(conexiones);
    }

    @Override
    public Optional<CredencialUsuario> buscarPorUsername(String username) {
        String sql = "SELECT u.id_usuario, u.password_hash, u.nombre_completo, u.activo, "
                + "u.intentos_fallidos, r.nombre AS rol FROM usuario u "
                + "JOIN rol r ON r.id_rol = u.id_rol WHERE u.username = ?";
        return conectar(con -> {
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, username);
                try (ResultSet rs = ps.executeQuery()) {
                    if (!rs.next()) {
                        return Optional.empty();
                    }
                    return Optional.of(new CredencialUsuario(rs.getInt("id_usuario"), username,
                            rs.getString("password_hash"), rs.getString("nombre_completo"), rs.getString("rol"),
                            rs.getInt("activo") != 0, rs.getInt("intentos_fallidos")));
                }
            }
        });
    }

    @Override
    public void registrarIntentoFallido(int idUsuario) {
        transaccion(con -> {
            ejecutar(con, "UPDATE usuario SET intentos_fallidos = intentos_fallidos + 1 WHERE id_usuario = ?", idUsuario);
            registrarLog(con, idUsuario, "Login fallido");
            return null;
        });
    }

    @Override
    public void registrarAccesoExitoso(int idUsuario) {
        transaccion(con -> {
            ejecutar(con, "UPDATE usuario SET intentos_fallidos = 0 WHERE id_usuario = ?", idUsuario);
            registrarLog(con, idUsuario, "Inicio de sesión");
            return null;
        });
    }

    @Override
    public List<Usuario> listarVeterinarios() {
        String sql = "SELECT u.id_usuario, u.username, u.nombre_completo, r.nombre AS rol FROM usuario u "
                + "JOIN rol r ON r.id_rol = u.id_rol WHERE r.nombre = 'Veterinario' AND u.activo = 1 "
                + "ORDER BY u.nombre_completo";
        return conectar(con -> {
            List<Usuario> lista = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    lista.add(new Usuario(rs.getInt("id_usuario"), rs.getString("username"),
                            rs.getString("nombre_completo"), rs.getString("rol")));
                }
            }
            return lista;
        });
    }

    private void ejecutar(Connection con, String sql, int id) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, id);
            ps.executeUpdate();
        }
    }

    private void registrarLog(Connection con, int idUsuario, String accion) throws SQLException {
        try (PreparedStatement ps = con.prepareStatement(
                "INSERT INTO log_auditoria (id_usuario, accion) VALUES (?, ?)")) {
            ps.setInt(1, idUsuario);
            ps.setString(2, accion);
            ps.executeUpdate();
        }
    }
}
