package dao.jdbc;

import dao.DaoException;
import java.sql.Connection;
import java.sql.SQLException;

/**
 * Base de los DAO JDBC: abre y cierra la conexión, maneja la transacción (commit / rollback)
 * y convierte SQLException en DaoException. Así cada DAO solo contiene su SQL.
 */
abstract class JdbcDAO {

    @FunctionalInterface
    interface Trabajo<T> {
        T ejecutar(Connection con) throws SQLException;
    }

    private final ProveedorConexion conexiones;

    protected JdbcDAO(ProveedorConexion conexiones) {
        this.conexiones = conexiones;
    }

    /** Una consulta o un UPDATE suelto, con su propia conexión. */
    protected <T> T conectar(Trabajo<T> trabajo) {
        try (Connection con = conexiones.obtener()) {
            return trabajo.ejecutar(con);
        } catch (SQLException e) {
            throw new DaoException(e.getMessage(), e);
        }
    }

    /** Varias sentencias "todo o nada": si algo falla se hace rollback y no se guarda nada. */
    protected <T> T transaccion(Trabajo<T> trabajo) {
        try (Connection con = conexiones.obtener()) {
            con.setAutoCommit(false);
            try {
                T resultado = trabajo.ejecutar(con);
                con.commit();
                return resultado;
            } catch (SQLException | RuntimeException e) {
                con.rollback();
                throw e;
            }
        } catch (SQLException e) {
            throw new DaoException(e.getMessage(), e);
        }
    }
}
