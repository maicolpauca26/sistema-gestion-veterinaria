package dao.jdbc;

import dao.CitaDAO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;
import modelo.Cita;
import modelo.CitaEstado;
import modelo.Mascota;
import modelo.Usuario;

/** DAO JDBC de citas y atenciones (RF06 a RF08). Las reglas de transición viven en {@link CitaEstado}. */
public class CitaDAOJdbc extends JdbcDAO implements CitaDAO {

    private static final String SELECT_CITA =
            "SELECT c.id_cita, c.fecha_hora, c.motivo, c.estado, m.id_mascota, m.nombre AS mascota, "
            + "cl.nombres AS cliente, u.id_usuario, u.nombre_completo AS veterinario "
            + "FROM cita c JOIN mascota m ON m.id_mascota = c.id_mascota "
            + "JOIN cliente cl ON cl.id_cliente = m.id_cliente "
            + "JOIN usuario u ON u.id_usuario = c.id_veterinario ";

    public CitaDAOJdbc(ProveedorConexion conexiones) {
        super(conexiones);
    }

    @Override
    public boolean horarioOcupado(int idVeterinario, LocalDateTime fechaHora, int idCitaExcluida) {
        String sql = "SELECT COUNT(*) FROM cita WHERE id_veterinario = ? AND fecha_hora = ? "
                + "AND estado <> 'CANCELADA' AND id_cita <> ?";
        return conectar(con -> {
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, idVeterinario);
                ps.setTimestamp(2, Timestamp.valueOf(fechaHora));
                ps.setInt(3, idCitaExcluida);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    return rs.getInt(1) > 0;
                }
            }
        });
    }

    @Override
    public void insertar(Cita c, int idRegistrador) {
        String sql = "INSERT INTO cita (id_mascota, id_veterinario, id_registrador, fecha_hora, motivo, estado) "
                + "VALUES (?, ?, ?, ?, ?, '" + CitaEstado.PROGRAMADA + "')";
        conectar(con -> {
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, c.getMascota().getId());
                ps.setInt(2, c.getVeterinario().getId());
                ps.setInt(3, idRegistrador);
                ps.setTimestamp(4, Timestamp.valueOf(c.getFechaHora()));
                ps.setString(5, c.getMotivo());
                ps.executeUpdate();
            }
            return null;
        });
    }

    @Override
    public boolean modificar(Cita c) {
        String sql = "UPDATE cita SET id_mascota=?, id_veterinario=?, fecha_hora=?, motivo=? "
                + "WHERE id_cita=? AND estado IN " + lista(editables());
        return conectar(con -> {
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setInt(1, c.getMascota().getId());
                ps.setInt(2, c.getVeterinario().getId());
                ps.setTimestamp(3, Timestamp.valueOf(c.getFechaHora()));
                ps.setString(4, c.getMotivo());
                ps.setInt(5, c.getId());
                return ps.executeUpdate() > 0;
            }
        });
    }

    @Override
    public boolean cambiarEstado(int idCita, CitaEstado nuevo) {
        String sql = "UPDATE cita SET estado = ? WHERE id_cita = ? AND estado IN " + lista(CitaEstado.origenesPara(nuevo));
        return conectar(con -> {
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                ps.setString(1, nuevo.name());
                ps.setInt(2, idCita);
                return ps.executeUpdate() > 0;
            }
        });
    }

    @Override
    public boolean atender(int idCita, String diagnostico, String tratamiento) {
        return transaccion(con -> {
            try (PreparedStatement ps = con.prepareStatement(
                    "UPDATE cita SET estado = ? WHERE id_cita = ? AND estado IN " + lista(CitaEstado.origenesPara(CitaEstado.ATENDIDA)))) {
                ps.setString(1, CitaEstado.ATENDIDA.name());
                ps.setInt(2, idCita);
                if (ps.executeUpdate() == 0) {
                    return false;
                }
            }
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO atencion (id_cita, diagnostico, tratamiento) VALUES (?, ?, ?)")) {
                ps.setInt(1, idCita);
                ps.setString(2, diagnostico);
                ps.setString(3, tratamiento);
                ps.executeUpdate();
            }
            return true;
        });
    }

    @Override
    public List<Cita> listarPorFecha(LocalDate dia) {
        return consultar(SELECT_CITA + "WHERE DATE(c.fecha_hora) = ? ORDER BY c.fecha_hora", dia);
    }

    @Override
    public List<Cita> listarTodas() {
        return consultar(SELECT_CITA + "ORDER BY c.fecha_hora DESC", null);
    }

    // ---------------- Apoyo ----------------

    private List<Cita> consultar(String sql, LocalDate dia) {
        return conectar(con -> {
            List<Cita> lista = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement(sql)) {
                if (dia != null) {
                    ps.setDate(1, java.sql.Date.valueOf(dia));
                }
                try (ResultSet rs = ps.executeQuery()) {
                    while (rs.next()) {
                        Cita c = new Cita();
                        c.setId(rs.getInt("id_cita"));
                        c.setFechaHora(rs.getTimestamp("fecha_hora").toLocalDateTime());
                        c.setMotivo(rs.getString("motivo"));
                        c.setEstado(rs.getString("estado"));
                        Mascota m = new Mascota();
                        m.setId(rs.getInt("id_mascota"));
                        m.setNombre(rs.getString("mascota"));
                        m.getCliente().setNombres(rs.getString("cliente"));
                        c.setMascota(m);
                        c.setVeterinario(new Usuario(rs.getInt("id_usuario"), null,
                                rs.getString("veterinario"), Usuario.VETERINARIO));
                        lista.add(c);
                    }
                }
            }
            return lista;
        });
    }

    private static Set<CitaEstado> editables() {
        Set<CitaEstado> r = new java.util.LinkedHashSet<>();
        for (CitaEstado e : CitaEstado.values()) {
            if (e.esEditable()) {
                r.add(e);
            }
        }
        return r;
    }

    /** ('PROGRAMADA','CONFIRMADA'): solo nombres del enum, nunca texto del usuario (sin riesgo de inyección). */
    private static String lista(Set<CitaEstado> estados) {
        return estados.stream().map(e -> "'" + e.name() + "'").collect(Collectors.joining(",", "(", ")"));
    }
}
