package dao.jdbc;

import dao.ComprobanteDAO;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import modelo.Atencion;
import modelo.Comprobante;
import modelo.DetalleComprobante;
import modelo.TipoMovimiento;

/** DAO JDBC de comprobantes (RF12 y RF13). Emitir es una sola transacción: cabecera, detalle y salida de stock. */
public class ComprobanteDAOJdbc extends JdbcDAO implements ComprobanteDAO {

    public ComprobanteDAOJdbc(ProveedorConexion conexiones) {
        super(conexiones);
    }

    @Override
    public void emitir(Comprobante c, int idUsuario) {
        int idComprobante = transaccion(con -> {
            int numero;
            try (PreparedStatement ps = con.prepareStatement(
                    "SELECT COALESCE(MAX(numero), 0) + 1 FROM comprobante WHERE serie = ? FOR UPDATE")) {
                ps.setString(1, Comprobante.SERIE);
                try (ResultSet rs = ps.executeQuery()) {
                    rs.next();
                    numero = rs.getInt(1);
                }
            }
            c.setSerie(Comprobante.SERIE);
            c.setNumero(numero);

            int id;
            try (PreparedStatement ps = con.prepareStatement(
                    "INSERT INTO comprobante (id_atencion, id_usuario, serie, numero, metodo_pago, "
                    + "subtotal, igv, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)", Statement.RETURN_GENERATED_KEYS)) {
                ps.setInt(1, c.getIdAtencion());
                ps.setInt(2, idUsuario);
                ps.setString(3, c.getSerie());
                ps.setInt(4, c.getNumero());
                ps.setString(5, c.getMetodoPago());
                ps.setBigDecimal(6, c.getSubtotal());
                ps.setBigDecimal(7, c.getIgv());
                ps.setBigDecimal(8, c.getTotal());
                ps.executeUpdate();
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    keys.next();
                    id = keys.getInt(1);
                }
            }

            for (DetalleComprobante d : c.getDetalles()) {
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO detalle_comprobante (id_comprobante, id_servicio, id_producto, "
                        + "descripcion, cantidad, precio_unitario, subtotal) VALUES (?, ?, ?, ?, ?, ?, ?)")) {
                    ps.setInt(1, id);
                    ps.setObject(2, d.getIdServicio());
                    ps.setObject(3, d.getIdProducto());
                    ps.setString(4, d.getDescripcion());
                    ps.setInt(5, d.getCantidad());
                    ps.setBigDecimal(6, d.getPrecioUnitario());
                    ps.setBigDecimal(7, d.getSubtotal());
                    ps.executeUpdate();
                }
                if (d.getIdProducto() != null) {   // el producto usado sale del inventario
                    try (PreparedStatement ps = con.prepareStatement(
                            "INSERT INTO movimiento_inventario (id_producto, id_atencion, id_usuario, tipo, cantidad) "
                            + "VALUES (?, ?, ?, ?, ?)")) {
                        ps.setInt(1, d.getIdProducto());
                        ps.setInt(2, c.getIdAtencion());
                        ps.setInt(3, idUsuario);
                        ps.setString(4, TipoMovimiento.SALIDA.name());
                        ps.setInt(5, d.getCantidad());
                        ps.executeUpdate();
                    }
                }
            }
            return id;
        });
        c.setId(idComprobante);
    }

    @Override
    public List<Comprobante> listar() {
        String sql = "SELECT k.id_comprobante, k.serie, k.numero, k.fecha, k.metodo_pago, k.subtotal, k.igv, k.total, "
                + "cl.nombres AS cliente FROM comprobante k "
                + "JOIN atencion a ON a.id_atencion = k.id_atencion JOIN cita c ON c.id_cita = a.id_cita "
                + "JOIN mascota m ON m.id_mascota = c.id_mascota JOIN cliente cl ON cl.id_cliente = m.id_cliente "
                + "ORDER BY k.id_comprobante DESC";
        return conectar(con -> {
            List<Comprobante> lista = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Comprobante c = new Comprobante();
                    c.setId(rs.getInt("id_comprobante"));
                    c.setSerie(rs.getString("serie"));
                    c.setNumero(rs.getInt("numero"));
                    c.setFecha(rs.getTimestamp("fecha").toLocalDateTime());
                    c.setMetodoPago(rs.getString("metodo_pago"));
                    c.setCliente(rs.getString("cliente"));
                    c.setMontos(rs.getBigDecimal("subtotal"), rs.getBigDecimal("igv"), rs.getBigDecimal("total"));
                    lista.add(c);
                }
            }
            return lista;
        });
    }

    @Override
    public List<Atencion> listarAtencionesPendientes() {
        String sql = "SELECT a.id_atencion, a.id_cita, a.fecha, a.diagnostico, m.nombre AS mascota, cl.nombres AS cliente "
                + "FROM atencion a JOIN cita c ON c.id_cita = a.id_cita "
                + "JOIN mascota m ON m.id_mascota = c.id_mascota JOIN cliente cl ON cl.id_cliente = m.id_cliente "
                + "WHERE NOT EXISTS (SELECT 1 FROM comprobante k WHERE k.id_atencion = a.id_atencion) "
                + "ORDER BY a.fecha";
        return conectar(con -> {
            List<Atencion> lista = new ArrayList<>();
            try (PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Atencion a = new Atencion();
                    a.setId(rs.getInt("id_atencion"));
                    a.setIdCita(rs.getInt("id_cita"));
                    a.setFecha(rs.getTimestamp("fecha").toLocalDateTime());
                    a.setDiagnostico(rs.getString("diagnostico"));
                    a.setMascota(rs.getString("mascota"));
                    a.setCliente(rs.getString("cliente"));
                    lista.add(a);
                }
            }
            return lista;
        });
    }
}
