package dao;

import java.util.List;
import modelo.Atencion;
import modelo.Mascota;

/** DAO - Mascotas (RF02 a RF05). Todos los métodos lanzan {@link DaoException} si falla la BD. */
public interface MascotaDAO {

    /** Guarda la mascota; si el DNI del dueño no existe, registra también al cliente. */
    void insertar(Mascota m);

    void modificar(Mascota m);

    /** Eliminación lógica. Devuelve false si no existía. */
    boolean eliminar(int idMascota);

    List<Mascota> listar();

    /** Busca por nombre de mascota, especie, nombre del dueño o DNI (coincidencia parcial). */
    List<Mascota> buscar(String texto);

    /** Historial médico (RF04): atenciones de la más reciente a la más antigua. */
    List<Atencion> historial(int idMascota);
}
