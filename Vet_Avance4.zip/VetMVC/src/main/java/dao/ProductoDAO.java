package dao;

import java.util.List;
import modelo.Producto;

/** DAO - Productos del inventario (RF09 a RF11). El stock NO se edita aquí: solo cambia con movimientos. */
public interface ProductoDAO {

    void insertar(Producto p);

    /** false si el producto no existe. */
    boolean modificar(Producto p);

    /** Eliminación lógica; false si no existía. */
    boolean eliminar(int idProducto);

    List<Producto> listar();

    List<Producto> buscar(String texto);

    /** Productos con stock igual o menor al mínimo (alerta RF11). */
    List<Producto> listarCriticos();
}
