package seguridad;

/** Abstracción del cifrado de contraseñas (DIP): el servicio de login no sabe qué algoritmo se usa. */
public interface PasswordHasher {

    String hash(String password);

    boolean verificar(String password, String guardado);
}
