package seguridad;

import java.util.EnumSet;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import modelo.Usuario;

/**
 * Qué puede hacer cada rol. Antes esto eran cadenas de if/else repartidas por los controladores;
 * ahora es una tabla en un solo lugar (SRP) y un rol nuevo se agrega aquí sin tocar nada más (OCP).
 */
public class PoliticaPermisos {

    private final Map<String, Set<Permiso>> porRol = new HashMap<>();

    public PoliticaPermisos() {
        porRol.put(Usuario.ADMIN, EnumSet.allOf(Permiso.class));
        porRol.put(Usuario.RECEPCIONISTA, EnumSet.of(
                Permiso.VER_MASCOTAS, Permiso.EDITAR_MASCOTAS,
                Permiso.VER_CITAS, Permiso.AGENDAR_CITAS,
                Permiso.VER_FACTURACION));
        porRol.put(Usuario.VETERINARIO, EnumSet.of(
                Permiso.VER_MASCOTAS,
                Permiso.VER_CITAS, Permiso.ATENDER_CITAS,
                Permiso.VER_INVENTARIO));
    }

    public boolean puede(String rol, Permiso permiso) {
        Set<Permiso> permisos = porRol.get(rol);
        return permisos != null && permisos.contains(permiso);
    }
}
