package seguridad;

import util.PasswordUtil;

/** Implementación con PBKDF2-HmacSHA256 (viene en el JDK). Reutiliza {@link PasswordUtil}. */
public class Pbkdf2PasswordHasher implements PasswordHasher {

    @Override
    public String hash(String password) {
        return PasswordUtil.hash(password);
    }

    @Override
    public boolean verificar(String password, String guardado) {
        return PasswordUtil.verificar(password, guardado);
    }
}
