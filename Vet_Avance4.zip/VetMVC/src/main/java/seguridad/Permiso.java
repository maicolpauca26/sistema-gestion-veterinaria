package seguridad;

/** Cada cosa que un rol puede hacer en el sistema. */
public enum Permiso {
    VER_MASCOTAS, EDITAR_MASCOTAS,
    VER_CITAS, AGENDAR_CITAS, ATENDER_CITAS,
    VER_INVENTARIO,
    VER_FACTURACION
}
