package util;

import java.awt.Component;
import javax.swing.JOptionPane;

/** UTILITARIO - Cuadros de diálogo comunes para los controladores. */
public final class Mensajes {

    private Mensajes() {
    }

    public static void aviso(Component padre, String mensaje) {
        JOptionPane.showMessageDialog(padre, mensaje, "Datos incompletos o inválidos", JOptionPane.WARNING_MESSAGE);
    }

    public static void error(Component padre, String mensaje) {
        JOptionPane.showMessageDialog(padre, mensaje, "Error", JOptionPane.ERROR_MESSAGE);
    }

    public static void info(Component padre, String mensaje) {
        JOptionPane.showMessageDialog(padre, mensaje, "DR.SHEEP", JOptionPane.INFORMATION_MESSAGE);
    }

    public static boolean confirmar(Component padre, String mensaje) {
        return JOptionPane.showConfirmDialog(padre, mensaje, "Confirmar", JOptionPane.YES_NO_OPTION)
                == JOptionPane.YES_OPTION;
    }

    /** Mensaje estándar cuando no hay conexión con la base de datos. */
    public static void sinConexion(Component padre, String detalle) {
        error(padre, "No se pudo conectar a la base de datos.\n"
                + "• Verifica que MySQL (Laragon) esté iniciado.\n"
                + "• Verifica que ejecutaste sql/dr_sheep_vet.sql.\n"
                + "• Revisa usuario y contraseña en dao/jdbc/ConexionMySQL.java.\n\nDetalle: " + detalle);
    }
}
